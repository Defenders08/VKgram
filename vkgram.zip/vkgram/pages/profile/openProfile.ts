import mediaSizes from '@helpers/mediaSizes';
import rootScope from '@lib/rootScope';
import {openVKSection} from '@/vkgram/sections';
import {openWebKProfile} from '@/vkgram/webk';
import {openVKProfilePeer} from '@/vkgram/pages/profile/route';

/**
 * The page of another user. Desktop: VKgram's own profile page inside
 * «Моя страница». Mobile: unchanged — Web K's profile in the right column of
 * the chat, as before.
 */
export function openVKProfile(peerId: PeerId) {
  if(mediaSizes.isMobile) return openWebKProfile(peerId);

  // brings the section up and drops the profile that was open in it
  openVKSection('profile');
  // my own id is simply «Моя страница»
  if(peerId !== rootScope.myId) openVKProfilePeer(peerId);
}
