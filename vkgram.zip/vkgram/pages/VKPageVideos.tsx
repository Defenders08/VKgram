import VKPagePlaceholder from '@/vkgram/pages/VKPagePlaceholder';

export default function VKPageVideos() {
  return (
    <VKPagePlaceholder
      section="videos"
      description="Здесь будут ваши видеозаписи."
    />
  );
}
