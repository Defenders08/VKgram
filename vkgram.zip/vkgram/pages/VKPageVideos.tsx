import VKMediaPage, {VKMediaList} from '@/vkgram/components/VKMediaBrowser';

/**
 * «Видеозаписи»: «Поиск» — the videos of all chats (Telegram's global search,
 * videos only) and «Избранное» — the videos kept in the saved messages.
 */
export default function VKPageVideos() {
  return (
    <VKMediaPage
      section="videos"
      tabs={[
        {id: 'search', title: 'Поиск', render: () => <VKMediaList kind="videos" source="search" />},
        {id: 'saved', title: 'Избранное', render: () => <VKMediaList kind="videos" source="saved" />}
      ]}
    />
  );
}
