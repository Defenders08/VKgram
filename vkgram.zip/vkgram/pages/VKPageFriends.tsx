import {createEffect, createMemo, createResource, createSignal, For, onCleanup, onMount, Show} from 'solid-js';
import type {Chat, User} from '@layer';
import rootScope from '@lib/rootScope';
import {usePeers} from '@stores/peers';
import {AvatarNewTsx} from '@components/avatarNew';
import sortContacts from '@appManagers/utils/users/sortContacts';
import getPeerActiveUsernames from '@appManagers/utils/peers/getPeerActiveUsernames';
import removeAccents from '@helpers/string/removeAccents';
import createListenerSetter from '@helpers/solid/createListenerSetter';
import {openWebKChat} from '@/vkgram/webk';
import {openVKProfile} from '@/vkgram/pages/profile/openProfile';
import createIncrementalList from '@/vkgram/hooks/createIncrementalList';
import VKSearchField from '@/vkgram/components/VKSearchField';
import VKTabs, {VKTabItem} from '@/vkgram/components/VKTabs';
import useChannelFolders from '@/vkgram/hooks/useChannelFolders';
import {fetchFolder} from '@/vkgram/hooks/useSubscribedChannels';
import getDialogIndex from '@appManagers/utils/dialogs/getDialogIndex';
import {FOLDER_ID_ALL} from '@appManagers/constants';
import type {Dialog} from '@appManagers/appMessagesManager';

const AVATAR_SIZE = 48;

const normalize = (text: string) => removeAccents(text).toLowerCase();

/**
 * «Друзья» — the Telegram contacts of the signed-in user (not every user, not
 * every chat).
 *
 * Ids: `appUsersManager.getContactsPeerIds` — the list Web K's own contacts
 * tab is built from (its `contacts.getContacts` result is cached in the
 * manager). Users themselves — names, usernames, avatars — come from the
 * reactive peer store, so a rename or a new avatar reaches the rows without
 * any refresh. The list of ids is asked again only when Web K says a contact
 * was added or removed (`contacts_update`). Search filters what is already
 * loaded.
 */
export default function VKPageFriends() {
  const peers = usePeers();
  const listenerSetter = createListenerSetter();
  const folders = useChannelFolders();

  const [peerIds, setPeerIds] = createSignal<PeerId[]>();
  const [allDialogs, setAllDialogs] = createSignal<Dialog[]>([]);
  const [query, setQuery] = createSignal('');
  const [tab, setTab] = createSignal('contacts');
  const [isDesktop, setIsDesktop] = createSignal(
    typeof window !== 'undefined' && window.matchMedia('(min-width: 601px)').matches
  );

  // Contacts are shown in chronological order, like Telegram's recent-contact
  // view: people with the most recently active dialog come first. Contacts that
  // have no dialog history are kept at the end in the existing name order.
  const [dialogIndexes, setDialogIndexes] = createSignal<Map<PeerId, number>>(new Map(), {equals: false});

  let loadToken = 0;
  let dialogLoadToken = 0;
  let disposed = false;
  onCleanup(() => {
    disposed = true;
  });

  onMount(() => {
    const media = window.matchMedia('(min-width: 601px)');
    const update = () => setIsDesktop(media.matches);
    update();
    media.addEventListener?.('change', update);
    onCleanup(() => media.removeEventListener?.('change', update));
  });

  const load = () => {
    const token = ++loadToken;
    rootScope.managers.appUsersManager.getContactsPeerIds(undefined, false, 'name').then((ids) => {
      if(disposed || token !== loadToken) return;
      setPeerIds(ids);
    }, (err) => {
      console.error('VKgram: failed to load contacts', err);
      if(!disposed && token === loadToken) setPeerIds((current) => current ?? []);
    });
  };

  load();

  const loadDialogOrder = () => {
    const token = ++dialogLoadToken;
    fetchFolder(FOLDER_ID_ALL, () => !disposed).then((dialogs) => {
      if(disposed || token !== dialogLoadToken) return;
      const dialogList = dialogs as Dialog[];
      setAllDialogs(dialogList);
      const next = new Map<PeerId, number>();
      for(const dialog of dialogList) {
        const index = getDialogIndex(dialog);
        if(index !== undefined) next.set(dialog.peerId, index);
      }
      setDialogIndexes(next);
    }, (err) => console.error('VKgram: failed to load dialog order for contacts', err));
  };

  loadDialogOrder();

  const updateDialogOrder = (dialog: Dialog | undefined) => {
    if(!dialog) return;
    const index = getDialogIndex(dialog);
    if(index === undefined) return;
    setDialogIndexes((current) => {
      const next = new Map(current);
      next.set(dialog.peerId, index);
      return next;
    });
    setAllDialogs((current) => {
      const existing = current.findIndex((item) => item.peerId === dialog.peerId);
      if(existing < 0) return [...current, dialog];
      const next = current.slice();
      next[existing] = dialog;
      return next;
    });
  };

  listenerSetter.add(rootScope)('dialogs_multiupdate', (updated) => {
    for(const [, item] of updated) updateDialogOrder(item.dialog as Dialog);
  });
  listenerSetter.add(rootScope)('dialog_flush', ({dialog}) => updateDialogOrder(dialog as Dialog));
  listenerSetter.add(rootScope)('dialog_unread', ({dialog}) => updateDialogOrder(dialog as Dialog));

  let reloadTimeout: number;
  listenerSetter.add(rootScope)('contacts_update', () => {
    clearTimeout(reloadTimeout);
    reloadTimeout = window.setTimeout(load, 0);
  });
  onCleanup(() => clearTimeout(reloadTimeout));

  const sorted = createMemo(() => {
    const ids = peerIds();
    if(!ids) return;

    // Start from Web K's stable contact ordering, then move contacts with a
    // recent dialog to the top. This keeps users without chat history visible
    // and deterministic at the end of the list.
    const byName = sortContacts(ids, 'name', (userId) => peers[userId.toPeerId(false)] as User.user).peerIds;
    const indexes = dialogIndexes();
    return byName.slice().sort((a, b) => {
      const indexA = indexes.get(a);
      const indexB = indexes.get(b);
      if(indexA === undefined && indexB === undefined) return 0;
      if(indexA === undefined) return 1;
      if(indexB === undefined) return -1;
      return indexB - indexA;
    });
  });

  // «Все чаты» здесь означает только личные диалоги с пользователями.
  // Группы, каналы и другие типы peer'ов намеренно исключаем.
  const allChatPeerIds = createMemo(() => {
    const indexes = dialogIndexes();
    return allDialogs()
      .filter((dialog) => {
        const peer = peers[dialog.peerId] as User.user | Chat.chat | Chat.channel | undefined;
        // «Все чаты» — только живые человеческие аккаунты.
        // Боты и удалённые аккаунты сюда не попадают.
        return peer?._ === 'user' && !peer.pFlags?.bot && !peer.pFlags?.deleted;
      })
      .slice()
      .sort((a, b) => {
        const indexA = indexes.get(a.peerId);
        const indexB = indexes.get(b.peerId);
        if(indexA === undefined && indexB === undefined) return 0;
        if(indexA === undefined) return 1;
        if(indexB === undefined) return -1;
        return indexB - indexA;
      })
      .map((dialog) => dialog.peerId);
  });

  const folderTabs = createMemo(() => {
    const ids = peerIds();
    if(!ids || !folders.isReady()) return [];
    const contacts = new Set(ids);
    return folders.folders().filter((folder) => [...folder.peerIds].some((peerId) => contacts.has(peerId)));
  }, undefined, {
    equals: (a, b) => a.length === b.length && a.every((folder, index) => folder === b[index])
  });

  const tabs = createMemo<VKTabItem<string>[]>(() => [
    {id: 'contacts', title: 'Контакты'},
    {id: 'all-chats', title: 'Все чаты'},
    ...folderTabs().map((folder) => ({id: String(folder.id), title: folder.title})),
    {id: 'search', title: 'Поиск'}
  ]);

  createEffect(() => {
    if(peerIds() && folders.isReady() && !tabs().some((item) => item.id === tab())) setTab('contacts');
  });

  const selectedFolder = createMemo(() => {
    if(tab() === 'contacts' || tab() === 'search') return undefined;
    return folders.folders().find((folder) => String(folder.id) === tab());
  });

  const filtered = createMemo(() => {
    if(tab() === 'all-chats') {
      const text = normalize(query().trim().replace(/^@/, ''));
      const ids = allChatPeerIds();
      if(!text) return ids;
      const words = text.split(/\s+/);
      return ids.filter((peerId) => {
        const peer = peers[peerId] as User.user | Chat.chat | Chat.channel;
        if(!peer) return false;
        const title = peer._ === 'user' ? [peer.first_name, peer.last_name].filter(Boolean).join(' ') : peer.title;
        const haystack = normalize([title, ...(peer._ === 'user' ? getPeerActiveUsernames(peer) : [])].filter(Boolean).join(' '));
        return words.every((word) => haystack.includes(word));
      });
    }

    const ids = sorted();
    if(!ids) return;
    const folder = selectedFolder();
    const inFolder = folder ? ids.filter((peerId) => folder.peerIds.has(peerId)) : ids;

    const text = normalize(query().trim().replace(/^@/, ''));
    if(!text || tab() === 'search') return inFolder;

    const words = text.split(/\s+/);
    return inFolder.filter((peerId) => {
      const user = peers[peerId] as User.user;
      if(!user) return false;
      const haystack = normalize([
        user.first_name,
        user.last_name,
        ...getPeerActiveUsernames(user)
      ].filter(Boolean).join(' '));
      return words.every((word) => haystack.includes(word));
    });
  });

  // The «Поиск» tab uses Web K's existing contacts search index. This keeps
  // the same account data and sorting as the header search without inventing
  // a second user cache.
  const [searchResults] = createResource(
    () => tab() === 'search' ? query().trim() : '',
    async(text) => {
      if(!text) return [] as PeerId[];
      try {
        if(text.startsWith('@')) {
          const username = text.slice(1).trim();
          if(!username) return [];
          const user = await rootScope.managers.appUsersManager.resolveUserByUsername(username);
          return user ? [user.id.toPeerId(false)] : [];
        }
        return await rootScope.managers.appUsersManager.getContactsPeerIds(text, false, 'name');
      } catch(err) {
        console.error('VKgram: failed to search accounts', err);
        return [];
      }
    }
  );

  const searchFiltered = createMemo(() => {
    if(tab() !== 'search') return [];
    return searchResults() ?? [];
  });

  const list = createIncrementalList({
    total: () => tab() === 'search' ? searchFiltered().length : (filtered()?.length ?? 0),
    resetKey: () => `${tab()}:${query()}`
  });
  const visible = createMemo(() => {
    const source = tab() === 'search' ? searchFiltered() : (filtered() ?? []);
    return source.slice(0, list.count());
  });

  return (
    <div class="vk-page vk-friends">
      <div class="vk-friends-layout">
        <main class="vk-friends-main">
          <section class="vk-block vk-page-block" aria-labelledby="vk-friends-title">
            <h1 id="vk-friends-title" class="vk-page-title">
              Друзья
              <Show when={tab() === 'all-chats' ? allDialogs() : peerIds()}>
                <span class="vk-page-text-secondary vk-list-count"> {(tab() === 'all-chats' ? allDialogs().length : peerIds().length)}</span>
              </Show>
            </h1>

            <Show when={!isDesktop()}>
              <VKTabs
                tabs={tabs()}
                active={tab()}
                onChange={setTab}
                idPrefix="vk-friends-mobile"
                label="Разделы"
              />
            </Show>

            <VKSearchField
              value={query()}
              placeholder={tab() === 'search' ? 'Поиск аккаунтов' : tab() === 'all-chats' ? 'Поиск людей в чатах' : 'Поиск друзей'}
              onInput={setQuery}
            />

            <Show
              when={tab() !== 'search' ? filtered() : searchResults()}
              fallback={<p class="vk-page-text vk-page-text-secondary vk-list-empty">Загрузка…</p>}
            >
              <Show
                when={visible().length}
                fallback={
                  <p class="vk-page-text vk-page-text-secondary vk-list-empty">
                    {tab() === 'search' && !query().trim() ?
                      'Введите имя или @username, чтобы найти аккаунт.' :
                      query().trim() ? 'Ничего не найдено.' :
                      tab() === 'all-chats' ? 'Личных чатов пока нет.' :
                      tab() !== 'contacts' ? 'В этой папке нет контактов.' :
                      'В вашем списке контактов пока никого нет.'}
                  </p>
                }
              >
                <ul class="vk-peer-list">
                  <For each={visible()}>
                    {(peerId) => tab() === 'all-chats' ? <ChatRow peerId={peerId} /> : <FriendRow peerId={peerId} />}
                  </For>
                </ul>
                <div ref={list.setSentinel} class="vk-list-sentinel" />
              </Show>
            </Show>
          </section>
        </main>

        <Show when={isDesktop()}>
          <aside class="vk-friends-side" aria-label="Навигация по друзьям">
            <section class="vk-block vk-friends-side-block">
              <VKTabs
                tabs={tabs()}
                active={tab()}
                onChange={setTab}
                idPrefix="vk-friends-desktop"
                label="Разделы"
              />
            </section>
          </aside>
        </Show>
      </div>
    </div>
  );
}

function ChatRow(props: {peerId: PeerId}) {
  const peers = usePeers();
  const peer = () => peers[props.peerId] as User.user | Chat.chat | Chat.channel;
  const title = () => {
    const value = peer();
    if(!value) return '';
    if(value._ === 'user') {
      if(value.pFlags.deleted) return 'Удалённый аккаунт';
      return [value.first_name, value.last_name].filter(Boolean).join(' ');
    }
    return value.title || 'Чат';
  };
  const username = () => {
    const value = peer();
    return value?._ === 'user' ? getPeerActiveUsernames(value)[0] : undefined;
  };

  return (
    <li class="vk-peer-row">
      <button
        type="button"
        class="vk-peer-avatar"
        tabindex="-1"
        aria-hidden="true"
        onClick={() => openWebKChat(props.peerId)}
      >
        <AvatarNewTsx peerId={props.peerId} size={AVATAR_SIZE} />
      </button>

      <div class="vk-peer-info">
        <button type="button" class="vk-link-button vk-peer-name" onClick={() => openWebKChat(props.peerId)}>
          {title()}
        </button>
        <Show when={username()}>
          <div class="vk-peer-sub vk-page-text-secondary">@{username()}</div>
        </Show>
      </div>

      <div class="vk-peer-actions">
        <button type="button" class="vk-link-button" onClick={() => openWebKChat(props.peerId)}>
          Открыть чат
        </button>
      </div>
    </li>
  );
}

function FriendRow(props: {peerId: PeerId}) {
  const peers = usePeers();
  const user = () => peers[props.peerId] as User.user;
  const name = () => {
    const value = user();
    if(!value) return '';
    if(value.pFlags.deleted) return 'Удалённый аккаунт';
    return [value.first_name, value.last_name].filter(Boolean).join(' ');
  };
  const username = () => getPeerActiveUsernames(user())[0];

  return (
    <li class="vk-peer-row">
      <button
        type="button"
        class="vk-peer-avatar"
        tabindex="-1"
        aria-hidden="true"
        onClick={() => openVKProfile(props.peerId)}
      >
        <AvatarNewTsx peerId={props.peerId} size={AVATAR_SIZE} />
      </button>

      <div class="vk-peer-info">
        <button type="button" class="vk-link-button vk-peer-name" onClick={() => openVKProfile(props.peerId)}>
          {name()}
        </button>
        <Show when={username()}>
          <div class="vk-peer-sub vk-page-text-secondary">@{username()}</div>
        </Show>
      </div>

      <div class="vk-peer-actions">
        <button type="button" class="vk-link-button" onClick={() => openWebKChat(props.peerId)}>
          Написать сообщение
        </button>
      </div>
    </li>
  );
}
