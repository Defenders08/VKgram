import {openVKSection} from '@/vkgram/sections';
import {setVKMessagePeer} from '@/vkgram/pages/messages/route';

/**
 * A chat with a user, a group or a bot — in VKgram's own «Сообщения», not in the Web K messenger
 * behind «Телеграм». The peer is stored first, so the page that mounts reads it as its open dialog
 * (the same value a `?vkgram=messages&peer=…` link carries); a «Сообщения» that is open already
 * follows the change by itself.
 *
 * NB: lives apart from `messages/route.ts`, which must not import sections.ts.
 */
export function openVKChat(peerId: PeerId) {
  setVKMessagePeer(peerId);
  openVKSection('messages');
}
