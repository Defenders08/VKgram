import VKPagePlaceholder from '@/vkgram/pages/VKPagePlaceholder';

export default function VKPageApps() {
  return (
    <VKPagePlaceholder
      section="apps"
      description="Здесь будет каталог приложений."
    />
  );
}
