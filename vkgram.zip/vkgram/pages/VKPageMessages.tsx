import {createEffect, createMemo, createResource, createSignal, For, on, onCleanup, onMount, Show} from 'solid-js';
import type {Chat, Message, User} from '@layer';
import rootScope from '@lib/rootScope';
import {usePeers} from '@stores/peers';
import {render} from 'solid-js/web';
import {createStore} from 'solid-js/store';
import {AvatarNewTsx} from '@components/avatarNew';
import {formatDateAccordingToTodayNew} from '@helpers/date';
import createListenerSetter from '@helpers/solid/createListenerSetter';
import getPeerActiveUsernames from '@appManagers/utils/peers/getPeerActiveUsernames';
import getDialogIndex from '@appManagers/utils/dialogs/getDialogIndex';
import {FOLDER_ID_ALL, FOLDER_ID_ARCHIVE, NULL_PEER_ID} from '@appManagers/constants';
import type {Dialog} from '@appManagers/appMessagesManager';
import removeAccents from '@helpers/string/removeAccents';
import appNavigationController, {NavigationItem} from '@components/appNavigationController';
import VKSearchField from '@/vkgram/components/VKSearchField';
import VKTabs, {VKTabItem} from '@/vkgram/components/VKTabs';
import VKIcon from '@/vkgram/components/VKIcons';
import useChannelFolders from '@/vkgram/hooks/useChannelFolders';
import createMutedPeers from '@/vkgram/hooks/createMutedPeers';
import {canPostToChannel, fetchFolder, isBroadcastChannel, isSubscribedChannel} from '@/vkgram/hooks/useSubscribedChannels';
import createChannelHistory from '@/vkgram/pages/channel/createChannelHistory';
import getDialogLastMessage from '@/vkgram/utils/getDialogLastMessage';
import type {ButtonMenuItemOptionsVerifiable} from '@components/buttonMenu';
import createContextMenu from '@helpers/dom/createContextMenu';
import {copyTextToClipboard} from '@helpers/clipboard';
import {openVKProfile} from '@/vkgram/pages/profile/openProfile';
import {vkMessagePeerId, setVKMessagePeer, setVKMessagesBack} from '@/vkgram/pages/messages/route';
import {vkMessagesSettings} from '@/vkgram/pages/messages/settings';
import VKMessagesSettings from '@/vkgram/pages/messages/VKMessagesSettings';
import MessageRenderer from '@/vkgram/components/MessageRenderer';
import VKComposer, {type ComposerReply} from '@/vkgram/components/VKComposer';

const AVATAR_SIZE = 46;
const ALL_TAB = 'all';
const PERSONAL_TAB = 'personal';
const ARCHIVE_TAB = 'archive';

const MONTHS_RU = [
  'января', 'февраля', 'марта', 'апреля', 'мая', 'июня',
  'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'
];

function formatDateSeparatorLabel(date: Date): string {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const yesterday = new Date(today.getTime() - 86400000);
  const msgDay = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  if(+msgDay === +today) return 'Сегодня';
  if(+msgDay === +yesterday) return 'Вчера';
  const day = date.getDate();
  const month = MONTHS_RU[date.getMonth()];
  return date.getFullYear() === now.getFullYear()
    ? `${day} ${month}`
    : `${day} ${month} ${date.getFullYear()}`;
}

type MessageTab = string;

type ChatItem =
  | {kind: 'separator', key: string, label: string}
  | {kind: 'message', key: string, message: Message.message, album?: Message.message[], isGrouped: boolean};

const normalize = (text: string) => removeAccents(text).toLowerCase();

function peerTitle(peer: User.user | Chat.chat | Chat.channel | undefined) {
  if(!peer) return '';
  if(peer._ === 'user') {
    if(peer.pFlags?.deleted) return 'Удалённый аккаунт';
    return [peer.first_name, peer.last_name].filter(Boolean).join(' ') || 'Пользователь';
  }
  return peer.title || 'Чат';
}

function peerSubtitle(peer: User.user | Chat.chat | Chat.channel | undefined) {
  if(!peer) return '';
  if(peer._ === 'user') {
    const username = getPeerActiveUsernames(peer)[0];
    return username ? `@${username}` : '';
  }
  if(peer._ === 'channel') return peer.pFlags?.megagroup ? 'Группа' : 'Канал';
  return 'Групповой чат';
}

/**
 * Полностью самостоятельная страница «Сообщения» VKgram.
 *
 * Здесь нет .page-chats, sidebar-left, chat-container и другой разметки Web K.
 * Web K используется только как источник данных через managers/storage.
 *
 * Левая колонка: поиск → папки → список диалогов.
 * Правая колонка: собственная шапка диалога → собственная история → собственный composer.
 *
 * URL: ?vkgram=messages&peer=<peerId> — прямая ссылка на диалог.
 * Мобильный режим: левая / правая колонка переключаются; браузерная кнопка
 * «Назад» возвращает в список диалогов.
 *
 * Каналы (broadcast) относятся к разделу «Каналы»; здесь только те, в которые можно писать
 * (создатель / админ с правом публикации). Их можно скрыть в «Настройках диалогов».
 */
export default function VKPageMessages() {
  const peers = usePeers();
  const folders = useChannelFolders();
  const listenerSetter = createListenerSetter();

  const [dialogs, setDialogs] = createSignal<Dialog[]>([]);
  const [archiveDialogs, setArchiveDialogs] = createSignal<Dialog[]>([]);
  const [query, setQuery] = createSignal('');
  const [tab, setTab] = createSignal<MessageTab>(ALL_TAB);
  // Initialise from the URL so a direct link / page refresh restores the chat.
  const [selectedPeerId, setSelectedPeerId] = createSignal<PeerId>(
    vkMessagePeerId() ?? NULL_PEER_ID
  );
  // the post whose comments are open in the «миничат» (instead of the dialog); a different dialog closes it
  const [commentsPost, setCommentsPost] = createSignal<Message.message[]>();
  const [isReady, setReady] = createSignal(false);
  const [isDesktop, setIsDesktop] = createSignal(true);
  // «Настройки диалогов»: only one of the desktop / mobile layouts is mounted at a time
  const [isSettingsOpen, setSettingsOpen] = createSignal(false);
  // bumped for a peer when its notification settings change (mute state)
  const [notifyVersions, setNotifyVersions] = createStore<{[peerId: PeerId]: number}>({});
  // On mobile: has the user explicitly opened a chat (vs auto-selection)?
  const [mobileShowChat, setMobileShowChat] = createSignal(
    // A direct link (?peer=xxx) counts as an intentional open.
    vkMessagePeerId() !== undefined
  );

  let alive = true;
  let reloadTimer: number | undefined;
  let loadToken = 0;
  // Mobile navigation stack item: browser Back → return to dialog list.
  let mobileNavItem: NavigationItem | undefined;

  // Keep the URL in sync whenever the selected peer changes.
  createEffect(() => {
    const peerId = selectedPeerId();
    setVKMessagePeer(peerId !== NULL_PEER_ID ? peerId : undefined);
  });

  createEffect(on(selectedPeerId, () => setCommentsPost(undefined), {defer: true}));

  // When no peer is selected any more, also reset the mobile view flag.
  createEffect(() => {
    if(selectedPeerId() === NULL_PEER_ID) setMobileShowChat(false);
  });

  const loadDialogs = async() => {
    const token = ++loadToken;
    try {
      const [all, archive] = await Promise.all([
        fetchFolder(FOLDER_ID_ALL, () => alive),
        fetchFolder(FOLDER_ID_ARCHIVE, () => alive)
      ]);
      if(!alive || token !== loadToken) return;
      setDialogs(all);
      setArchiveDialogs(archive);
      setReady(true);

      const current = selectedPeerId();
      const available = new Set([...all, ...archive].map((dialog) => dialog.peerId));
      if(!current || current === NULL_PEER_ID || !available.has(current)) {
        // the list comes first: a dialog stays unselected until it is opened
        if(current && current !== NULL_PEER_ID) setSelectedPeerId(NULL_PEER_ID);
      }
    } catch(err) {
      console.error('VKgram: failed to load messages dialogs', err);
      if(alive && token === loadToken) setReady(true);
    }
  };

  const scheduleReload = () => {
    window.clearTimeout(reloadTimer);
    reloadTimer = window.setTimeout(() => {
      void loadDialogs();
    }, 0);
  };

  onMount(() => {
    const media = window.matchMedia('(min-width: 601px)');
    const update = () => setIsDesktop(media.matches);
    update();
    media.addEventListener?.('change', update);
    loadDialogs();

    listenerSetter.add(rootScope)('dialogs_multiupdate', scheduleReload);
    listenerSetter.add(rootScope)('dialog_flush', scheduleReload);
    listenerSetter.add(rootScope)('dialog_unread', scheduleReload);
    listenerSetter.add(rootScope)('dialog_drop', scheduleReload);
    listenerSetter.add(rootScope)('dialog_notify_settings', (dialog) => {
      setNotifyVersions(dialog.peerId, (version) => (version || 0) + 1);
    });

    onCleanup(() => media.removeEventListener?.('change', update));
  });

  onCleanup(() => {
    alive = false;
    loadToken++;
    window.clearTimeout(reloadTimer);
    listenerSetter.removeAll();
    // Drop the mobile nav reference so the orphaned onPop does nothing.
    mobileNavItem = undefined;
  });

  // ── Dialog selection ────────────────────────────────────────────────────────

  /**
   * Select a dialog.  On mobile, also switches to the chat panel and pushes a
   * browser history entry so the Back button returns to the list.
   */
  const selectDialog = (peerId: PeerId) => {
    // Drop the previous nav item (if switching between chats directly).
    if(mobileNavItem) {
      // Clear the reference first so its onPop guard fails and does not reset
      // selectedPeerId while we are about to set it to the new value.
      const old = mobileNavItem;
      mobileNavItem = undefined;
      appNavigationController.backByItem(old);
    }

    setSelectedPeerId(peerId);
    setMobileShowChat(true);

    if(peerId !== NULL_PEER_ID) {
      const item: NavigationItem = {
        type: 'vkgram-section',
        onPop: () => {
          if(mobileNavItem !== item) return;
          mobileNavItem = undefined;
          if(alive) {
            setSelectedPeerId(NULL_PEER_ID);
            setMobileShowChat(false);
          }
        },
        onEscape: () => false
      };
      mobileNavItem = item;
      appNavigationController.pushItem(item);
    }
  };

  /**
   * Return to the dialog list on mobile (the «←» button or the browser Back).
   */
  const closeMobileChat = () => {
    if(mobileNavItem) {
      appNavigationController.backByItem(mobileNavItem);
    } else {
      setSelectedPeerId(NULL_PEER_ID);
      setMobileShowChat(false);
    }
  };

  // ── Folders / tabs ──────────────────────────────────────────────────────────

  const folderTabs = createMemo<VKTabItem<string>[]>(() => [
    {id: ALL_TAB, title: 'Все'},
    {id: PERSONAL_TAB, title: 'Личное'},
    ...folders.folders().map((folder) => ({id: String(folder.id), title: folder.title})),
    {id: ARCHIVE_TAB, title: 'Архив'}
  ]);

  createEffect(() => {
    if(folders.isReady() && !folderTabs().some((item) => item.id === tab())) setTab(ALL_TAB);
  });

  // Every dialog that can be in the list: the archive too (the filters decide). Broadcast channels
  // belong to «Каналы» — except those the user can write to (owner / admin who may post): they
  // are in «Сообщения», and «Скрыть каналы» takes them out.
  const isListDialog = (dialog: Dialog) => {
    const peer = peers[dialog.peerId];
    return !isSubscribedChannel(peer) || canPostToChannel(peer);
  };
  const isChannelDialog = (dialog: Dialog) => isSubscribedChannel(peers[dialog.peerId]);
  const allDialogs = createMemo(() => [...dialogs(), ...archiveDialogs()].filter(isListDialog));

  // Which of them are muted: Web K's own answer, asked again when a peer's notify settings change.
  const muted = createMutedPeers({
    peerIds: () => allDialogs().map((dialog) => dialog.peerId),
    version: (peerId) => notifyVersions[peerId] || 0
  });
  // Until the mute state of the dialogs is known once, a list that leaves muted dialogs out is not
  // shown (it would flash them). Dialogs that come later are not waited for.
  const [isMutedKnown, setMutedKnown] = createSignal(false);
  createEffect(() => {
    if(isReady() && muted.isResolved()) setMutedKnown(true);
  });

  // the dialogs of the open tab before the filters
  const scopeDialogs = createMemo(() => {
    const current = tab();
    if(current === ARCHIVE_TAB) return archiveDialogs().filter(isListDialog);

    let list = allDialogs();
    if(current === PERSONAL_TAB) {
      list = list.filter((dialog) => {
        const peer = peers[dialog.peerId] as User.user | undefined;
        return peer?._ === 'user' && !peer.pFlags?.bot && !peer.pFlags?.deleted;
      });
    } else if(current !== ALL_TAB) {
      const folder = folders.folders().find((item) => String(item.id) === current);
      if(folder) list = list.filter((dialog) => folder.peerIds.has(dialog.peerId));
    }
    return list;
  });

  // «Все» is always filtered; the other tabs only when the settings say so; «Архив» never.
  const filtersApply = () => tab() !== ARCHIVE_TAB && (tab() === ALL_TAB || vkMessagesSettings().scope === 'all');

  // what the settings leave of the open tab's dialogs
  const ruledDialogs = createMemo(() => {
    let list = scopeDialogs();
    if(!filtersApply()) return list;

    const settings = vkMessagesSettings();
    if(settings.hideArchived) list = list.filter((dialog) => dialog.folder_id !== FOLDER_ID_ARCHIVE);
    // a dialog whose mute state is not known yet stays
    if(settings.hideMuted) list = list.filter((dialog) => muted.isMuted(dialog.peerId) !== true);
    if(settings.hideChannels) list = list.filter((dialog) => !isChannelDialog(dialog));
    return list;
  });

  // what each filter would take out of the open tab's dialogs (`muted` is undefined until Web K answered)
  const scopeStats = createMemo(() => {
    if(!isReady() || tab() === ARCHIVE_TAB) return undefined;
    const scope = scopeDialogs();
    return {
      archived: scope.filter((dialog) => dialog.folder_id === FOLDER_ID_ARCHIVE).length,
      channels: scope.filter(isChannelDialog).length,
      muted: muted.isResolved() ? scope.filter((dialog) => muted.isMuted(dialog.peerId) === true).length : undefined
    };
  });

  const isListReady = () => isReady() && (!filtersApply() || !vkMessagesSettings().hideMuted || isMutedKnown());

  const filteredDialogs = createMemo(() => {
    let list = ruledDialogs();

    const text = normalize(query().trim().replace(/^@/, ''));
    if(text) {
      const words = text.split(/\s+/).filter(Boolean);
      list = list.filter((dialog) => {
        const peer = peers[dialog.peerId] as User.user | Chat.chat | Chat.channel | undefined;
        if(!peer) return false;
        const haystack = normalize([
          peerTitle(peer),
          peerSubtitle(peer),
          ...(peer._ === 'user' ? getPeerActiveUsernames(peer) : [])
        ].filter(Boolean).join(' '));
        return words.every((word) => haystack.includes(word));
      });
    }

    return list.slice().sort((a, b) => {
      const pinA = !!a.pFlags?.pinned;
      const pinB = !!b.pFlags?.pinned;
      if(pinA !== pinB) return pinA ? -1 : 1;
      const dateA = a.topMessage?.date ?? 0;
      const dateB = b.topMessage?.date ?? 0;
      if(dateA !== dateB) return dateB - dateA;
      return (getDialogIndex(b) ?? 0) - (getDialogIndex(a) ?? 0);
    });
  });

  // the settings panel, in the desktop rail or in the mobile tabs
  const renderSettings = (id: string) => (
    <VKMessagesSettings
      id={id}
      isOpen={isSettingsOpen()}
      onOpenChange={setSettingsOpen}
      applies={filtersApply()}
      dialogCount={isListReady() && scopeStats() ? ruledDialogs().length : undefined}
      scopeCount={isListReady() && scopeStats() ? scopeDialogs().length : undefined}
      stats={scopeStats()}
    />
  );

  // The folders rail stays visible next to an open chat; picking a folder
  // brings the dialog list back so the result is actually shown.
  const selectTab = (id: MessageTab) => {
    setTab(id);
    if(chatOpen()) closeMobileChat();
  };

  const selectedDialog = createMemo(() => {
    const peerId = selectedPeerId();
    return [...dialogs(), ...archiveDialogs()].find((dialog) => dialog.peerId === peerId);
  });

  // The list and the chat take turns: an open chat replaces the search and the list.
  const chatOpen = () => mobileShowChat() && selectedPeerId() !== NULL_PEER_ID;

  // «← Чаты» lives in the header bar while a dialog (not its comments) is open
  createEffect(() => {
    const hasBack = selectedPeerId() !== NULL_PEER_ID && !!selectedDialog() && !commentsPost();
    setVKMessagesBack(hasBack ? () => closeMobileChat : undefined);
  });
  onCleanup(() => setVKMessagesBack(undefined));

  return (
    <div class="vk-page vk-messages-page">
      <div class="vk-messages-shell">
      <div class="vk-messages-layout" classList={{'is-chat-open': chatOpen()}}>
        <section class="vk-messages-left" aria-label="Список сообщений">
          <div class="vk-block vk-messages-search-block">
            <div class="vk-messages-search">
              <VKSearchField
                value={query()}
                placeholder="Поиск сообщений"
                onInput={setQuery}
              />
            </div>
          </div>

          <Show when={!isDesktop()}>
            <div class="vk-block vk-messages-tabs-block">
              <VKTabs
                tabs={folderTabs()}
                active={tab()}
                onChange={selectTab}
                idPrefix="vk-messages-mobile"
                label="Папки сообщений"
                actions={renderSettings('vk-messages-settings-mobile')}
              />
            </div>
          </Show>

          <div class="vk-block vk-messages-list-block">
            <div class="vk-messages-list" role="list">
              <Show when={isListReady()} fallback={<div class="vk-messages-empty">Загрузка сообщений…</div>}>
                <Show
                  when={filteredDialogs().length}
                  fallback={
                    <div class="vk-messages-empty">
                      {query() ? 'Ничего не найдено.' : 'Диалогов не найдено.'}
                      {/* the settings left every dialog of the tab out */}
                      <Show when={!query() && ruledDialogs().length === 0 && scopeDialogs().length > 0}>
                        <div>
                          Архивные, заглушённые диалоги и каналы не показываются, если так выбрано в настройках.{' '}
                          <button type="button" class="vk-link-button" onClick={() => setSettingsOpen(true)}>
                            Настройки диалогов
                          </button>
                        </div>
                      </Show>
                    </div>
                  }
                >
                  <For each={filteredDialogs()}>
                    {(dialog) => (
                      <MessageDialogRow
                        dialog={dialog}
                        active={selectedPeerId() === dialog.peerId}
                        muted={muted.isMuted(dialog.peerId) === true}
                        onSelect={() => selectDialog(dialog.peerId)}
                      />
                    )}
                  </For>
                </Show>
              </Show>
            </div>
          </div>
        </section>

        <section class="vk-block vk-messages-right" aria-label="Диалог">
          <Show
            when={selectedPeerId() !== NULL_PEER_ID && selectedDialog()}
            fallback={<div class="vk-messages-no-chat">Выберите диалог</div>}
          >
            <Show
              when={commentsPost()}
              keyed
              fallback={
                <VKMessagesChat
                  peerId={selectedPeerId()}
                  dialog={selectedDialog()}
                  onBack={closeMobileChat}
                  onOpenComments={setCommentsPost}
                />
              }
            >
              {(post) => <VKCommentsChat post={post} onBack={() => setCommentsPost(undefined)} />}
            </Show>
          </Show>
        </section>
      </div>

      <Show when={isDesktop()}>
        <aside class="vk-messages-side" aria-label="Папки сообщений">
          <section class="vk-block vk-messages-side-block">
            <VKTabs
              tabs={folderTabs()}
              active={tab()}
              onChange={selectTab}
              idPrefix="vk-messages-desktop"
              label="Папки сообщений"
              actions={renderSettings('vk-messages-settings-desktop')}
            />
          </section>
        </aside>
      </Show>
      </div>
    </div>
  );
}

// ── VKPeerAvatar ─────────────────────────────────────────────────────────────

function peerInitials(peer: User.user | Chat.chat | Chat.channel | undefined) {
  const title = peerTitle(peer).trim();
  const words = title.split(/\s+/).filter(Boolean);
  return (words.length > 1 ? words.slice(0, 2).map((word) => word[0]) : [title[0] || '?'])
    .join('')
    .toUpperCase();
}

function VKPeerAvatar(props: {peerId: PeerId, peer?: User.user | Chat.chat | Chat.channel, size: number}) {
  let root!: HTMLSpanElement;
  const [showFallback, setShowFallback] = createSignal(false);

  const handleImageError = (event: Event) => {
    const target = event.target;
    if(target instanceof HTMLImageElement) setShowFallback(true);
  };

  const handleImageLoad = (event: Event) => {
    const target = event.target;
    if(target instanceof HTMLImageElement) setShowFallback(false);
  };

  onMount(() => {
    root.addEventListener('error', handleImageError, true);
    root.addEventListener('load', handleImageLoad, true);

    const image = root.querySelector('img');
    if(image?.complete && image.naturalWidth === 0) setShowFallback(true);
  });

  onCleanup(() => {
    root.removeEventListener('error', handleImageError, true);
    root.removeEventListener('load', handleImageLoad, true);
  });

  return (
    <span
      ref={root}
      class="vk-peer-avatar"
      classList={{'has-fallback': showFallback()}}
      style={{width: `${props.size}px`, height: `${props.size}px`}}
    >
      <AvatarNewTsx peerId={props.peerId} size={props.size} />
      <Show when={showFallback()}>
        <span class="vk-peer-avatar-fallback" aria-hidden="true">{peerInitials(props.peer)}</span>
      </Show>
    </span>
  );
}

// ── Dialog context menu ───────────────────────────────────────────────────────

function createDialogContextMenu(options: {
  element: HTMLElement,
  dialog: Dialog
}) {
  const managers = rootScope.managers;
  const dialog = options.dialog;
  const peerId = dialog.peerId;

  const buttons: ButtonMenuItemOptionsVerifiable[] = [{
    icon: 'unread',
    regularText: 'Пометить непрочитанным',
    onClick: () => managers.appMessagesManager.markDialogUnread({peerId}),
    verify: () => !dialog.unread_count
  }, {
    icon: 'readchats',
    regularText: 'Пометить прочитанным',
    onClick: () => managers.appMessagesManager.readHistory({peerId}),
    verify: () => !!dialog.unread_count
  }, {
    icon: 'pin',
    regularText: 'Закрепить',
    onClick: () => managers.appMessagesManager.toggleDialogPin({peerId, filterId: FOLDER_ID_ALL}),
    verify: () => !dialog.pFlags?.pinned
  }, {
    icon: 'unpin',
    regularText: 'Открепить',
    onClick: () => managers.appMessagesManager.toggleDialogPin({peerId, filterId: FOLDER_ID_ALL}),
    verify: () => !!dialog.pFlags?.pinned
  }, {
    icon: dialog.folder_id ? 'archive' : 'unarchive',
    regularText: dialog.folder_id ? 'Вернуть из архива' : 'В архив',
    onClick: () => managers.appMessagesManager.editPeerFolders([peerId], dialog.folder_id ? FOLDER_ID_ALL : FOLDER_ID_ARCHIVE)
  }];

  return createContextMenu({
    buttons,
    listenTo: options.element,
    findElement: () => options.element
  });
}

// ── MessageDialogRow ──────────────────────────────────────────────────────────

function MessageDialogRow(props: {
  dialog: Dialog,
  active: boolean,
  muted: boolean,
  onSelect: () => void
}) {
  const peers = usePeers();
  const peer = () => peers[props.dialog.peerId] as User.user | Chat.chat | Chat.channel | undefined;
  const unread = () => props.dialog.unread_count || 0;
  const pinned = () => !!props.dialog.pFlags?.pinned;
  const lastMessage = createMemo(() => getDialogLastMessage(props.dialog));
  const previewText = createMemo(() => {
    const message = lastMessage();
    if(!message || message._ === 'messageService') return '';
    return (message.message || '').replace(/\s+/g, ' ').trim();
  });
  const previewTime = createMemo(() => {
    const message = lastMessage();
    return message?.date ? formatDateAccordingToTodayNew(new Date(message.date * 1000)) : '';
  });
  let row!: HTMLButtonElement;
  let menu: ReturnType<typeof createDialogContextMenu> | undefined;

  onMount(() => {
    menu = createDialogContextMenu({element: row, dialog: props.dialog});
  });
  onCleanup(() => menu?.destroy());

  return (
    <button
      ref={row}
      type="button"
      class="vk-message-dialog"
      classList={{'is-active': props.active}}
      role="listitem"
      onClick={props.onSelect}
    >
      <span class="vk-message-dialog-avatar">
        <VKPeerAvatar peerId={props.dialog.peerId} peer={peer()} size={AVATAR_SIZE} />
      </span>

      <span class="vk-message-dialog-main">
        <strong class="vk-message-dialog-title">{peerTitle(peer())}</strong>
        <span class="vk-message-dialog-preview">
          <Show when={previewText()} fallback="Нет сообщений">{previewText()}</Show>
        </span>
      </span>

      {/* the right column: the time on the title's line, the badges on the preview's line */}
      <span class="vk-message-dialog-meta">
        <time class="vk-message-dialog-time">{previewTime()}</time>
        <span class="vk-message-dialog-badges">
          <Show when={unread() > 0}>
            <span class="vk-message-dialog-unread" classList={{'is-muted': props.muted}}>{unread()}</span>
          </Show>
          <Show when={pinned()}>
            <span class="vk-message-dialog-pin" aria-label="Закреплено">📌</span>
          </Show>
        </span>
      </span>
    </button>
  );
}

// ── VKDateSeparator ───────────────────────────────────────────────────────────

function VKDateSeparator(props: {label: string}) {
  return (
    <div class="vk-date-separator" role="separator" aria-label={props.label}>
      <span class="vk-date-separator-label">{props.label}</span>
    </div>
  );
}

// ── VKMessagesChat ────────────────────────────────────────────────────────────

type CommentsThread = {
  // the thread id: the mid of the discussion message in the discussion group
  id: number,
  // the channel post the comments belong to (an album: all its messages)
  post: Message.message[],
  channelPeerId: PeerId,
  repliesCount?: number
};

const pluralRu = (n: number, one: string, few: string, many: string) => {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if(mod10 === 1 && mod100 !== 11) return one;
  if(mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return few;
  return many;
};

/** Web K's own media viewer, the same search context for a chat and for the post at the top of a thread. */
async function openMediaViewer(message: Message.message, target?: HTMLElement) {
  const {default: AppMediaViewer} = await import('@components/mediaViewer');
  new AppMediaViewer()
  .setSearchContext({
    peerId: message.peerId,
    inputFilter: {_: 'inputMessagesFilterPhotoVideo'},
    useSearch: true
  })
  .openMedia({message, target});
}

/**
 * The composer of a comments thread. Writing is allowed by the rights in the discussion group:
 * a member writes, someone who has left gets «Вступить», otherwise the form is replaced by a note.
 */
function VKThreadComposer(props: {
  peerId: PeerId,
  threadId: number,
  reply?: ComposerReply,
  editing?: Message.message,
  onCancelReply: () => void,
  onCancelEdit: () => void,
  onSent: () => void
}) {
  const peers = usePeers();
  const group = () => peers[props.peerId] as Chat.channel | undefined;
  const [canWrite, {refetch}] = createResource(async() => {
    try {
      return await rootScope.managers.appMessagesManager.canSendToPeer(props.peerId, props.threadId);
    } catch(err) {
      return false;
    }
  });
  const [isJoining, setJoining] = createSignal(false);
  const join = async() => {
    setJoining(true);
    try {
      await rootScope.managers.appChatsManager.joinChannel(props.peerId.toChatId());
      await refetch();
    } catch(err) {
      console.error('VKgram: joinChannel failed', err);
    } finally {
      setJoining(false);
    }
  };

  return (
    <Show when={!canWrite.loading}>
      <Show
        when={canWrite()}
        fallback={
          <div class="vk-comments-chat-note">
            <Show
              when={group()?.pFlags?.left}
              fallback={<span>Писать комментарии здесь нельзя.</span>}
            >
              <button type="button" class="vk-button vk-button-secondary" disabled={isJoining()} onClick={join}>
                {isJoining() ? 'Вступаем…' : 'Вступить в обсуждение, чтобы комментировать'}
              </button>
            </Show>
          </div>
        }
      >
        <VKComposer
          peerId={props.peerId}
          threadId={props.threadId}
          reply={props.reply}
          editing={props.editing}
          onCancelReply={props.onCancelReply}
          onCancelEdit={props.onCancelEdit}
          onSent={props.onSent}
        />
      </Show>
    </Show>
  );
}

/**
 * The «миничат» of a channel post — what Telegram opens on «Комментарии»: the thread of the
 * post's discussion message, in the discussion group. The discussion message comes from
 * `getDiscussionMessage` (its mid is the thread id); the chat itself is the usual one in thread mode.
 */
function VKCommentsChat(props: {post: Message.message[], onBack: () => void}) {
  const main = props.post.find((message) => message.replies?.pFlags?.comments) ?? props.post[0];
  const [root] = createResource(async() => {
    try {
      return await rootScope.managers.appMessagesManager.getDiscussionMessage(main.peerId, main.mid) as Message.message | undefined;
    } catch(err) {
      console.error('VKgram: getDiscussionMessage failed', err);
    }
  });

  return (
    <Show
      when={root()}
      fallback={
        <div class="vk-custom-chat">
          <header class="vk-custom-chat-header">
            <button type="button" class="vk-custom-chat-back" aria-label="Назад к посту" onClick={props.onBack}>
              <VKIcon name="back" size={16} />
              <span>Назад</span>
            </button>
            <div class="vk-custom-chat-header-info">
              <div class="vk-custom-chat-title">Комментарии</div>
            </div>
          </header>
          <div class="vk-custom-chat-history">
            <div class="vk-custom-chat-loading">
              {root.loading ? 'Загрузка комментариев…' : 'Комментарии недоступны.'}
            </div>
          </div>
        </div>
      }
    >
      {(discussion) => (
        <VKMessagesChat
          peerId={discussion().peerId}
          onBack={props.onBack}
          thread={{
            id: discussion().mid,
            post: props.post,
            channelPeerId: main.peerId,
            repliesCount: main.replies?.pFlags?.comments ? main.replies.replies : undefined
          }}
        />
      )}
    </Show>
  );
}

function VKMessagesChat(props: {
  peerId: PeerId,
  dialog?: Dialog,
  onBack: () => void,
  // the dialog's chat opens a comments thread (a channel post's «Комментарии»)
  onOpenComments?: (post: Message.message[]) => void,
  // set: the chat is the comments thread of a post (`peerId` is the discussion group)
  thread?: CommentsThread
}) {
  const peers = usePeers();
  const peer = () => peers[props.peerId] as User.user | Chat.chat | Chat.channel | undefined;
  const history = createChannelHistory({peerId: () => props.peerId, threadId: props.thread?.id, pageSize: 40});
  const channel = () => props.thread ? peers[props.thread.channelPeerId] as Chat.channel | undefined : undefined;
  // the discussion message itself is the post (shown on top), not a comment
  const comments = createMemo(() => history.messages().filter((message) => message.mid !== props.thread?.id));
  const commentsTotal = () => history.isEnd() ? comments().length : (props.thread?.repliesCount ?? comments().length);
  const commentsTitle = () => {
    const total = commentsTotal();
    return total ? `${total} ${pluralRu(total, 'комментарий', 'комментария', 'комментариев')}` : 'Комментарии';
  };

  let scrollEl!: HTMLDivElement;
  const [replyTo, setReplyTo] = createSignal<ComposerReply>();
  const [editing, setEditing] = createSignal<Message.message>();

  // reply / edit belong to the dialog they were started in
  createEffect(on(() => props.peerId, () => {
    setReplyTo(undefined);
    setEditing(undefined);
  }, {defer: true}));

  const startReply = (message: Message.message) => {
    const isChannel = isBroadcastChannel(peers[message.peerId]);
    const outgoing = !!message.pFlags?.out && !isChannel;
    const sender = peers[(isChannel ? message.peerId : (message.fromId ?? message.peerId)) as PeerId] as User.user | Chat.chat | Chat.channel | undefined;
    setEditing(undefined);
    setReplyTo({
      mid: message.mid,
      author: outgoing ? 'Вы' : peerTitle(sender),
      text: message.message || (message.media ? 'Вложение' : '')
    });
  };

  const startEdit = (message: Message.message) => {
    setReplyTo(undefined);
    setEditing(message);
  };

  const onSent = () => {
    // force scroll to the bottom after sending
    requestAnimationFrame(() => {
      if(scrollEl) scrollEl.scrollTop = scrollEl.scrollHeight;
    });
  };

  // Smart scroll state (mutable, not reactive — used only in effects/handlers).
  let loadMoreScrollHeight = 0;
  let isLoadMorePending = false;
  let prevMessageCount = 0;

  const isNearBottom = () => {
    if(!scrollEl) return true;
    return scrollEl.scrollHeight - scrollEl.scrollTop - scrollEl.clientHeight < 200;
  };

  // Compute a flat list of date separators + messages with grouping info.
  const chatItems = createMemo<ChatItem[]>(() => {
    const msgs = comments().slice().reverse(); // oldest first
    const items: ChatItem[] = [];
    let prevDateKey = '';
    let prevSenderId: PeerId | null = null;
    let prevTime = 0;

    for(let i = 0; i < msgs.length; ++i) {
      const message = msgs[i];

      // an album is several messages with one grouped_id: one row, one grid
      let album: Message.message[] | undefined;
      const groupedId = message.grouped_id;
      if(groupedId) {
        const group = [message];
        while(i + 1 < msgs.length && msgs[i + 1].grouped_id === groupedId) group.push(msgs[++i]);
        if(group.length > 1) album = group;
      }

      const date = new Date(message.date * 1000);
      const dateKey = `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;

      if(dateKey !== prevDateKey) {
        items.push({kind: 'separator', key: `sep-${dateKey}`, label: formatDateSeparatorLabel(date)});
        prevDateKey = dateKey;
        prevSenderId = null;
        prevTime = 0;
      }

      const senderId = (message.fromId ?? message.peerId) as PeerId;
      // Group with previous when same sender and within 5 minutes.
      const isGrouped = senderId === prevSenderId && (message.date - prevTime) < 300;

      items.push({kind: 'message', key: String(message.mid), message, album, isGrouped});

      prevSenderId = senderId;
      prevTime = message.date;
    }

    return items;
  });

  // Smart scroll: restore position after load-more; scroll to bottom otherwise.
  createEffect(() => {
    const count = history.messages().length;
    const loadingMore = history.isLoadingMore();
    const status = history.status();

    // Reset tracking when the peer changes (history resets to empty).
    if(count === 0) {
      isLoadMorePending = false;
      loadMoreScrollHeight = 0;
      prevMessageCount = 0;
      return;
    }

    requestAnimationFrame(() => {
      if(!scrollEl) return;

      if(isLoadMorePending && !loadingMore) {
        // Load-more completed — restore the scroll position by compensating for
        // the newly prepended messages.
        const diff = scrollEl.scrollHeight - loadMoreScrollHeight;
        scrollEl.scrollTop = diff > 0 ? diff : 0;
        isLoadMorePending = false;
        loadMoreScrollHeight = 0;
      } else if(!isLoadMorePending) {
        if(prevMessageCount === 0 || status === 'loading') {
          // Initial load — jump to the bottom.
          scrollEl.scrollTop = scrollEl.scrollHeight;
        } else if(isNearBottom()) {
          // New message arrived and user is already near the bottom.
          scrollEl.scrollTop = scrollEl.scrollHeight;
        }
      }

      prevMessageCount = count;
    });
  });

  const onScroll = () => {
    if(!scrollEl) return;
    if(scrollEl.scrollTop < 80 && !isLoadMorePending && history.status() === 'loaded' && !history.isEnd()) {
      loadMoreScrollHeight = scrollEl.scrollHeight;
      isLoadMorePending = true;
      history.loadMore();
    }
  };

  return (
    <div class="vk-custom-chat">
      <Show
        when={props.thread}
        fallback={
          <header class="vk-custom-chat-header">
            <button
              type="button"
              class="vk-custom-chat-avatar-button"
              aria-label={`Открыть страницу ${peerTitle(peer())}`}
              onClick={() => openVKProfile(props.peerId)}
            >
              <VKPeerAvatar peerId={props.peerId} peer={peer()} size={44} />
            </button>
            <button
              type="button"
              class="vk-custom-chat-header-info"
              onClick={() => openVKProfile(props.peerId)}
            >
              <div class="vk-custom-chat-title">{peerTitle(peer())}</div>
              <Show when={peerSubtitle(peer())}>
                <div class="vk-custom-chat-subtitle">{peerSubtitle(peer())}</div>
              </Show>
            </button>
          </header>
        }
      >
        {/* миничат комментариев: назад к каналу, «N комментариев», под ним — название канала */}
        <header class="vk-custom-chat-header">
          <button
            type="button"
            class="vk-custom-chat-back"
            aria-label="Назад к посту"
            onClick={props.onBack}
          >
            <VKIcon name="back" size={16} />
            <span>Назад</span>
          </button>

          <div class="vk-custom-chat-header-info">
            <div class="vk-custom-chat-title">{commentsTitle()}</div>
            <Show when={channel()}>
              <div class="vk-custom-chat-subtitle">{peerTitle(channel())}</div>
            </Show>
          </div>
        </header>
      </Show>

      <div class="vk-custom-chat-history" ref={scrollEl!} onScroll={onScroll}>
        <Show when={history.isLoadingMore()}>
          <div class="vk-custom-chat-loading">Загрузка…</div>
        </Show>

        <Show when={history.status() === 'loading' && !history.messages().length}>
          <div class="vk-custom-chat-loading">Загрузка сообщений…</div>
        </Show>

        <Show when={history.status() === 'error'}>
          <div class="vk-custom-chat-loading">
            Не удалось загрузить сообщения.{' '}
            <button type="button" class="vk-link-button" onClick={() => history.reload()}>Повторить</button>
          </div>
        </Show>

        <div class="vk-custom-chat-messages">
          {/* the post itself opens the thread, as in Telegram: it is the oldest message of it */}
          <Show when={props.thread && history.isEnd()}>
            <div class="vk-comments-chat-post">
              <MessageRenderer
                message={props.thread!.post}
                variant="chat-incoming"
                showAvatar
                showAuthor
                mediaBoxSize={320}
                onMediaClick={openMediaViewer}
              />
            </div>
          </Show>
          <Show when={props.thread && history.status() === 'loaded' && !comments().length}>
            <div class="vk-custom-chat-loading">Комментариев пока нет. Напишите первым.</div>
          </Show>
          <For each={chatItems()}>
            {(item) => item.kind === 'separator'
              ? <VKDateSeparator label={item.label} />
              : <VKMessageRow message={item.message} album={item.album} peerId={props.peerId} isGrouped={item.isGrouped} onReply={startReply} onEdit={startEdit} onOpenComments={props.onOpenComments} />
            }
          </For>
        </div>
      </div>

      <div class="vk-custom-chat-composer">
        <Show
          when={props.thread}
          fallback={
            <VKComposer
              peerId={props.peerId}
              reply={replyTo()}
              editing={editing()}
              onCancelReply={() => setReplyTo(undefined)}
              onCancelEdit={() => setEditing(undefined)}
              onSent={onSent}
            />
          }
        >
          <VKThreadComposer
            peerId={props.peerId}
            threadId={props.thread!.id}
            reply={replyTo()}
            editing={editing()}
            onCancelReply={() => setReplyTo(undefined)}
            onCancelEdit={() => setEditing(undefined)}
            onSent={onSent}
          />
        </Show>
      </div>
    </div>
  );
}

// ── VKMessageRow ──────────────────────────────────────────────────────────────

function VKMessageRow(props: {
  message: Message.message,
  album?: Message.message[],
  peerId: PeerId,
  isGrouped: boolean,
  onReply: (message: Message.message) => void,
  onEdit: (message: Message.message) => void,
  // «Комментарии» under a channel post: open its thread
  onOpenComments?: (post: Message.message[]) => void
}) {
  const peers = usePeers();
  // Posts of a channel are written by the channel, not by me: on the left like anyone else's,
  // as in Telegram — even if I am the one who posted them.
  const isChannel = () => isBroadcastChannel(peers[props.peerId]);
  const outgoing = () => !!props.message.pFlags?.out && !isChannel();

  /**
   * Opens Web K's own media viewer for chat messages.
   */
  const handleMediaClick = async(message: Message.message, target?: HTMLElement) => {
    const {default: AppMediaViewer} = await import('@components/mediaViewer');
    new AppMediaViewer()
    .setSearchContext({
      peerId: message.peerId,
      inputFilter: {_: 'inputMessagesFilterPhotoVideo'},
      useSearch: true
    })
    .openMedia({message, target});
  };

  return (
    <MessageRenderer
      message={props.album ?? props.message}
      variant={outgoing() ? 'chat-outgoing' : 'chat-incoming'}
      showReactions
      showComments={isChannel() && !!props.onOpenComments}
      onCommentsToggle={() => props.onOpenComments?.(props.album ?? [props.message])}
      showAvatar={!props.isGrouped}
      showAuthor={!props.isGrouped}
      grouped={props.isGrouped}
      mediaBoxSize={320}
      onMediaClick={handleMediaClick}
      contextMenu={{
        onCreate: (element) => {
          const managers = rootScope.managers;
          const message = props.album ? (props.album.find((m) => m.message) ?? props.album[0]) : props.message;

          const headerEl = document.createElement('div');

          const disposeReactions = render(() => {
            const [available] = createResource(async() => {
              try {
                const res = await managers.appReactionsManager.getAvailableReactionsByMessage(message);
                return res.reactions.filter((r: any) => r._ === 'reactionEmoji').slice(0, 6) as any[];
              } catch(err) {
                return [];
              }
            });

            return (
              <div class="vk-context-menu-reactions">
                <For each={available()}>
                  {(reaction) => (
                    <button
                      type="button"
                      class="vk-reaction-quick-btn"
                      onClick={() => {
                        managers.appReactionsManager.sendReaction({message, reaction});
                        document.dispatchEvent(new KeyboardEvent('keydown', {key: 'Escape'}));
                      }}
                    >
                      {reaction.emoticon}
                    </button>
                  )}
                </For>
              </div>
            );
          }, headerEl);

          const buttons: ButtonMenuItemOptionsVerifiable[] = [
            {
              icon: 'reply',
              regularText: 'Ответить',
              onClick: () => props.onReply(message),
              verify: () => true
            }, {
              icon: 'copy',
              regularText: 'Копировать текст',
              onClick: () => copyTextToClipboard(message.message || ''),
              verify: () => !!message.message
            }, {
              icon: 'link',
              regularText: 'Копировать ссылку',
              onClick: async() => {
                const username = await managers.appPeersManager.getPeerUsername(message.peerId);
                const url = username
                  ? `https://t.me/${username}/${message.mid}`
                  : `https://t.me/c/${message.peerId.toChatId()}/${message.mid}`;
                copyTextToClipboard(url);
              }
            }, {
              icon: 'edit',
              regularText: 'Редактировать',
              onClick: () => props.onEdit(message),
              verify: () => managers.appMessagesManager.canEditMessage(message, 'text')
            }, {
              icon: 'forward',
              regularText: 'Переслать',
              onClick: async() => {
                const {default: showForwardPopup} = await import('@components/popups/forward');
                showForwardPopup({[message.peerId]: [message.mid]});
              },
              verify: () => managers.appMessagesManager.canForward(message)
            }, {
              icon: 'flag',
              regularText: 'Пожаловаться',
              onClick: async() => {
                const {showMessageReport} = await import('@components/popups/reportAd');
                showMessageReport(message.peerId, [message.mid]);
              },
              verify: () => !message.pFlags?.out
            }, {
              icon: 'select',
              regularText: 'Выделить',
              onClick: async() => {
                const {default: appImManager} = await import('@lib/appImManager');
                await appImManager.setInnerPeer({peerId: message.peerId, lastMsgId: message.mid});
                const bubble = appImManager.chat?.bubbles?.getBubble(message.peerId, message.mid);
                if(bubble) appImManager.chat.selection.toggleByElement(bubble);
              }
            }, {
              icon: 'delete',
              className: 'danger',
              regularText: 'Удалить',
              onClick: async() => {
                const [{default: showDeleteMessagesPopup}, {ChatType}] = await Promise.all([
                  import('@components/popups/deleteMessages'),
                  import('@components/chat/chatType')
                ]);
                showDeleteMessagesPopup(message.peerId, [message.mid], ChatType.Chat);
              },
              verify: () => managers.appMessagesManager.canDeleteMessage(message)
            }
          ];

          const menu = createContextMenu({
            buttons,
            onElementReady: (menuEl) => menuEl.prepend(headerEl),
            listenTo: element,
            findElement: () => element
          });

          const originalDestroy = menu.destroy;
          menu.destroy = () => {
            disposeReactions();
            originalDestroy.call(menu);
          };

          return menu;
        }
      }}
    />
  );
}
