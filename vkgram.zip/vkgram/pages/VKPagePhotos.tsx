import VKMediaPage, {VKMediaList} from '@/vkgram/components/VKMediaBrowser';

/**
 * «Фотографии»: «Поиск» — the photos of all chats (Telegram's global search,
 * photos only) and «Избранное» — the photos kept in the saved messages.
 */
export default function VKPagePhotos() {
  return (
    <VKMediaPage
      section="photos"
      tabs={[
        {id: 'search', title: 'Поиск', render: () => <VKMediaList kind="photos" source="search" />},
        {id: 'saved', title: 'Избранное', render: () => <VKMediaList kind="photos" source="saved" />}
      ]}
    />
  );
}
