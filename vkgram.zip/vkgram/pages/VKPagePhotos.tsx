import VKPagePlaceholder from '@/vkgram/pages/VKPagePlaceholder';

export default function VKPagePhotos() {
  return (
    <VKPagePlaceholder
      section="photos"
      description="Здесь будут ваши фотографии."
    />
  );
}
