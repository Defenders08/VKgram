import {createEffect, createMemo, createSignal, For, Match, on, onCleanup, Show, Switch} from 'solid-js';
import {openVKSection} from '@/vkgram/sections';
import {openWebKFolderCreation} from '@/vkgram/webk';
import useSubscribedChannels from '@/vkgram/hooks/useSubscribedChannels';
import useChannelFolders from '@/vkgram/hooks/useChannelFolders';
import createNewsFeed, {VKNewsRules} from '@/vkgram/hooks/createNewsFeed';
import {vkNewsSettings} from '@/vkgram/pages/news/settings';
import VKNewsSettings from '@/vkgram/pages/news/VKNewsSettings';
import VKChannelPost from '@/vkgram/pages/channel/VKChannelPost';
import VKEmptyState from '@/vkgram/components/VKEmptyState';
import VKTabs, {VKTabItem} from '@/vkgram/components/VKTabs';

// the tab of the main feed; the others are the ids of the user's folders
const ALL_TAB = 'all';

const isSameSet = (a?: Set<PeerId>, b?: Set<PeerId>) => {
  if(a === b) return true;
  if(!a || !b || a.size !== b.size) return false;
  for(const value of a) if(!b.has(value)) return false;
  return true;
};

/**
 * «Новости» — the posts of the channels the user is subscribed to, newest
 * first, as one feed. The posts are the channel page's own (`VKChannelPost`:
 * channel avatar and name, text, media, date, reactions, comments); the feed
 * itself is `createNewsFeed`, which merges the channels' histories. Older
 * posts come as the end of the list comes near (an IntersectionObserver on a
 * sentinel — no scroll listeners).
 *
 * Tabs: «Все» — every channel — and one tab per chat folder of the user that
 * has channels (a folder without channels has no tab); a folder tab shows the
 * channels of that folder. «+» after the tabs opens Web K's own folder creation
 * popup (over this page, no section change); the new folder comes back through
 * Web K's `filter_update` event.
 * «Настройки ленты» (right of the tabs) says which channels the feed leaves
 * out — archived (by default), muted — and whether that is for «Все»
 * only or for the folders too (the default). The rules go into the feed's source: a channel that
 * is out is never read, not hidden afterwards.
 * When the filters take out most of the channels, the page says so and offers
 * «Показать все каналы»: the muted filter is switched off for this visit only
 * (the saved settings are not touched).
 */
export default function VKPageNews() {
  // «Все» is every channel of the user, in whatever folder: the folders are read too, none is missed
  const subscribed = useSubscribedChannels({customFolders: true});
  const folders = useChannelFolders();

  // the folders of the user, in the order of Web K's chat list (every one, with or without channels)
  const allFolders = () => folders.folders();
  // one tab per folder that has channels; a folder without any has no tab.
  // Only the folder itself counts (a folder whose channels are all archived or muted keeps its tab:
  // the filters may take them out, the folder still has them). Until the channels are read nothing
  // is known about the folders, so only «Все» is shown (no tabs that appear and vanish).
  const folderTabs = createMemo(() => {
    if(!subscribed.isReady()) return [];
    const channelPeerIds = new Set(subscribed.channels().map((dialog) => dialog.peerId));
    return allFolders().filter((folder) => {
      for(const peerId of folder.peerIds) if(channelPeerIds.has(peerId)) return true;
      return false;
    });
  }, undefined, {
    // dialogs change all the time; the tabs are rebuilt only when the set of folders with channels changes
    equals: (a, b) => a.length === b.length && a.every((folder, index) => folder === b[index])
  });
  const tabs = createMemo<VKTabItem<string>[]>(() => [
    {id: ALL_TAB, title: 'Все'},
    ...folderTabs().map((folder) => ({id: String(folder.id), title: folder.title}))
  ]);

  const [tab, setTab] = createSignal(ALL_TAB);
  // a folder that was deleted (or lost its last channel) under the open tab
  createEffect(() => {
    if(folders.isReady() && subscribed.isReady() && !tabs().some((item) => item.id === tab())) setTab(ALL_TAB);
  });

  const [isSettingsOpen, setSettingsOpen] = createSignal(false);

  // «Показать все каналы»: the muted filter is off for now; not saved, gone with the page
  const [isMutedShown, setMutedShown] = createSignal(false);
  // the user's own choice of the filter is a new start
  createEffect(on(() => vkNewsSettings().hideMuted, () => setMutedShown(false), {defer: true}));

  const rules = createMemo<VKNewsRules>(() => {
    const settings = vkNewsSettings();
    const isMain = tab() === ALL_TAB;
    // «Все» is filtered by default; a folder only when the settings say so
    const isFiltered = isMain || settings.scope === 'all';
    return {
      peerIds: isMain ? undefined : allFolders().find((folder) => String(folder.id) === tab())?.peerIds,
      hideArchived: isFiltered && settings.hideArchived,
      hideMuted: isFiltered && settings.hideMuted && !isMutedShown()
    };
  }, undefined, {
    // dialogs change all the time; only other rules are another feed (a new one starts from the top)
    // (a folder that was read again with the same members is the same feed)
    equals: (a, b) => isSameSet(a.peerIds, b.peerIds) && a.hideArchived === b.hideArchived && a.hideMuted === b.hideMuted
  });
  const feed = createNewsFeed({source: subscribed, rules});

  // the filters leave a few channels of many: the feed looks like «one channel» and the user must know why
  const hiddenCount = () => feed.isReady() ? feed.scopeChannelCount() - feed.channelCount() : 0;
  const hidesMost = () => hiddenCount() >= 3 && hiddenCount() > feed.channelCount();

  // the folder itself has no channel (as opposed to the rules leaving them all out)
  const isFolderWithoutChannels = createMemo(() => {
    const peerIds = rules().peerIds;
    return !!peerIds && !subscribed.channels().some((dialog) => peerIds.has(dialog.peerId));
  });

  const [sentinel, setSentinel] = createSignal<HTMLElement>();
  createEffect(() => {
    const element = sentinel();
    // a new page re-arms the observer: a sentinel that is still in view has nothing to report by itself
    void feed.postKeys().length;
    if(!element || feed.isEnd() || feed.isLoadingMore()) return;

    const observer = new IntersectionObserver((entries) => {
      if(entries.some((entry) => entry.isIntersecting)) feed.loadMore();
    }, {rootMargin: '400px'});
    observer.observe(element);
    onCleanup(() => observer.disconnect());
  });

  return (
    <div class="vk-page vk-news">
      <div class="vk-news-column">
        <section class="vk-block vk-page-block" aria-labelledby="vk-news-title">
          <h1 id="vk-news-title" class="vk-page-title">Новости</h1>

          <VKTabs
            tabs={tabs()}
            active={tab()}
            onChange={setTab}
            idPrefix="vk-news"
            label="Папки"
            // «+»: Web K's own folder creation, in its popup over this page (the real folder is saved
            // by Web K; the tabs follow its `filter_update` event, see useChannelFolders)
            addLabel="Создать папку"
            onAdd={() => {
              openWebKFolderCreation().catch((err) => console.error('VKgram: failed to open the folder creation', err));
            }}
            actions={
              <VKNewsSettings
                id="vk-news-settings"
                isOpen={isSettingsOpen()}
                onOpenChange={setSettingsOpen}
                channelCount={feed.isReady() ? feed.channelCount() : undefined}
                scopeCount={feed.isReady() ? feed.scopeChannelCount() : undefined}
                stats={feed.isReady() ? feed.scopeStats() : undefined}
                hidesMost={hidesMost()}
                isMutedShown={isMutedShown()}
                canShowMuted={rules().hideMuted}
                onShowAllChannels={() => setMutedShown(true)}
                onRestoreFilters={() => setMutedShown(false)}
              />
            }
          />

          <Show when={feed.isReady() && hidesMost()}>
            <p class="vk-page-text vk-page-text-secondary">
              Фильтры скрывают большинство каналов: в ленте {feed.channelCount()} из {feed.scopeChannelCount()}.{' '}
              <Show
                when={rules().hideMuted}
                fallback={<button type="button" class="vk-link-button" onClick={() => setSettingsOpen(true)}>Настройки ленты</button>}
              >
                <button type="button" class="vk-link-button" onClick={() => setMutedShown(true)}>Показать все каналы</button>
              </Show>
            </p>
          </Show>

          <div
            id={`vk-news-panel-${tab()}`}
            role="tabpanel"
            aria-labelledby={`vk-news-tab-${tab()}`}
          >
            <Switch>
              <Match when={feed.isLoading()}>
                <p class="vk-page-text vk-page-text-secondary vk-list-empty">Загрузка новостей…</p>
              </Match>

              <Match when={feed.totalChannelCount() === 0}>
                <VKEmptyState
                  icon="news"
                  title="Лента пуста"
                  description="Подпишитесь на каналы — их публикации появятся здесь."
                >
                  <button type="button" class="vk-button vk-news-action" onClick={() => openVKSection('channels')}>
                    Открыть «Каналы»
                  </button>
                </VKEmptyState>
              </Match>

              <Match when={feed.channelCount() === 0}>
                <VKEmptyState
                  icon="news"
                  title="Нет каналов для ленты"
                  description={!isFolderWithoutChannels() && (rules().hideArchived || rules().hideMuted) ?
                    'Каналы из архива и заглушённые не показываются. Это можно изменить в настройках ленты.' :
                    'В этой папке нет каналов.'}
                >
                  <Show when={!isFolderWithoutChannels() && (rules().hideArchived || rules().hideMuted)}>
                    <button type="button" class="vk-button vk-news-action" onClick={() => setSettingsOpen(true)}>
                      Настройки ленты
                    </button>
                  </Show>
                </VKEmptyState>
              </Match>

              <Match when={feed.postKeys().length === 0}>
                <VKEmptyState
                  icon="news"
                  title="Публикаций пока нет"
                  description="В каналах, на которые вы подписаны, ещё нет записей."
                />
              </Match>

              <Match when={true}>
                <div class="vk-channel-posts">
                  <For each={feed.postKeys()}>
                    {(key) => (
                      <Show when={feed.getPost(key)}>
                        {(post) => <VKChannelPost messages={post().messages} />}
                      </Show>
                    )}
                  </For>
                </div>
                <div ref={setSentinel} class="vk-list-sentinel" />
                <Show when={feed.isLoadingMore()}>
                  <p class="vk-page-text vk-page-text-secondary">Загрузка публикаций…</p>
                </Show>
              </Match>
            </Switch>
          </div>

          <Show when={feed.failedCount()}>
            <p class="vk-page-text vk-page-text-secondary">
              Не удалось загрузить часть каналов.{' '}
              <button type="button" class="vk-link-button" onClick={() => feed.retry()}>Повторить</button>
            </p>
          </Show>
        </section>
      </div>
    </div>
  );
}
