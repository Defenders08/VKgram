import {createEffect, createMemo, createResource, createSignal, For, onCleanup, onMount, Show} from 'solid-js';
import type {Chat} from '@layer';
import rootScope from '@lib/rootScope';
import {usePeers} from '@stores/peers';
import {AvatarNewTsx} from '@components/avatarNew';
import wrapMessageForReply from '@components/wrappers/messageForReply';
import wrapPeerTitle from '@components/wrappers/peerTitle';
import renderDialogSubtitleParts from '@components/wrappers/dialogSubtitle';
import getPeerActiveUsernames from '@appManagers/utils/peers/getPeerActiveUsernames';
import type {Dialog} from '@appManagers/appMessagesManager';
import {formatDateAccordingToTodayNew} from '@helpers/date';
import removeAccents from '@helpers/string/removeAccents';
import {getMiddleware} from '@helpers/middleware';
import {FOLDER_ID_ARCHIVE} from '@appManagers/constants';
import {openVKChannel, vkChannelPeerId} from '@/vkgram/pages/channel/route';
import VKChannelPage from '@/vkgram/pages/channel/VKChannelPage';
import createIncrementalList from '@/vkgram/hooks/createIncrementalList';
import useSubscribedChannels from '@/vkgram/hooks/useSubscribedChannels';
import getDialogLastMessage from '@/vkgram/utils/getDialogLastMessage';
import VKSearchField from '@/vkgram/components/VKSearchField';
import VKTabs, {VKTabItem} from '@/vkgram/components/VKTabs';
import useChannelFolders from '@/vkgram/hooks/useChannelFolders';
import {openWebKFolderCreation} from '@/vkgram/webk';

const AVATAR_SIZE = 48;

const normalize = (text: string) => removeAccents(text).toLowerCase();

/**
 * «Каналы» — the broadcast channels the user is subscribed to (no groups, no
 * catalog, no global search).
 *
 * The list comes from Web K's dialogs storage in its own order (see
 * useSubscribedChannels); titles / usernames / avatars from the reactive peer
 * store; the last-message preview is rendered by the same helper Web K's chat
 * list uses. Search filters what is already loaded. A click opens the
 * channel's VKgram page (`pages/channel`); the chat itself is one button away there.
 */
export default function VKPageChannels() {
  return (
    <Show when={vkChannelPeerId()} fallback={<VKChannelsList />}>
      {(peerId) => <VKChannelPage peerId={peerId()} />}
    </Show>
  );
}

const ALL_TAB = 'all';

function VKChannelsList() {
  const peers = usePeers();
  const subscribed = useSubscribedChannels({customFolders: true});
  const folders = useChannelFolders();
  const [query, setQuery] = createSignal('');
  const [tab, setTab] = createSignal(ALL_TAB);
  const [isDesktop, setIsDesktop] = createSignal(
    typeof window !== 'undefined' && window.matchMedia('(min-width: 601px)').matches
  );

  onMount(() => {
    const media = window.matchMedia('(min-width: 601px)');
    const update = () => setIsDesktop(media.matches);
    update();
    media.addEventListener?.('change', update);
    onCleanup(() => media.removeEventListener?.('change', update));
  });

  // Only show folders that actually contain at least one subscribed channel.
  const folderTabs = createMemo(() => {
    if(!subscribed.isReady()) return [];
    const channelPeerIds = new Set(subscribed.channels().map((dialog) => dialog.peerId));
    return folders.folders().filter((folder) => {
      for(const peerId of folder.peerIds) if(channelPeerIds.has(peerId)) return true;
      return false;
    });
  }, undefined, {
    equals: (a, b) => a.length === b.length && a.every((folder, index) => folder === b[index])
  });

  const tabs = createMemo<VKTabItem<string>[]>(() => [
    {id: ALL_TAB, title: 'Все'},
    ...folderTabs().map((folder) => ({id: String(folder.id), title: folder.title}))
  ]);

  // A folder can disappear while this page is open. Return to «Все» instead of
  // leaving the list on a tab that no longer exists.
  createEffect(() => {
    if(folders.isReady() && subscribed.isReady() && !tabs().some((item) => item.id === tab())) {
      setTab(ALL_TAB);
    }
  });

  const selectedPeerIds = createMemo(() => {
    if(tab() === ALL_TAB) return undefined;
    return folders.folders().find((folder) => String(folder.id) === tab())?.peerIds;
  });

  const filtered = createMemo(() => {
    const text = normalize(query().trim().replace(/^@/, ''));
    const peerIds = selectedPeerIds();
    const all = subscribed.channels();
    const inFolder = peerIds ? all.filter((dialog) => peerIds.has(dialog.peerId)) : all;
    if(!text) return inFolder;

    const words = text.split(/\s+/);
    return inFolder.filter((dialog) => {
      const chat = peers[dialog.peerId] as Chat.channel;
      const haystack = normalize([chat?.title, ...getPeerActiveUsernames(chat)].filter(Boolean).join(' '));
      return words.every((word) => haystack.includes(word));
    });
  });

  const list = createIncrementalList({
    total: () => filtered().length,
    resetKey: () => `${tab()}:${query()}`
  });
  const visible = createMemo(() => filtered().slice(0, list.count()));

  const createFolder = () => {
    openWebKFolderCreation().catch((err) => console.error('VKgram: failed to open the folder creation', err));
  };

  return (
    <div class="vk-page vk-channels">
      <div class="vk-channels-layout">
        <main class="vk-channels-main">
          <section class="vk-block vk-page-block" aria-labelledby="vk-channels-title">
            <h1 id="vk-channels-title" class="vk-page-title">
              Каналы
              <Show when={subscribed.isReady()}>
                <span class="vk-page-text-secondary vk-list-count"> {subscribed.channels().length}</span>
              </Show>
            </h1>

            <Show when={!isDesktop()}>
              <VKTabs
                tabs={tabs()}
                active={tab()}
                onChange={setTab}
                idPrefix="vk-channels-mobile"
                label="Папки"
                addLabel="Создать папку"
                onAdd={createFolder}
              />
            </Show>

            <VKSearchField value={query()} placeholder="Поиск каналов" onInput={setQuery} />

            <Show
              when={filtered().length}
              fallback={
                <p class="vk-page-text vk-page-text-secondary vk-list-empty">
                  {!subscribed.isReady() && !subscribed.channels().length ?
                    'Загрузка каналов…' :
                    query().trim() ? 'Ничего не найдено.' :
                    tab() !== ALL_TAB ? 'В этой папке нет каналов.' : 'Вы пока не подписаны ни на один канал.'}
                </p>
              }
            >
              <ul class="vk-peer-list">
                <For each={visible()}>
                  {(dialog) => <ChannelRow dialog={dialog} notifyVersion={subscribed.notifyVersion} />}
                </For>
              </ul>
              <div ref={list.setSentinel} class="vk-list-sentinel" />
            </Show>
          </section>
        </main>

        <Show when={isDesktop()}>
          <aside class="vk-channels-side" aria-label="Папки каналов">
            <section class="vk-block vk-channels-side-block">
              <VKTabs
                tabs={tabs()}
                active={tab()}
                onChange={setTab}
                idPrefix="vk-channels-desktop"
                label="Папки"
                addLabel="Создать папку"
                addInFooter
                onAdd={createFolder}
              />
            </section>
          </aside>
        </Show>
      </div>
    </div>
  );
}

function ChannelRow(props: {
  dialog: Dialog,
  notifyVersion: (peerId: PeerId) => number
}) {
  const peers = usePeers();
  const peerId = () => props.dialog.peerId;
  const chat = () => peers[peerId()] as Chat.channel;
  const username = () => getPeerActiveUsernames(chat())[0];
  const lastMessage = createMemo(() => getDialogLastMessage(props.dialog));

  const isArchived = () => props.dialog.folder_id === FOLDER_ID_ARCHIVE;
  // the pin is a flag of the dialog itself; in the archive it isn't shown
  const isPinned = () => !isArchived() && !!props.dialog.pFlags?.pinned;
  const unreadCount = () => props.dialog.unread_count || 0;
  const isMarkedUnread = () => !!props.dialog.pFlags?.unread_mark;

  // Web K's answer (the channel's own settings, then the type defaults);
  // asked again only when this peer's notification settings change
  const [isMuted] = createResource(
    () => ({peerId: peerId(), version: props.notifyVersion(peerId())}),
    ({peerId}) => rootScope.managers.appNotificationsManager.isPeerLocalMuted({peerId, respectType: true})
  );

  let previewEl: HTMLDivElement;
  createEffect(() => {
    const message = lastMessage();
    const id = peerId();

    const middlewareHelper = getMiddleware();
    onCleanup(() => middlewareHelper.destroy());
    const middleware = middlewareHelper.get();

    if(!message) {
      previewEl.replaceChildren();
      return;
    }

    renderDialogSubtitleParts({
      peerId: id,
      isSaved: false,
      lastMessage: message,
      middleware: middleware as any,
      textColor: 'secondary-text-color',
      messageRenderer: wrapMessageForReply,
      peerTitleRenderer: wrapPeerTitle
    }).then((parts) => {
      if(!middleware()) return;
      previewEl.replaceChildren(...parts);
    }, () => {
      // interrupted by a newer message — nothing to do
    });
  });

  const time = () => {
    const message = lastMessage();
    return message ? formatDateAccordingToTodayNew(new Date(message.date * 1000)) : undefined;
  };

  const open = () => openVKChannel(peerId());

  return (
    <li class="vk-peer-row vk-peer-row-clickable" onClick={open}>
      <div class="vk-peer-avatar">
        <AvatarNewTsx peerId={peerId()} size={AVATAR_SIZE} />
      </div>

      <div class="vk-peer-info">
        <div class="vk-peer-title-line">
          <button type="button" class="vk-link-button vk-peer-name">{chat()?.title}</button>
          <Show when={isPinned()}>
            <span class="vk-peer-flag" title="Закреплён">📌</span>
          </Show>
          <Show when={isMuted()}>
            <span class="vk-peer-flag" title="Без звука">🔕</span>
          </Show>
          <Show when={isArchived()}>
            <span class="vk-peer-flag vk-page-text-secondary">в архиве</span>
          </Show>
        </div>
        <Show when={username()}>
          <div class="vk-peer-sub vk-page-text-secondary">@{username()}</div>
        </Show>
        <div class="vk-peer-preview vk-page-text-secondary" ref={previewEl} />
      </div>

      <div class="vk-peer-meta">
        <div class="vk-peer-time vk-page-text-secondary">{time()}</div>
        <Show when={unreadCount() || isMarkedUnread()}>
          <span class="vk-badge" classList={{'vk-badge-muted': !!isMuted()}}>
            {unreadCount() || ''}
          </span>
        </Show>
      </div>
    </li>
  );
}
