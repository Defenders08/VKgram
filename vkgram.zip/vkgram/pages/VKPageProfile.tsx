import {createMemo, createSignal, For, Show} from 'solid-js';
import type {User, UserFull} from '@layer';
import type {MyDocument} from '@appManagers/appDocsManager';
import rootScope from '@lib/rootScope';
import {useUser} from '@stores/peers';
import {useFullPeer} from '@stores/fullPeers';
import {AvatarNewTsx} from '@components/avatarNew';
import {pickAvatarAndUpload} from '@components/avatarEdit';
import {useMediaSizes} from '@helpers/mediaSizes';
import getPeerActiveUsernames from '@appManagers/utils/peers/getPeerActiveUsernames';
import {formatPhoneNumber} from '@helpers/formatPhoneNumber';
import VKProfileEditForm from '@/vkgram/pages/profile/VKProfileEditForm';
import VKProfileBirthday from '@/vkgram/pages/profile/VKProfileBirthday';
import VKProfilePersonalChannel from '@/vkgram/pages/profile/VKProfilePersonalChannel';
import VKProfileMusic from '@/vkgram/pages/profile/VKProfileMusic';
import {VKProfileStories, VKProfileStoriesArchive} from '@/vkgram/pages/profile/VKProfileStories';
import VKProfileGifts from '@/vkgram/pages/profile/VKProfileGifts';
import VKProfileInfoRow from '@/vkgram/pages/profile/VKProfileInfoRow';
import VKProfileMusicList from '@/vkgram/pages/profile/VKProfileMusicList';
import {VKProfileGroups, VKProfileSubscriptions} from '@/vkgram/pages/profile/VKProfileSideBlocks';
import VKPageUserProfile from '@/vkgram/pages/profile/VKPageUserProfile';
import {vkProfilePeerId} from '@/vkgram/pages/profile/route';

/**
 * «Моя страница». On desktop the same section shows the page of another user
 * when one was opened (friends, search); on mobile it is always my page.
 */
export default function VKPageProfile() {
  const sizes = useMediaSizes();

  return (
    <Show when={!sizes.isMobile && vkProfilePeerId()} fallback={<VKPageOwnProfile />}>
      {(peerId) => <VKPageUserProfile peerId={peerId()} />}
    </Show>
  );
}

/**
 * The signed-in user's profile in VKgram markup.
 *
 * No data of its own: the user comes from Web K's reactive peer store
 * (`useUser`), bio / birthday from its full-peer store (`useFullPeer`), the
 * avatar is Web K's avatar component. Edits go through Web K's managers, and
 * the stores push the result back here — no reload, no manual refresh.
 */
function VKPageOwnProfile() {
  const myPeerId = rootScope.myId;
  const sizes = useMediaSizes();
  const user = useUser(() => myPeerId.toUserId()) as () => User.user;
  const fullPeer = useFullPeer(myPeerId);
  const userFull = () => fullPeer() as UserFull.userFull;

  const [isEditing, setIsEditing] = createSignal(false);
  const [isAvatarUploading, setIsAvatarUploading] = createSignal(false);

  const fullName = () => [user()?.first_name, user()?.last_name].filter(Boolean).join(' ');
  const usernames = createMemo(() => getPeerActiveUsernames(user()));
  const phone = createMemo(() => {
    const raw = user()?.phone;
    if(!raw) return;
    const {formatted, code} = formatPhoneNumber(raw);
    return (code ? '+' : '') + formatted;
  });
  // the page scrolls itself; the gifts grid lazy-loads against it
  const [pageEl, setPageEl] = createSignal<HTMLDivElement>();

  // Web K's own flow: file picker → media editor → upload → uploadProfilePhoto.
  // The new photo arrives through `avatar_update`, which AvatarNew listens to.
  const changeAvatar = () => {
    pickAvatarAndUpload({
      managers: rootScope.managers,
      mode: 'self',
      onUploadStart: (progress) => {
        setIsAvatarUploading(true);
        progress.catch(() => setIsAvatarUploading(false));
      },
      onUploaded: () => setIsAvatarUploading(false)
    });
  };

  // the blocks of the page; the mobile page stacks them in this order, the desktop one splits them into two columns
  const changePhotoButton = () => (
    <button
      type="button"
      class="vk-link-button"
      disabled={isAvatarUploading()}
      onClick={changeAvatar}
    >
      {isAvatarUploading() ? 'Загрузка фотографии…' : 'Изменить фотографию'}
    </button>
  );

  // everything the profile says in words: name, about, data rows, actions
  // (the desktop page has «Изменить профиль» under the avatar, the mobile one in the block)
  const infoContent = (withEditButton = true) => (
    <>
      <h1 id="vk-profile-name" class="vk-profile-name">{fullName()}</h1>
      <Show when={usernames().length}>
        <div class="vk-profile-username">
          {usernames().map((username) => '@' + username).join(', ')}
        </div>
      </Show>
      <Show when={userFull()?.about}>
        <p class="vk-profile-about">{userFull().about}</p>
      </Show>

      {/* ProfileInfo */}
      <dl class="vk-profile-info">
        <VKProfileInfoRow label="Имя">{user()?.first_name}</VKProfileInfoRow>
        <VKProfileInfoRow label="Фамилия">{user()?.last_name}</VKProfileInfoRow>
        <VKProfileInfoRow label="Имя пользователя">
          {usernames().length ? usernames().map((username) => '@' + username).join(', ') : undefined}
        </VKProfileInfoRow>
        <VKProfileInfoRow label="О себе">{userFull()?.about}</VKProfileInfoRow>
        <VKProfileBirthday birthday={userFull()?.birthday} />
        <VKProfileInfoRow label="Телефон">{phone()}</VKProfileInfoRow>
      </dl>

      {/* ProfileActions */}
      <Show when={withEditButton && !isEditing()}>
        <div class="vk-profile-actions">
          <button type="button" class="vk-button" onClick={() => setIsEditing(true)}>
            Изменить профиль
          </button>
        </div>
      </Show>
    </>
  );

  // mobile: avatar and text in one block, as before
  const headerBlock = () => (
    <section class="vk-block vk-profile-header" aria-labelledby="vk-profile-name">
      <div class="vk-profile-avatar">
        <AvatarNewTsx peerId={myPeerId} size={120} isBig />
        {changePhotoButton()}
      </div>

      <div class="vk-profile-main">
        {infoContent()}
      </div>
    </section>
  );

  // desktop: the avatar alone in its block — hover dims it and offers the change of the photo, like the old VK;
  // «Изменить профиль» sits right under it, the text is a block of its own
  const avatarBlock = () => (
    <section class="vk-block vk-profile-avatar-block">
      <button
        type="button"
        class="vk-profile-avatar-edit"
        classList={{'is-uploading': isAvatarUploading()}}
        disabled={isAvatarUploading()}
        aria-label="Изменить фотографию"
        onClick={changeAvatar}
      >
        <AvatarNewTsx peerId={myPeerId} size={120} isBig />
        <span class="vk-profile-avatar-edit-label">
          {isAvatarUploading() ? 'Загрузка…' : 'Изменить фотографию'}
        </span>
      </button>
    </section>
  );
  const editProfileButton = () => (
    <Show when={!isEditing()}>
      <div class="vk-profile-side-actions">
        <button type="button" class="vk-button" onClick={() => setIsEditing(true)}>
          Изменить профиль
        </button>
      </div>
    </Show>
  );
  const summaryBlock = () => (
    <section class="vk-block vk-profile-summary" aria-labelledby="vk-profile-name">
      {infoContent(false)}
    </section>
  );
  const editBlock = () => (
    <Show when={isEditing()}>
      <VKProfileEditForm
        user={user()}
        userFull={userFull()}
        onDone={() => setIsEditing(false)}
      />
    </Show>
  );
  const channelBlock = () => (
    <VKProfilePersonalChannel channelId={userFull()?.personal_channel_id?.toChatId()} />
  );
  const musicBlock = () => (
    <VKProfileMusic profileTrack={userFull()?.saved_music as MyDocument} hideAllTracks={!sizes.isMobile} />
  );
  // desktop: the tracks are a block of their own in the narrow column
  const musicListBlock = () => (
    <VKProfileMusicList peerId={myPeerId} profileTrack={userFull()?.saved_music as MyDocument} />
  );
  const restBlocks = () => (
    <>
      <VKProfileStories />
      <VKProfileStoriesArchive />
      <Show when={pageEl()}>
        <VKProfileGifts scrollParent={pageEl()} />
      </Show>

      {/* ProfileContent — groundwork for the wall and media */}
      {/* on desktop «Музыка» is the block in the narrow column, not a stub here */}
      <For each={sizes.isMobile ? PROFILE_CONTENT_SECTIONS : PROFILE_CONTENT_SECTIONS.filter((section) => section.title !== 'Музыка')}>
        {(section) => (
          <section class="vk-block vk-profile-section" aria-label={section.title}>
            <h2 class="vk-block-title">{section.title}</h2>
            <p class="vk-page-text vk-page-text-secondary">{section.empty}</p>
          </section>
        )}
      </For>
    </>
  );

  return (
    <div class="vk-page vk-profile" ref={setPageEl}>
      <Show
        when={user()}
        fallback={<div class="vk-block vk-page-block vk-page-text-secondary">Загрузка профиля…</div>}
      >
        <Show
          when={sizes.isMobile}
          fallback={
            // desktop: two columns like the old VK — the person on the left, the content on the right
            <div class="vk-cols">
              <div class="vk-col-side">
                {avatarBlock()}
                {editProfileButton()}
                <VKProfileSubscriptions />
                <VKProfileGroups />
                {musicListBlock()}
              </div>
              <div class="vk-col-main">
                {summaryBlock()}
                {musicBlock()}
                {editBlock()}
                {channelBlock()}
                {restBlocks()}
              </div>
            </div>
          }
        >
          {headerBlock()}
          {editBlock()}
          {channelBlock()}
          {musicBlock()}
          {restBlocks()}
        </Show>
      </Show>
    </div>
  );
}

const PROFILE_CONTENT_SECTIONS = [
  {title: 'Стена', empty: 'Раздел в разработке.'},
  {title: 'Фотографии', empty: 'Раздел в разработке.'},
  {title: 'Видео', empty: 'Раздел в разработке.'},
  {title: 'Музыка', empty: 'Раздел в разработке.'}
];
