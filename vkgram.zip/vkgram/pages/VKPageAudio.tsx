import {createMemo, createSignal, For, Show} from 'solid-js';
import type {UserFull} from '@layer';
import type {MyDocument} from '@appManagers/appDocsManager';
import getAudioTitles from '@appManagers/utils/docs/getAudioTitles';
import appMediaPlaybackController from '@components/appMediaPlaybackController';
import rootScope from '@lib/rootScope';
import {useFullPeer} from '@stores/fullPeers';
import {openWebKSavedMusic} from '@/vkgram/webk';
import createSavedMusic from '@/vkgram/hooks/createSavedMusic';
import createNowPlaying from '@/vkgram/hooks/createNowPlaying';
import createIncrementalList from '@/vkgram/hooks/createIncrementalList';
import matchesQuery from '@/vkgram/utils/matchesQuery';
import {formatAudioTitles, formatDuration} from '@/vkgram/utils/audio';
import VKSearchField from '@/vkgram/components/VKSearchField';
import VKEmptyState from '@/vkgram/components/VKEmptyState';
import VKIcon from '@/vkgram/components/VKIcons';
import VKMediaPage, {VKMediaList} from '@/vkgram/components/VKMediaBrowser';

// how many tracks are asked for; the rest of a longer playlist stays in Web K's own tab
const LIMIT = 100;

/**
 * «Аудиозаписи», tabs as in Telegram's shared media:
 * «Поиск» — the music of all chats (Telegram's global search, music only),
 * «Избранное» — the music kept in the saved messages,
 * «Аудиостатус» — the music of the user's profile (`VKAudioStatus`),
 * «Голосовые» — the voice messages of all chats (global search, voice only).
 * The tracks of the lists play in Web K's global player.
 */
export default function VKPageAudio() {
  return (
    <VKMediaPage
      section="audio"
      tabs={[
        {id: 'search', title: 'Поиск', render: () => <VKMediaList kind="music" source="search" />},
        {id: 'saved', title: 'Избранное', render: () => <VKMediaList kind="music" source="saved" />},
        {id: 'status', title: 'Аудиостатус', render: () => <VKAudioStatus />},
        {id: 'voice', title: 'Голосовые', render: () => <VKMediaList kind="voice" source="search" />}
      ]}
    />
  );
}

/**
 * «Аудиостатус» of «Аудиозаписи» — the tracks of the signed-in user's profile music (the same
 * list «Все треки» of Web K opens), in the old VK's audio-list shape: a
 * search, «now playing», rows with a cover, title, performer and duration.
 *
 * There is no player of its own: what plays is Web K's global one
 * (`appMediaPlaybackController`). A row of the playing track pauses / resumes
 * it; a row of any other track opens Web K's playlist tab, where playback is
 * started — the one place to change (`playTrack`) when playback moves in here.
 * The cover is an icon: the data has no cover for a track that is not loaded
 * in a chat.
 */
function VKAudioStatus() {
  const myPeerId = rootScope.myId;
  const fullPeer = useFullPeer(myPeerId);
  const userFull = () => fullPeer() as UserFull.userFull;

  const music = createSavedMusic({
    peerId: () => myPeerId,
    limit: LIMIT,
    refreshKey: () => (userFull()?.saved_music as MyDocument)?.id
  });
  const playing = createNowPlaying();
  const [query, setQuery] = createSignal('');

  const filtered = createMemo(() => {
    const tracks = music.tracks();
    if(!tracks) return;
    return tracks.filter((doc) => {
      const titles = getAudioTitles(doc);
      return matchesQuery(query(), titles?.title, titles?.performer);
    });
  });

  const list = createIncrementalList({
    total: () => filtered()?.length ?? 0,
    resetKey: query
  });
  const visible = createMemo(() => filtered()?.slice(0, list.count()) ?? []);
  const total = () => music.count() ?? music.tracks()?.length ?? 0;

  const openPlaylist = () => openWebKSavedMusic(myPeerId);
  const isCurrent = (doc: MyDocument) => playing()?.doc?.id === doc.id;
  const playTrack = (doc: MyDocument) => {
    if(isCurrent(doc)) appMediaPlaybackController.toggle();
    else openPlaylist();
  };

  return (
    <div class="vk-audio">
      <Show when={music.tracks()?.length}>
        <p class="vk-page-text vk-page-text-secondary">Музыка вашего профиля: {total()}</p>
      </Show>

      <Show when={playing()}>
        <div class="vk-audio-now">
          <span class="vk-page-text-secondary">Сейчас играет: </span>
          <span class="vk-audio-now-title">{formatAudioTitles(playing().doc)}</span>
          {' '}
          <button
            type="button"
            class="vk-link-button"
            aria-label={playing().paused ? 'Продолжить' : 'Пауза'}
            onClick={() => appMediaPlaybackController.toggle()}
          >
            {playing().paused ? '▶' : '⏸'}
          </button>
        </div>
      </Show>

      <Show when={music.tracks()?.length}>
        <VKSearchField value={query()} placeholder="Поиск аудиозаписей" onInput={setQuery} />
      </Show>

      <Show
        when={filtered()}
        fallback={<p class="vk-page-text vk-page-text-secondary vk-list-empty">Загрузка аудиозаписей…</p>}
      >
        <Show
          when={music.tracks().length}
          fallback={
            <VKEmptyState
              icon="audio"
              title="Аудиозаписей пока нет"
              description="Музыка из вашего профиля Telegram появится здесь."
            />
          }
        >
          <Show
            when={filtered().length}
            fallback={<p class="vk-page-text vk-page-text-secondary vk-list-empty">Ничего не найдено.</p>}
          >
            <ul class="vk-audio-list">
              <For each={visible()}>
                {(doc) => (
                  <TrackRow
                    doc={doc}
                    isCurrent={isCurrent(doc)}
                    isPaused={!!playing()?.paused}
                    onPlay={() => playTrack(doc)}
                  />
                )}
              </For>
            </ul>
            <div ref={list.setSentinel} class="vk-list-sentinel" />
          </Show>

          <Show when={total() > music.tracks().length}>
            <button type="button" class="vk-link-button vk-audio-more" onClick={openPlaylist}>
              Показать все в «Сообщениях»
            </button>
          </Show>
        </Show>
      </Show>
    </div>
  );
}

function TrackRow(props: {
  doc: MyDocument,
  isCurrent: boolean,
  isPaused: boolean,
  onPlay: () => void
}) {
  const titles = () => getAudioTitles(props.doc);

  return (
    <li>
      <button
        type="button"
        class="vk-audio-row"
        classList={{'is-current': props.isCurrent}}
        onClick={() => props.onPlay()}
      >
        <span class="vk-audio-cover">
          <VKIcon name="audio" size={18} class="vk-audio-cover-icon" />
          <span class="vk-audio-cover-state" aria-hidden="true">
            {props.isCurrent && !props.isPaused ? '⏸' : '▶'}
          </span>
        </span>

        <span class="vk-audio-info">
          <span class="vk-audio-title">{titles()?.title || 'Аудио'}</span>
          <span class="vk-audio-performer">{titles()?.performer || 'Неизвестный исполнитель'}</span>
        </span>

        <span class="vk-audio-duration">{formatDuration(props.doc.duration)}</span>
      </button>
    </li>
  );
}
