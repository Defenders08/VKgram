import {createMemo, createSignal, For, Show} from 'solid-js';
import type {UserFull} from '@layer';
import type {MyDocument} from '@appManagers/appDocsManager';
import getAudioTitles from '@appManagers/utils/docs/getAudioTitles';
import appMediaPlaybackController from '@components/appMediaPlaybackController';
import rootScope from '@lib/rootScope';
import {useFullPeer} from '@stores/fullPeers';
import {openWebKSavedMusic} from '@/vkgram/webk';
import createSavedMusic from '@/vkgram/hooks/createSavedMusic';
import createNowPlaying from '@/vkgram/hooks/createNowPlaying';
import createPlaybackTime from '@/vkgram/hooks/createPlaybackTime';
import createIncrementalList from '@/vkgram/hooks/createIncrementalList';
import matchesQuery from '@/vkgram/utils/matchesQuery';
import {formatAudioTitles, formatDuration, formatTime} from '@/vkgram/utils/audio';
import VKSearchField from '@/vkgram/components/VKSearchField';
import VKEmptyState from '@/vkgram/components/VKEmptyState';
import VKPlayGlyph from '@/vkgram/components/VKPlayGlyph';
import VKTrackRow from '@/vkgram/components/VKTrackRow';
import VKMediaPage, {VKMediaList} from '@/vkgram/components/VKMediaBrowser';

// how many tracks are asked for; the rest of a longer playlist stays in Web K's own tab
const LIMIT = 100;

/**
 * «Аудиозаписи», tabs as in Telegram's shared media:
 * «Поиск» — the music of all chats (Telegram's global search, music only),
 * «Избранное» — the music kept in the saved messages,
 * «Аудиостатус» — the music of the user's profile (`VKAudioStatus`),
 * «Голосовые» — the voice messages of all chats (global search, voice only).
 * The tracks of the lists play in Web K's global player.
 */
export default function VKPageAudio() {
  return (
    <VKMediaPage
      section="audio"
      tabs={[
        {id: 'search', title: 'Поиск', render: () => <VKMediaList kind="music" source="search" />},
        {id: 'saved', title: 'Избранное', render: () => <VKMediaList kind="music" source="saved" />},
        {id: 'status', title: 'Аудиостатус', render: () => <VKAudioStatus />},
        {id: 'voice', title: 'Голосовые', render: () => <VKMediaList kind="voice" source="search" />}
      ]}
    />
  );
}

/**
 * «Аудиостатус» of «Аудиозаписи» — the tracks of the signed-in user's profile music (the same
 * list «Все треки» of Web K opens), in the old VK's audio-list shape: a
 * search, «now playing», and compact one-line rows: a small play / pause
 * button, «исполнитель — название», duration.
 *
 * There is no player of its own: what plays is Web K's global one
 * (`appMediaPlaybackController`). A row of the playing track pauses / resumes
 * it; a row of any other track opens Web K's playlist tab, where playback is
 * started — the one place to change (`playTrack`) when playback moves in here.
 */
function VKAudioStatus() {
  const myPeerId = rootScope.myId;
  const fullPeer = useFullPeer(myPeerId);
  const userFull = () => fullPeer() as UserFull.userFull;

  const music = createSavedMusic({
    peerId: () => myPeerId,
    limit: LIMIT,
    refreshKey: () => (userFull()?.saved_music as MyDocument)?.id
  });
  const playing = createNowPlaying();
  const time = createPlaybackTime(playing);
  const [query, setQuery] = createSignal('');

  const filtered = createMemo(() => {
    const tracks = music.tracks();
    if(!tracks) return;
    return tracks.filter((doc) => {
      const titles = getAudioTitles(doc);
      return matchesQuery(query(), titles?.title, titles?.performer);
    });
  });

  const list = createIncrementalList({
    total: () => filtered()?.length ?? 0,
    resetKey: query
  });
  const visible = createMemo(() => filtered()?.slice(0, list.count()) ?? []);
  const total = () => music.count() ?? music.tracks()?.length ?? 0;

  const openPlaylist = () => openWebKSavedMusic(myPeerId);
  const isCurrent = (doc: MyDocument) => playing()?.doc?.id === doc.id;
  const playTrack = (doc: MyDocument) => {
    if(isCurrent(doc)) appMediaPlaybackController.toggle();
    else openPlaylist();
  };

  return (
    <div class="vk-audio">
      <Show when={music.tracks()?.length}>
        <p class="vk-page-text vk-page-text-secondary">Музыка вашего профиля: {total()}</p>
      </Show>

      <Show when={playing()}>
        <div class="vk-audio-now">
          <button
            type="button"
            class="vk-audio-now-toggle"
            aria-label={playing().paused ? 'Продолжить' : 'Пауза'}
            onClick={() => appMediaPlaybackController.toggle()}
          >
            <VKPlayGlyph playing={!playing().paused} size={12} />
          </button>
          <span class="vk-audio-now-info">
            <span class="vk-audio-now-label">Сейчас играет</span>
            <span class="vk-audio-now-title">{formatAudioTitles(playing().doc)}</span>
          </span>
          <Show when={playing().doc.duration}>
            <span class="vk-audio-now-time">
              {formatTime(time())} / {formatDuration(playing().doc.duration, true)}
            </span>
            <span class="vk-audio-now-bar" aria-hidden="true">
              <span style={{width: Math.min(100, (time() / playing().doc.duration) * 100) + '%'}} />
            </span>
          </Show>
        </div>
      </Show>

      <Show when={music.tracks()?.length}>
        <VKSearchField value={query()} placeholder="Поиск аудиозаписей" onInput={setQuery} />
      </Show>

      <Show
        when={filtered()}
        fallback={<p class="vk-page-text vk-page-text-secondary vk-list-empty">Загрузка аудиозаписей…</p>}
      >
        <Show
          when={music.tracks().length}
          fallback={
            <VKEmptyState
              icon="audio"
              title="Аудиозаписей пока нет"
              description="Музыка из вашего профиля Telegram появится здесь."
            />
          }
        >
          <Show
            when={filtered().length}
            fallback={<p class="vk-page-text vk-page-text-secondary vk-list-empty">Ничего не найдено.</p>}
          >
            <ul class="vk-audio-list">
              <For each={visible()}>
                {(doc) => (
                  <VKTrackRow
                    doc={doc}
                    isCurrent={isCurrent(doc)}
                    isPaused={!!playing()?.paused}
                    onPlay={() => playTrack(doc)}
                  />
                )}
              </For>
            </ul>
            <div ref={list.setSentinel} class="vk-list-sentinel" />
          </Show>

          <Show when={total() > music.tracks().length}>
            <button type="button" class="vk-link-button vk-audio-more" onClick={openPlaylist}>
              Показать все в «Телеграм»
            </button>
          </Show>
        </Show>
      </Show>
    </div>
  );
}
