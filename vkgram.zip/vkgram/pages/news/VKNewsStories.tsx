import {createRoot, For, getOwner, onCleanup, Show} from 'solid-js';
import rootScope from '@lib/rootScope';
import {AvatarNewTsx} from '@components/avatarNew';
import {PeerTitleTsx} from '@components/peerTitleTsx';
import {StoriesProvider, useStories} from '@components/stories/store';

const AVATAR_SIZE = 54;

type PeerStories = ReturnType<typeof useStories>[0]['peers'][0];

// every story of the peer is seen (my own ring never greys out, as in Telegram)
const isRead = (peer: PeerStories) => peer.peerId !== rootScope.myId &&
  !!peer.maxReadId && peer.maxReadId >= peer.stories[peer.stories.length - 1]?.id;

function StoriesStrip() {
  const [stories, actions] = useStories();
  const owner = getOwner();
  const items = new Map<PeerId, HTMLElement>();

  // the open viewer lives in its own root under this strip: the stories context is found through it
  let disposeViewer: () => void;
  onCleanup(() => disposeViewer?.());

  const open = async(peer: PeerStories) => {
    const {createStoriesViewer} = await import('@components/stories/viewer');
    disposeViewer?.();
    actions.resetIndexes();
    actions.set({peer});
    createRoot((dispose) => {
      disposeViewer = dispose;
      // the viewer flies out of (and back into) the avatar of the peer it shows
      createStoriesViewer({
        onExit: () => {
          dispose();
          if(disposeViewer === dispose) disposeViewer = undefined;
        },
        target: () => items.get(stories.peer?.peerId)?.querySelector('.avatar')
      });
    }, owner);
  };

  // the next page of peers comes as the strip is scrolled to its end
  const onScroll = (e: Event) => {
    const el = e.currentTarget as HTMLElement;
    if(el.scrollLeft + el.clientWidth >= el.scrollWidth - AVATAR_SIZE * 2) actions.load();
  };

  return (
    <Show when={stories.peers.length}>
      <section class="vk-block vk-stories" aria-label="Истории">
        <div class="vk-stories-list" onScroll={onScroll}>
          <For each={stories.peers}>
            {(peer) => (
              <button
                ref={(el) => items.set(peer.peerId, el)}
                type="button"
                class="vk-stories-item"
                aria-label={peer.peerId === rootScope.myId ? 'Открыть мою историю' : undefined}
                classList={{'is-read': isRead(peer)}}
                onClick={() => open(peer)}
              >
                <AvatarNewTsx peerId={peer.peerId} size={AVATAR_SIZE} withStories isDialog={false} />
                <span class="vk-stories-name">
                  {peer.peerId === rootScope.myId ? 'Моя история' : <PeerTitleTsx peerId={peer.peerId} onlyFirstName />}
                </span>
              </button>
            )}
          </For>
        </div>
      </section>
    </Show>
  );
}

/**
 * Stories at the top of «Новости», as in Telegram: a horizontal strip of round
 * avatars — a colored ring while a peer has stories not seen yet, a grey one
 * after — and Web K's story viewer on a click (it opens over VKgram, as
 * everywhere in the app).
 *
 * Nothing is VKgram's own: the list is Web K's stories store
 * (`StoriesProvider` without peers reads every active story of the user's
 * contacts and channels — `stories.getAllStories` — and follows the updates),
 * the ring is `AvatarNew`'s, the viewer is `createStoriesViewer`. The strip is
 * not drawn while nobody has stories.
 */
export default function VKNewsStories() {
  return (
    <StoriesProvider needUpdates>
      <StoriesStrip />
    </StoriesProvider>
  );
}
