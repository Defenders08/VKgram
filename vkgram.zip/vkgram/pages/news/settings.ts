import {createRoot, createSignal} from 'solid-js';

/**
 * The settings of the «Новости» feed.
 * `hideArchived` / `hideMuted` — leave out the channels in the archive / with
 * notifications off. By default only the archive is left out: muted channels
 * are the user's to hide (a muted channel is often still one to read). `scope` — where that applies: `main` is «Все» only, the
 * folders show what is in them; `all` — the folders too.
 */
export type VKNewsSettings = {
  hideArchived: boolean,
  hideMuted: boolean,
  scope: 'main' | 'all'
};

const STORAGE_KEY = 'vkgram-news-settings';
// Version of the saved shape. Before 2, «hide muted» was on by default and was
// saved together with everything else, so a saved `true` did not have to be a
// choice; it is not carried over (once), the default of the version decides.
const VERSION = 2;
// the archive is left out, in «Все» and in the folders alike; muted channels stay
const DEFAULTS: VKNewsSettings = {hideArchived: true, hideMuted: false, scope: 'all'};

function read(): VKNewsSettings {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    return {
      hideArchived: typeof saved?.hideArchived === 'boolean' ? saved.hideArchived : DEFAULTS.hideArchived,
      hideMuted: saved?.v === VERSION && typeof saved?.hideMuted === 'boolean' ? saved.hideMuted : DEFAULTS.hideMuted,
      // what the user saved stays as it is, the default is only for what was never chosen
      scope: saved?.scope === 'main' || saved?.scope === 'all' ? saved.scope : DEFAULTS.scope
    };
  } catch{
    return {...DEFAULTS};
  }
}

// module-level: the choice outlives the page and comes back with the next visit
const [settings, setSettings] = createRoot(() => createSignal<VKNewsSettings>(read()));

export {settings as vkNewsSettings};

export const isDefaultVKNewsSettings = () => {
  const {hideArchived, hideMuted, scope} = settings();
  return hideArchived === DEFAULTS.hideArchived && hideMuted === DEFAULTS.hideMuted && scope === DEFAULTS.scope;
};

/** Back to the defaults; the saved choice is dropped, so the defaults stay the app's to change. */
export function resetVKNewsSettings() {
  setSettings({...DEFAULTS});
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch{}
}

export function updateVKNewsSettings(patch: Partial<VKNewsSettings>) {
  const next = {...settings(), ...patch};
  setSettings(next);
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({...next, v: VERSION}));
  } catch{}
}
