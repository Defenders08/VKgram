import {render} from 'solid-js/web';
import {createResource, For} from 'solid-js';
import type {Message} from '@layer';
import type {ButtonMenuItemOptionsVerifiable} from '@components/buttonMenu';
import createContextMenu from '@helpers/dom/createContextMenu';
import {copyTextToClipboard} from '@helpers/clipboard';
import getServerMessageId from '@appManagers/utils/messageId/getServerMessageId';
import rootScope from '@lib/rootScope';
import {toast} from '@components/toast';
import {openWebKMessage, openWebKMessageEditing} from '@/vkgram/webk';

// what the menu gets from the ⋮ button: the point it opens from (not a real event)
type ButtonOpenEvent = {pageX: number, pageY: number, isVKButton: true};

// parts of a post that keep the browser's own menu (links, the comment form) or have their own
const NATIVE_MENU_SELECTOR = 'a[href], input, textarea, [contenteditable="true"], .vk-comments';

// a long press of a finger (a touch event on Apple, a `contextmenu` from a touch elsewhere), not a mouse
const isTouchPress = (e: MouseEvent | TouchEvent) => e.type.startsWith('touch') ||
  (e as PointerEvent).pointerType === 'touch' || (e as PointerEvent).pointerType === 'pen';

/**
 * The menu of one publication, in Telegram's shape: Web K's own context menu
 * (`createContextMenu` → `ButtonMenu`, the menu chat bubbles open), so it
 * looks, animates, positions and closes (Escape, a click outside, a section
 * change) like every other menu of the app, in the light and the dark theme.
 *
 * Desktop: a right click on the post opens it where the cursor is; the ⋮ next
 * to the author opens the same menu under the button. A finger opens it with
 * the ⋮ only (a long press stays the browser's — text selection, scrolling);
 * a mouse on a touch laptop still has the right click.
 *
 * Every action is Web K's: the same checks the chat's menu makes (`verify` —
 * an item that cannot be done is not shown) and the same popups / manager calls.
 * Nothing is done by VKgram itself.
 */
export default function createPostMenu(options: {
  // the post element: right clicks on it open the menu
  element: HTMLElement,
  // the post's messages (an album has several) and the one carrying its text
  getMessages: () => Message.message[],
  getMain: () => Message.message
}) {
  const managers = rootScope.managers;
  const peerId = () => options.getMain().peerId;
  const mids = () => options.getMessages().map((message) => message.mid);

  const canForward = async() => {
    const results = await Promise.all(options.getMessages().map((message) => managers.appMessagesManager.canForward(message)));
    return results.every(Boolean);
  };

  // the pin state as Web K's storage has it now (the post's own copy is not updated by a pin)
  const isPinned = async() => {
    const main = options.getMain();
    const message = await managers.appMessagesManager.getMessageByPeer(main.peerId, main.mid);
    return !!((message as Message.message) ?? main).pFlags?.pinned;
  };

  const isMuted = () => managers.appNotificationsManager.isPeerLocalMuted({peerId: peerId(), respectType: true});

  // the same link the chat's «Копировать ссылку» makes: t.me/<username>/<id>, or t.me/c/<id>/<id> for a private channel
  const getLink = async() => {
    const main = options.getMain();
    const username = await managers.appPeersManager.getPeerUsername(main.peerId);
    const id = getServerMessageId(main.mid);
    return {
      url: username ? `https://t.me/${username}/${id}` : `https://t.me/c/${main.peerId.toChatId()}/${id}`,
      isPrivate: !username
    };
  };

  const buttons: ButtonMenuItemOptionsVerifiable[] = [
    {
      icon: 'reply',
      regularText: 'Ответить',
      onClick: async() => {
        const {default: appImManager} = await import('@lib/appImManager');
        await appImManager.setInnerPeer({peerId: peerId()});
        appImManager.chat?.input?.initMessageReply({replyToMsgId: options.getMain().mid});
      },
      verify: () => true
    }, {
      icon: 'select',
      regularText: 'Выделить',
      onClick: async() => {
        const {default: appImManager} = await import('@lib/appImManager');
        const mid = options.getMain().mid;
        await appImManager.setInnerPeer({peerId: peerId(), lastMsgId: mid});
        const bubble = appImManager.chat?.bubbles?.getBubble(peerId(), mid);
        if(bubble) appImManager.chat.selection.toggleByElement(bubble);
      }
    },
    {
      icon: 'edit',
      regularText: 'Редактировать',
      onClick: () => openWebKMessageEditing(peerId(), options.getMain().mid),
      verify: () => managers.appMessagesManager.canEditMessage(options.getMain(), 'text')
    }, {
      icon: 'pin',
      regularText: 'Закрепить',
      onClick: async() => {
        const {default: showPinMessagePopup} = await import('@components/popups/unpinMessage');
        showPinMessagePopup(peerId(), options.getMain().mid);
      },
      verify: async() => !(await isPinned()) && await managers.appPeersManager.canPinMessage(peerId())
    }, {
      icon: 'unpin',
      regularText: 'Открепить',
      onClick: async() => {
        const {default: showPinMessagePopup} = await import('@components/popups/unpinMessage');
        showPinMessagePopup(peerId(), options.getMain().mid, true);
      },
      verify: async() => await isPinned() && await managers.appPeersManager.canPinMessage(peerId())
    }, {
      icon: 'forward',
      regularText: 'Переслать',
      onClick: async() => {
        const {default: showForwardPopup} = await import('@components/popups/forward');
        showForwardPopup({[peerId()]: mids()});
      },
      verify: canForward
    }, {
      icon: 'savedmessages',
      regularText: 'Сохранить в «Избранное»',
      onClick: async() => {
        try {
          await managers.appMessagesManager.forwardMessages({peerId: rootScope.myId, fromPeerId: peerId(), mids: mids()});
          toast('Публикация сохранена в «Избранном»');
        } catch(err) {
          console.error('VKgram: failed to save the post', err);
          toast('Не удалось сохранить публикацию');
        }
      },
      verify: canForward
    }, {
      icon: 'link',
      regularText: 'Копировать ссылку',
      onClick: async() => {
        const {url, isPrivate} = await getLink();
        copyTextToClipboard(url);
        toast(isPrivate ? 'Ссылка скопирована. Она откроется только у подписчиков канала.' : 'Ссылка скопирована');
      },
      verify: () => managers.appPeersManager.isChannel(peerId())
    }, {
      icon: 'copy',
      regularText: 'Копировать текст',
      onClick: () => {
        copyTextToClipboard(options.getMain().message);
        toast('Текст скопирован');
      },
      verify: () => !!options.getMain().message
    }, {
      icon: 'message',
      regularText: 'Открыть в «Телеграм»',
      onClick: () => openWebKMessage(peerId(), options.getMain().mid)
    }, {
      icon: 'mute',
      regularText: 'Отключить уведомления',
      separator: true,
      onClick: () => managers.appMessagesManager.togglePeerMute({peerId: peerId(), mute: true}),
      verify: async() => (await isMuted()) === false
    }, {
      icon: 'unmute',
      regularText: 'Включить уведомления',
      separator: true,
      onClick: () => managers.appMessagesManager.togglePeerMute({peerId: peerId(), mute: false}),
      verify: async() => (await isMuted()) === true
    }, {
      icon: 'flag',
      regularText: 'Пожаловаться',
      onClick: async() => {
        const {showMessageReport} = await import('@components/popups/reportAd');
        showMessageReport(peerId(), mids());
      },
      verify: async() => !options.getMain().pFlags.out && await managers.appPeersManager.isChannel(peerId())
    }, {
      icon: 'delete',
      className: 'danger',
      regularText: 'Удалить',
      onClick: async() => {
        const [{default: showDeleteMessagesPopup}, {ChatType}] = await Promise.all([
          import('@components/popups/deleteMessages'),
          import('@components/chat/chatType')
        ]);
        showDeleteMessagesPopup(peerId(), mids(), ChatType.Chat);
      },
      verify: () => managers.appMessagesManager.canDeleteMessage(options.getMain())
    }
  ];

  // A press on the ⋮ of an open menu first closes it (Web K closes menus on any press outside
  // them); the click that follows must not open it again at once — the ⋮ toggles.
  let closedAt = 0;

  // (while the menu is open Web K marks the post with `menu-open`)
  const headerEl = document.createElement('div');
  const disposeReactions = render(() => {
    const [available] = createResource(async() => {
      try {
        const res = await managers.appReactionsManager.getAvailableReactionsByMessage(options.getMain());
        return res.reactions.filter((r: any) => r._ === 'reactionEmoji').slice(0, 6) as any[];
      } catch(err) {
        return [];
      }
    });

    return (
      <div class="vk-context-menu-reactions">
        <For each={available()}>
          {(reaction) => (
            <button
              type="button"
              class="vk-reaction-quick-btn"
              onClick={() => {
                managers.appReactionsManager.sendReaction({message: options.getMain(), reaction});
                document.dispatchEvent(new KeyboardEvent('keydown', {key: 'Escape'}));
              }}
            >
              {reaction.emoticon}
            </button>
          )}
        </For>
      </div>
    );
  }, headerEl);

  const menu = createContextMenu({
    buttons,
    onElementReady: (element) => element.prepend(headerEl),
    listenTo: options.element,
    findElement: (e) => {
      if((e as any as ButtonOpenEvent).isVKButton) return options.element;
      if(isTouchPress(e)) return;
      const target = e.target as HTMLElement;
      if(target?.closest?.(NATIVE_MENU_SELECTOR)) return;
      return options.element;
    },
    onClose: () => {
      closedAt = Date.now();
    }
  });

  const originalDestroy = menu.destroy;
  menu.destroy = () => {
    disposeReactions();
    originalDestroy.call(menu);
  };

  return {
    /** The ⋮ button: the menu drops from under it, aligned to its right edge */
    openFromButton: (button: HTMLElement) => {
      if(Date.now() - closedAt < 300) return;
      const rect = button.getBoundingClientRect();
      const event: ButtonOpenEvent = {
        pageX: rect.right + window.scrollX,
        pageY: rect.bottom + window.scrollY,
        isVKButton: true
      };
      menu.open(event as any);
    },
    destroy: () => menu.destroy()
  };
}
