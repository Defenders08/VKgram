import {createEffect, createMemo, createResource, createSignal, For, on, onCleanup, onMount, Show} from 'solid-js';
import type {Message, MessageReactions, Reaction, ReactionCount} from '@layer';
import rootScope from '@lib/rootScope';
import {usePeers} from '@stores/peers';
import {AvatarNewTsx} from '@components/avatarNew';
import formatNumber from '@helpers/number/formatNumber';
import getPeerId from '@appManagers/utils/peers/getPeerId';
import VKIcon from '@/vkgram/components/VKIcons';

const LIST_LIMIT = 50;
const PICKER_LIMIT = 12;

// only what the reaction itself says: an emoji, or the paid star; a custom
// emoji has no text form here, so a neutral mark stands in for it
export function getReactionGlyph(reaction: Reaction) {
  if(reaction._ === 'reactionEmoji') return reaction.emoticon;
  if(reaction._ === 'reactionPaid') return '⭐';
  return '✦';
}

/**
 * Reactions of one post, after its content: the reactions it already has (a
 * Telegram-style round chip with the count; the one I chose is filled), «+» with the reactions
 * the channel allows, and — where Telegram lets the viewer see it — who
 * reacted. Nothing here is VKgram's own: a click goes to Web K's
 * `appReactionsManager.sendReaction`, which adds, changes (another chip) or
 * removes (my own chip again) the reaction; the list of allowed reactions is
 * `getAvailableReactionsByMessage`, the users are `getMessageReactionsList`.
 * The state follows Web K's `messages_reactions` event and the manager's answer.
 */
export default function VKChannelPostReactions(props: {message: Message.message}) {
  const peers = usePeers();

  // the freshest reactions of this post: the event / the manager's answer win over the prop
  const [latest, setLatest] = createSignal<MessageReactions>();
  createEffect(on(() => props.message.reactions, () => setLatest(undefined), {defer: true}));

  const onReactions = (updates: {message: Message.message | {peerId: PeerId, mid: number}}[]) => {
    const update = updates.find(({message}) => message.peerId === props.message.peerId && message.mid === props.message.mid);
    if(update) setLatest((update.message as Message.message).reactions ?? {_: 'messageReactions', results: [], pFlags: {}});
  };
  onMount(() => {
    rootScope.addEventListener('messages_reactions', onReactions as any);
    onCleanup(() => rootScope.removeEventListener('messages_reactions', onReactions as any));
  });

  const reactions = () => latest() ?? props.message.reactions;
  const results = createMemo(() => (reactions()?.results || []).filter((result) => result.count > 0));
  const total = () => results().reduce((sum, result) => sum + result.count, 0);
  const canSeeList = () => !!reactions()?.pFlags?.can_see_list && total() > 0;

  const send = async(reaction: Reaction) => {
    // stars cost money: paid reactions are shown, never sent from here
    if(reaction._ === 'reactionPaid') return;
    try {
      const answer = await rootScope.managers.appReactionsManager.sendReaction({message: props.message, reaction});
      setLatest(answer ?? {_: 'messageReactions', results: [], pFlags: {}});
    } catch(err) {
      console.error('VKgram: sendReaction failed', err);
    }
  };

  // * «+»: the reactions this post can get (loaded once, Web K caches the channel's settings)
  const [available] = createResource(
    () => ({peerId: props.message.peerId, mid: props.message.mid}),
    async() => {
      try {
        const {reactions} = await rootScope.managers.appReactionsManager.getAvailableReactionsByMessage(props.message);
        return reactions.filter((reaction) => reaction._ === 'reactionEmoji').slice(0, PICKER_LIMIT) as Reaction.reactionEmoji[];
      } catch(err) {
        console.error('VKgram: getAvailableReactionsByMessage failed', err);
        return [];
      }
    }
  );

  const [isPickerOpen, setPickerOpen] = createSignal(false);
  let pickerEl: HTMLDivElement;
  const onPointerDown = (e: PointerEvent) => {
    if(isPickerOpen() && !pickerEl.contains(e.target as Node)) setPickerOpen(false);
  };
  onMount(() => {
    document.addEventListener('pointerdown', onPointerDown, true);
    onCleanup(() => document.removeEventListener('pointerdown', onPointerDown, true));
  });

  // * «Кто поставил»
  const [isListOpen, setListOpen] = createSignal(false);
  const [list] = createResource(
    () => isListOpen() && canSeeList() ? {peerId: props.message.peerId, mid: props.message.mid, total: total()} : undefined,
    async({peerId, mid}) => {
      try {
        const result = await rootScope.managers.appReactionsManager.getMessageReactionsList(peerId, mid, LIST_LIMIT);
        return result.reactions.map((item) => ({peerId: getPeerId(item.peer_id), reaction: item.reaction}));
      } catch(err) {
        console.error('VKgram: getMessageReactionsList failed', err);
        return [];
      }
    }
  );
  const peerTitle = (peerId: PeerId) => {
    const peer = peers[peerId] as {title?: string, first_name?: string, last_name?: string};
    return peer?.title ?? [peer?.first_name, peer?.last_name].filter(Boolean).join(' ');
  };

  return (
    <Show when={results().length || available()?.length}>
      <div class="vk-channel-post-reactions" classList={{'is-empty': !results().length}}>
        <div class="vk-reactions">
          <For each={results()}>
            {(result: ReactionCount) => (
              <button
                type="button"
                class="vk-reaction"
                classList={{'is-chosen': result.chosen_order !== undefined}}
                disabled={result.reaction._ === 'reactionPaid'}
                aria-pressed={result.chosen_order !== undefined}
                title={result.chosen_order !== undefined ? 'Убрать реакцию' : 'Поставить реакцию'}
                onClick={() => send(result.reaction)}
              >
                <span class="vk-reaction-glyph">{getReactionGlyph(result.reaction)}</span>
                <span class="vk-reaction-count">{formatNumber(result.count, 1)}</span>
              </button>
            )}
          </For>

          <Show when={available()?.length}>
            <div class="vk-reaction-picker-holder" ref={pickerEl}>
              <button
                type="button"
                class="vk-reaction vk-reaction-add"
                aria-haspopup="true"
                aria-expanded={isPickerOpen()}
                title="Добавить реакцию"
                aria-label="Добавить реакцию"
                onClick={() => setPickerOpen((open) => !open)}
                onKeyDown={(e) => e.key === 'Escape' && setPickerOpen(false)}
              >
                <VKIcon name="smile" size={18} />
              </button>
              <Show when={isPickerOpen()}>
                <div class="vk-reaction-picker vk-block" role="menu">
                  <For each={available()}>
                    {(reaction) => (
                      <button
                        type="button"
                        class="vk-reaction-picker-item"
                        role="menuitem"
                        onClick={() => {
                          setPickerOpen(false);
                          send(reaction);
                        }}
                      >
                        {reaction.emoticon}
                      </button>
                    )}
                  </For>
                </div>
              </Show>
            </div>
          </Show>

          <Show when={canSeeList()}>
            <button
              type="button"
              class="vk-link-button vk-reactions-who"
              aria-expanded={isListOpen()}
              onClick={() => setListOpen((open) => !open)}
            >
              {isListOpen() ? 'Скрыть' : 'Кто поставил'}
            </button>
          </Show>
        </div>

        <Show when={isListOpen() && canSeeList()}>
          <Show when={!list.loading} fallback={<p class="vk-page-text vk-page-text-secondary">Загрузка…</p>}>
            <ul class="vk-reactions-list">
              <For each={list()} fallback={<li class="vk-page-text-secondary">Список недоступен.</li>}>
                {(item) => (
                  <li class="vk-reactions-list-item">
                    <AvatarNewTsx peerId={item.peerId} size={20} />
                    <span class="vk-reactions-list-name">{peerTitle(item.peerId)}</span>
                    <span>{getReactionGlyph(item.reaction)}</span>
                  </li>
                )}
              </For>
            </ul>
          </Show>
        </Show>
      </div>
    </Show>
  );
}
