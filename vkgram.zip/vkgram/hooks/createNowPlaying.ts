import {createSignal, onCleanup} from 'solid-js';
import type {MyDocument} from '@appManagers/appDocsManager';
import appMediaPlaybackController from '@components/appMediaPlaybackController';

/**
 * What Web K's global audio player is playing right now (`undefined` when it
 * is stopped) and whether it is paused. The player itself stays Web K's:
 * `appMediaPlaybackController.toggle()` plays / pauses it.
 */
export default function createNowPlaying() {
  const [playing, setPlaying] = createSignal<{doc: MyDocument, paused: boolean}>();

  const sync = () => {
    const details = appMediaPlaybackController.getPlayingDetails();
    setPlaying(details?.doc ? {doc: details.doc, paused: details.media.paused} : undefined);
  };
  const onStop = () => setPlaying(undefined);

  sync();
  appMediaPlaybackController.addEventListener('play', sync);
  appMediaPlaybackController.addEventListener('pause', sync);
  appMediaPlaybackController.addEventListener('stop', onStop);
  onCleanup(() => {
    appMediaPlaybackController.removeEventListener('play', sync);
    appMediaPlaybackController.removeEventListener('pause', sync);
    appMediaPlaybackController.removeEventListener('stop', onStop);
  });

  return playing;
}
