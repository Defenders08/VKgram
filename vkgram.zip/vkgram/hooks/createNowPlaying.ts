import {createSignal, onCleanup} from 'solid-js';
import type {MyDocument} from '@appManagers/appDocsManager';
import appMediaPlaybackController from '@components/appMediaPlaybackController';

/**
 * What Web K's global audio player is playing right now (`undefined` when it
 * is stopped) and whether it is paused. The player itself stays Web K's:
 * `appMediaPlaybackController.toggle()` plays / pauses it.
 */
export default function createNowPlaying() {
  const [playing, setPlaying] = createSignal<{doc: MyDocument, paused: boolean}>();

  const sync = () => {
    const details = appMediaPlaybackController.getPlayingDetails();
    const doc = details?.doc;
    const paused = details?.media?.paused;
    // the same state is not set again: nothing that reads it is redrawn for nothing
    setPlaying((prev) => {
      if(!doc) return prev ? undefined : prev;
      if(prev && prev.doc.id === doc.id && prev.paused === paused) return prev;
      return {doc, paused};
    });
  };
  const onStop = () => setPlaying(undefined);

  sync();
  appMediaPlaybackController.addEventListener('play', sync);
  appMediaPlaybackController.addEventListener('pause', sync);
  appMediaPlaybackController.addEventListener('stop', onStop);
  // Web K's events can come before it has the track (it is still loading): read it again shortly
  const interval = window.setInterval(sync, 300);
  onCleanup(() => {
    window.clearInterval(interval);
    appMediaPlaybackController.removeEventListener('play', sync);
    appMediaPlaybackController.removeEventListener('pause', sync);
    appMediaPlaybackController.removeEventListener('stop', onStop);
  });

  return playing;
}
