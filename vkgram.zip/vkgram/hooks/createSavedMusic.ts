import {Accessor, createEffect, createSignal, on, onCleanup} from 'solid-js';
import rootScope from '@lib/rootScope';
import type {MyDocument} from '@appManagers/appDocsManager';

/**
 * The tracks of a user's profile music (Telegram «saved music») — the same
 * list Web K's «Все треки» tab opens. The first `limit` tracks and the total.
 *
 * NB: this is the one place that talks to the server for the list:
 * `users.getSavedMusic` through Web K's apiManager, the documents are put
 * into Web K's docs storage (`saveDoc`) so wrappers can use them later. If Web K
 * on your branch has a manager method for it, swap the request below — the
 * rest of VKgram only reads `tracks()` / `count()`.
 *
 * `refreshKey` — anything that changes when the profile music changes (e.g.
 * the id of `userFull.saved_music`): the list is asked again.
 */
export default function createSavedMusic(options: {
  peerId: Accessor<PeerId>,
  limit: number,
  refreshKey?: Accessor<unknown>
}) {
  const [tracks, setTracks] = createSignal<MyDocument[]>();
  const [count, setCount] = createSignal<number>();

  let generation = 0;
  onCleanup(() => {
    generation++;
  });

  createEffect(on(() => [options.peerId(), options.refreshKey?.()] as const, async([peerId]) => {
    const current = ++generation;
    setTracks(undefined);
    setCount(undefined);
    if(!peerId) return;

    try {
      const managers = rootScope.managers;
      const inputUser = await managers.appUsersManager.getUserInput(peerId.toUserId());
      const result: any = await managers.apiManager.invokeApi('users.getSavedMusic', {
        id: inputUser,
        offset: 0,
        limit: options.limit,
        hash: 0
      });
      if(current !== generation) return;

      const documents: any[] = result?._ === 'users.savedMusic' ? result.documents : [];
      const saved = await Promise.all(documents.map((doc) => managers.appDocsManager.saveDoc(doc)));
      if(current !== generation) return;

      setTracks(saved.filter(Boolean) as MyDocument[]);
      setCount(result?.count ?? saved.length);
    } catch(err) {
      if(current !== generation) return;
      // the block is simply not drawn
      console.error('VKgram: failed to load saved music', err);
      setTracks([]);
    }
  }));

  return {tracks, count};
}
