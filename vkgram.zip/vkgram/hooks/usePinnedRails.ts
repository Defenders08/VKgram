import {onCleanup, onMount} from 'solid-js';

// the right-hand blocks of every page (see `vk-pinned` in styles/vk-base.scss)
const RAIL_SELECTOR = '.vk-news-side, .vk-media-side, .vk-channels-side, .vk-friends-side, .vk-cols > .vk-col-side';
// the gap kept between the lower edge of a rail and the bottom of the window
const BOTTOM_GAP = 10;

/**
 * Lets the right-hand blocks scroll with the page until their lower edge is `BOTTOM_GAP`
 * above the bottom of the scrolling `.vk-page`, and rest there. CSS `sticky` can only do
 * that when it knows how far the rail has to go up, so the rail's `top` is
 * `scroller height - rail height - gap` (never below 0, so a short rail stays at the top).
 * Written to `--vk-rail-top`; the stylesheet applies it on desktop only.
 */
export default function usePinnedRails(getRoot: () => HTMLElement | undefined) {
  onMount(() => {
    const root = getRoot();
    if(!root) return;

    const update = (rail: HTMLElement) => {
      const scroller = rail.closest<HTMLElement>('.vk-page');
      if(!scroller) return;
      const top = Math.min(0, scroller.clientHeight - rail.offsetHeight - BOTTOM_GAP);
      rail.style.setProperty('--vk-rail-top', `${top}px`);
    };

    const observed = new Set<HTMLElement>();
    const resizeObserver = new ResizeObserver((entries) => {
      for(const entry of entries) {
        if(entry.target instanceof HTMLElement && entry.target !== root) update(entry.target);
      }
      if(entries.some((entry) => entry.target === root)) observed.forEach(update);
    });

    // pages and their rails come and go with the section, so look for them again on every change
    const sync = () => {
      const rails = new Set(root.querySelectorAll<HTMLElement>(RAIL_SELECTOR));
      observed.forEach((rail) => {
        if(rails.has(rail)) return;
        resizeObserver.unobserve(rail);
        observed.delete(rail);
      });
      rails.forEach((rail) => {
        if(observed.has(rail)) return;
        observed.add(rail);
        resizeObserver.observe(rail);
        update(rail);
      });
    };

    const mutationObserver = new MutationObserver(sync);
    mutationObserver.observe(root, {childList: true, subtree: true});
    // the window height changes the scroller's height, which the rails' size alone does not report
    resizeObserver.observe(root);
    sync();

    onCleanup(() => {
      mutationObserver.disconnect();
      resizeObserver.disconnect();
    });
  });
}
