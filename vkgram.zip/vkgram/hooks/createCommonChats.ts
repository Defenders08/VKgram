import {Accessor, createEffect, createSignal, on, onCleanup} from 'solid-js';
import rootScope from '@lib/rootScope';

export type CommonChat = {peerId: PeerId, title: string};

/**
 * The groups that both the signed-in user and `peerId` are in
 * (`messages.getCommonChats`, the list Web K shows as «Groups in common»).
 * The first `limit` of them, oldest id first — as the server answers.
 *
 * NB: the one place that talks to the server for it: the request goes through
 * Web K's apiManager and the chats are put into Web K's chats storage
 * (`saveApiChats`), so the reactive peer store knows them for the avatars.
 * If the request fails, the list is empty and the block is not drawn.
 */
export default function createCommonChats(options: {
  peerId: Accessor<PeerId>,
  limit: number
}) {
  const [chats, setChats] = createSignal<CommonChat[]>();

  let generation = 0;
  onCleanup(() => {
    generation++;
  });

  createEffect(on(options.peerId, async(peerId) => {
    const current = ++generation;
    setChats(undefined);
    if(!peerId) return;

    try {
      const managers = rootScope.managers;
      const inputUser = await managers.appUsersManager.getUserInput(peerId.toUserId());
      const result: any = await managers.apiManager.invokeApi('messages.getCommonChats', {
        user_id: inputUser,
        max_id: 0,
        limit: options.limit
      });
      if(current !== generation) return;

      const apiChats: any[] = result?.chats ?? [];
      await managers.appChatsManager.saveApiChats(apiChats);
      if(current !== generation) return;

      setChats(apiChats
      .filter((chat) => chat?._ === 'chat' || chat?._ === 'channel')
      .map((chat) => ({peerId: (chat.id as ChatId).toPeerId(true), title: chat.title as string})));
    } catch(err) {
      if(current !== generation) return;
      console.error('VKgram: failed to load common chats', err);
      setChats([]);
    }
  }));

  return chats;
}
