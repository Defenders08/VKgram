import {createSignal, Show} from 'solid-js';
import VKHeader from '@/vkgram/components/VKHeader';
import VKMobileNav, {VK_MOBILE_MORE_ID} from '@/vkgram/components/VKMobileNav';
import VKSidebar from '@/vkgram/components/VKSidebar';
import VKMiniPlayer from '@/vkgram/components/VKMiniPlayer';
import VKContent from '@/vkgram/components/VKContent';
import type {VKLayoutProps} from '@/vkgram/layouts/VKDesktopLayout';
import type {VKSectionId} from '@/vkgram/sections';

/**
 * Mobile structure: compact header, content area, bottom navigation.
 * Not a CSS-shrunk desktop — no sidebar here at all. Sections that don't fit
 * the bottom bar are in the side menu: the header's ☰ (and the bar's «Ещё»)
 * slide it in over the content — the same list the desktop sidebar shows,
 * plus «Выйти» as its last item (desktop has «Выйти» in the header).
 * While something plays, the mini player is the first block of the side menu.
 */
export default function VKMobileLayout(props: VKLayoutProps) {
  const [isMoreOpen, setIsMoreOpen] = createSignal(false);

  const selectSection = (id: VKSectionId) => {
    setIsMoreOpen(false);
    props.onSectionChange(id);
  };

  const toggleMore = () => setIsMoreOpen((open) => !open);

  return (
    <div class="vk-mobile-layout">
      <VKHeader
        variant="mobile"
        section={props.section}
        isMenuActive={isMoreOpen()}
        menuControls={VK_MOBILE_MORE_ID}
        onMenuClick={toggleMore}
      />
      <div class="vk-mobile-body">
        <VKContent section={props.section} telegramHost={props.telegramHost} />
        <Show when={isMoreOpen()}>
          <div class="vk-mobile-drawer-layer">
            <div class="vk-mobile-backdrop" onClick={() => setIsMoreOpen(false)} />
            <aside
              id={VK_MOBILE_MORE_ID}
              class="vk-mobile-drawer"
              aria-label="Меню"
              ref={(el) => queueMicrotask(() => el.querySelector<HTMLElement>('.vk-sidebar button')?.focus())}
              onKeyDown={(e) => {
                if(e.key === 'Escape') {
                  e.stopPropagation();
                  setIsMoreOpen(false);
                }
              }}
            >
              <VKMiniPlayer variant="drawer" />
              <VKSidebar active={props.section} onSectionChange={selectSection} withLogout />
            </aside>
          </div>
        </Show>
      </div>
      <VKMobileNav
        active={props.section}
        onSectionChange={selectSection}
        isMoreOpen={isMoreOpen()}
        onMoreToggle={toggleMore}
      />
    </div>
  );
}
