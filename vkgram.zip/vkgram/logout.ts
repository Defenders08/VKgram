import rootScope from '@lib/rootScope';

/**
 * «Выйти»: Web K's own confirmation popup (the one `showLogOutPopup` shows —
 * the same popup, danger button, Escape / overlay close it), with VKgram's
 * words; on «Выйти» the session ends exactly as Web K ends it
 * (`apiManager.logOut`). Shared by the desktop header, the mobile menu and
 * «Настройки → Аккаунт → Выход».
 */
export async function confirmVKLogout() {
  const {default: confirmationPopup} = await import('@components/confirmationPopup');

  const button = {
    text: document.createTextNode('Выйти'),
    isDanger: true
  };

  try {
    await confirmationPopup({
      title: 'Выход',
      descriptionRaw: 'Вы действительно хотите выйти?',
      button,
      // the cancel button is given here too, so it reads «Отмена» whatever Web K's language is
      buttons: [button, {text: document.createTextNode('Отмена'), isCancel: true}]
    });
  } catch{
    // «Отмена», Escape or a click outside — nothing to do
    return;
  }

  rootScope.managers.apiManager.logOut();
}
