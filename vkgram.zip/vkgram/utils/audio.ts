import type {MyDocument} from '@appManagers/appDocsManager';
import getAudioTitles from '@appManagers/utils/docs/getAudioTitles';

/** «Исполнитель — Название» of a track, as the profile music shows it */
export function formatAudioTitles(doc: MyDocument) {
  const titles = getAudioTitles(doc);
  if(!titles) return doc?.type === 'voice' ? 'Голосовое сообщение' : 'Аудио';
  return [titles.performer, titles.title].filter(Boolean).join(' — ');
}

/** `m:ss` of a duration in seconds; empty when it is unknown */
export function formatDuration(seconds?: number) {
  if(!seconds) return '';
  const total = Math.round(seconds);
  return Math.floor(total / 60) + ':' + String(total % 60).padStart(2, '0');
}
