import {Show} from 'solid-js';
import type {MyDocument} from '@appManagers/appDocsManager';
import getAudioTitles from '@appManagers/utils/docs/getAudioTitles';
import {formatDuration} from '@/vkgram/utils/audio';
import VKPlayGlyph from '@/vkgram/components/VKPlayGlyph';

/** One track of a list drawn from a document: [round play] «performer — title» ..... 3:42 */
export default function VKTrackRow(props: {
  doc: MyDocument,
  isCurrent: boolean,
  isPaused: boolean,
  onPlay: () => void
}) {
  const titles = () => getAudioTitles(props.doc);
  const isPlaying = () => props.isCurrent && !props.isPaused;

  return (
    <li>
      <button
        type="button"
        class="vk-audio-row"
        classList={{'is-current': props.isCurrent}}
        onClick={() => props.onPlay()}
      >
        <span class="vk-audio-play" aria-hidden="true">
          <VKPlayGlyph playing={isPlaying()} size={14} />
        </span>

        <span class="vk-audio-info">
          <span class="vk-audio-performer">{titles()?.performer || 'Неизвестный исполнитель'}</span>
          <span class="vk-audio-dash" aria-hidden="true">{' — '}</span>
          <span class="vk-audio-title">{titles()?.title || 'Аудио'}</span>
        </span>

        <Show when={isPlaying()}>
          <span class="vk-audio-eq" aria-hidden="true"><i /><i /><i /></span>
        </Show>

        <span class="vk-audio-duration">{formatDuration(props.doc.duration, true)}</span>
      </button>
    </li>
  );
}
