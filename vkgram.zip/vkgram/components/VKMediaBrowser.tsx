import {createEffect, createSignal, For, JSX, Match, on, onCleanup, onMount, Show, Switch} from 'solid-js';
import type {Message} from '@layer';
import type {MyInputMessagesFilter} from '@appManagers/appMessagesManager';
import rootScope from '@lib/rootScope';
import {usePeers} from '@stores/peers';
import {formatDateAccordingToTodayNew} from '@helpers/date';
import {getVKSection, VKSectionId} from '@/vkgram/sections';
import {openWebKMessage} from '@/vkgram/webk';
import createMediaSearch from '@/vkgram/hooks/createMediaSearch';
import createChannelHistory from '@/vkgram/pages/channel/createChannelHistory';
import VKChannelPostMedia from '@/vkgram/pages/channel/VKChannelPostMedia';
import VKTabs from '@/vkgram/components/VKTabs';
import VKSearchField from '@/vkgram/components/VKSearchField';
import VKEmptyState from '@/vkgram/components/VKEmptyState';
import {VKAudioRows} from '@/vkgram/components/VKAudioItem';
import type {VKIconName} from '@/vkgram/components/VKIcons';

// how long typing may pause before the search is sent (ms)
const SEARCH_DELAY = 400;

export type VKMediaKind = 'photos' | 'videos' | 'docs' | 'music' | 'voice';
export type VKMediaSource = 'search' | 'saved';

const KINDS: {[kind in VKMediaKind]: {
  filter: MyInputMessagesFilter,
  layout: 'grid' | 'list',
  icon: VKIconName,
  placeholder: string,
  empty: {[source in VKMediaSource]: string}
}} = {
  photos: {
    filter: 'inputMessagesFilterPhotos',
    layout: 'grid',
    icon: 'photos',
    placeholder: 'Поиск фотографий',
    empty: {search: 'Фотографий не найдено', saved: 'В «Избранном» нет фотографий'}
  },
  videos: {
    filter: 'inputMessagesFilterVideo',
    layout: 'grid',
    icon: 'videos',
    placeholder: 'Поиск видеозаписей',
    empty: {search: 'Видеозаписей не найдено', saved: 'В «Избранном» нет видеозаписей'}
  },
  docs: {
    filter: 'inputMessagesFilterDocument',
    layout: 'list',
    icon: 'docs',
    placeholder: 'Поиск файлов',
    empty: {search: 'Файлов не найдено', saved: 'В «Избранном» нет файлов'}
  },
  music: {
    filter: 'inputMessagesFilterMusic',
    layout: 'list',
    icon: 'audio',
    placeholder: 'Поиск музыки',
    empty: {search: 'Музыки не найдено', saved: 'В «Избранном» нет музыки'}
  },
  voice: {
    filter: 'inputMessagesFilterVoice',
    layout: 'list',
    icon: 'messages',
    placeholder: 'Поиск голосовых сообщений',
    empty: {search: 'Голосовых сообщений не найдено', saved: 'В «Избранном» нет голосовых сообщений'}
  }
};

// «из <chat> · <date>» under a file: where it was found, a click opens it there
function MediaSource(props: {message: Message.message}) {
  const peers = usePeers();
  const title = () => {
    if(props.message.peerId === rootScope.myId) return 'Избранное';
    const peer = peers[props.message.peerId] as {title?: string, first_name?: string, last_name?: string};
    return peer?.title ?? [peer?.first_name, peer?.last_name].filter(Boolean).join(' ');
  };

  return (
    <button
      type="button"
      class="vk-media-row-source"
      title="Открыть в «Телеграм»"
      onClick={() => openWebKMessage(props.message.peerId, props.message.mid)}
    >
      <span class="vk-media-row-source-title">{title()}</span>
      <span>{'· '}{formatDateAccordingToTodayNew(new Date(props.message.date * 1000))}</span>
    </button>
  );
}

/**
 * One list of media: found by Telegram's global search (`source: 'search'`,
 * `createMediaSearch`, with a search field) or kept in «Избранное» — the
 * user's saved messages (`source: 'saved'`, `createChannelHistory` over them,
 * the same filtered search Web K's shared media runs). Only the given kind:
 * photos, videos, files, music or voice messages.
 *
 * Everything is drawn by Web K's own wrappers (`VKChannelPostMedia`): a photo
 * or a video opens the media viewer, a file downloads, music and voice play in
 * Web K's global player. Older items come as the end of the list comes near.
 */
export function VKMediaList(props: {kind: VKMediaKind, source: VKMediaSource}) {
  const config = KINDS[props.kind];
  // music and voice messages are drawn as audio rows (VKAudioRows); Web K's global player is what plays
  const isAudio = props.kind === 'music' || props.kind === 'voice';

  const [query, setQuery] = createSignal('');
  // what is searched: the query once typing pauses
  const [searched, setSearched] = createSignal('');
  createEffect(on(query, (value) => {
    const timer = window.setTimeout(() => setSearched(value.trim()), SEARCH_DELAY);
    onCleanup(() => clearTimeout(timer));
  }, {defer: true}));

  const list = props.source === 'search' ?
    createMediaSearch({query: searched, inputFilter: config.filter}) :
    createChannelHistory({peerId: () => rootScope.myId, inputFilter: config.filter, pageSize: 30});

  const [sentinel, setSentinel] = createSignal<HTMLElement>();
  createEffect(() => {
    const element = sentinel();
    // a new page re-arms the observer: a sentinel still in view has nothing to report by itself
    void list.messages().length;
    if(!element || list.status() !== 'loaded' || list.isEnd() || list.isLoadingMore()) return;

    const observer = new IntersectionObserver((entries) => {
      if(entries.some((entry) => entry.isIntersecting)) list.loadMore();
    }, {rootMargin: '400px'});
    observer.observe(element);
    onCleanup(() => observer.disconnect());
  });

  return (
    // data-kind: lets a section (e.g. «Аудиозаписи») style its music and voice rows apart
    <div class="vk-media-list" data-kind={props.kind}>
      <Show when={props.source === 'search'}>
        <VKSearchField value={query()} placeholder={config.placeholder} onInput={setQuery} />
      </Show>

      <Switch>
        <Match when={list.status() === 'loading'}>
          <p class="vk-page-text vk-page-text-secondary vk-list-empty">Загрузка…</p>
        </Match>

        <Match when={list.status() === 'error'}>
          <p class="vk-page-text vk-page-text-secondary vk-list-empty">
            Не удалось загрузить.{' '}
            <button type="button" class="vk-link-button" onClick={() => list.reload()}>Повторить</button>
          </p>
        </Match>

        <Match when={!list.messages().length}>
          <VKEmptyState
            icon={config.icon}
            title={config.empty[props.source]}
            description={props.source === 'search' ?
              (searched() ? 'Попробуйте другой запрос.' : 'Здесь появятся медиа из ваших чатов.') :
              'Сохраняйте публикации и сообщения в «Избранное» — они появятся здесь.'}
          />
        </Match>

        <Match when={config.layout === 'grid'}>
          <div class="vk-media-grid">
            <For each={list.messages()}>
              {(message) => (
                <div class="vk-media-tile">
                  <VKChannelPostMedia message={message} boxSize={240} />
                </div>
              )}
            </For>
          </div>
        </Match>

        <Match when={config.layout === 'list'}>
          <Show
            when={isAudio}
            fallback={
              <ul class="vk-media-rows">
                <For each={list.messages()}>
                  {(message) => (
                    <li class="vk-media-row">
                      <VKChannelPostMedia message={message} asFile={props.kind === 'docs'} />
                      <MediaSource message={message} />
                    </li>
                  )}
                </For>
              </ul>
            }
          >
            <VKAudioRows messages={list.messages()} />
          </Show>
        </Match>
      </Switch>

      <div ref={setSentinel} class="vk-list-sentinel" />
      <Show when={list.isLoadingMore()}>
        <p class="vk-page-text vk-page-text-secondary">Загрузка…</p>
      </Show>
    </div>
  );
}

export type VKMediaTab<T extends string> = {
  id: T,
  title: string,
  render: () => JSX.Element
};

// the last open tab of each section: coming back to a section opens it again
const lastTabs = new Map<VKSectionId, string>();

/**
 * A media section of the left menu («Фотографии», «Видеозаписи», «Документы»,
 * «Аудиозаписи»): the title and Telegram-like tabs over the content — one list
 * per tab, mounted anew when the tab is opened.
 */
export default function VKMediaPage<T extends string>(props: {
  section: VKSectionId,
  tabs: VKMediaTab<T>[]
}) {
  const section = () => getVKSection(props.section);
  const idPrefix = `vk-${props.section}`;
  const [tab, setTab] = createSignal<T>((lastTabs.get(props.section) as T) ?? props.tabs[0].id);
  createEffect(() => lastTabs.set(props.section, tab()));

  const current = () => props.tabs.find((item) => item.id === tab()) ?? props.tabs[0];

  // Like the News page, desktop and mobile use separate tab layouts. Only one
  // is mounted at a time so the same tab state is never represented by two
  // interactive tablists.
  const [isDesktop, setIsDesktop] = createSignal(
    typeof window !== 'undefined' && window.matchMedia('(min-width: 601px)').matches
  );
  onMount(() => {
    const media = window.matchMedia('(min-width: 601px)');
    const update = () => setIsDesktop(media.matches);
    update();
    media.addEventListener?.('change', update);
    onCleanup(() => media.removeEventListener?.('change', update));
  });

  const tabs = () => props.tabs.map(({id, title}) => ({id, title}));

  return (
    <div class={`vk-page vk-media-page vk-${props.section}`}>
      <div class="vk-media-layout">
        <main class="vk-media-main">
          <section class="vk-block vk-page-block" aria-labelledby={`${idPrefix}-title`}>
            <h1 id={`${idPrefix}-title`} class="vk-page-title">{section().title}</h1>
            <Show when={!isDesktop()}>
              <VKTabs
                tabs={tabs()}
                active={current().id}
                onChange={(id) => setTab(() => id)}
                idPrefix={`${idPrefix}-mobile`}
                label={section().title}
              />
            </Show>
            <Show when={current()} keyed>
              {(item) => (
                <div id={`${idPrefix}-panel-${item.id}`} role="tabpanel" aria-labelledby={`${idPrefix}-mobile-tab-${item.id} ${idPrefix}-desktop-tab-${item.id}`}>
                  {item.render()}
                </div>
              )}
            </Show>
          </section>
        </main>

        <Show when={isDesktop()}>
          <aside class="vk-media-side" aria-label={`Навигация: ${section().title}`}>
            <section class="vk-block vk-media-side-block">
              <VKTabs
                tabs={tabs()}
                active={current().id}
                onChange={(id) => setTab(() => id)}
                idPrefix={`${idPrefix}-desktop`}
                label={section().title}
              />
            </section>
          </aside>
        </Show>
      </div>
    </div>
  );
}
