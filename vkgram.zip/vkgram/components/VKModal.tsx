import {createUniqueId, JSX, onCleanup, onMount} from 'solid-js';
import {Portal} from 'solid-js/web';
import VKIcon from '@/vkgram/components/VKIcons';

// what the Tab key can land on inside the dialog
const FOCUSABLE = [
  'a[href]',
  'button:not(:disabled)',
  'input:not(:disabled):not([type="hidden"])',
  'select:not(:disabled)',
  'textarea:not(:disabled)',
  '[contenteditable]:not([contenteditable="false"])',
  '[tabindex]:not([tabindex="-1"])'
].join(',');

// the first thing worth typing into
const FIELD = 'input:not(:disabled):not([type="hidden"]):not([type="checkbox"]):not([type="radio"]), textarea:not(:disabled), select:not(:disabled), [contenteditable]:not([contenteditable="false"])';

/**
 * A modal dialog in the look of the «Настройки ленты» panel: the same white
 * card, border, title, dividers and buttons, over a dimmed layer.
 *
 * It is a layer of the VKgram root (`.vkgram`) — a portal into it, so the
 * VKgram styles and tokens (day / night) apply and the page underneath is
 * neither moved nor re-laid-out. What goes inside is up to the caller: the
 * head (title and «×») is drawn here, the rest is `children` — usually a
 * `.vk-modal-body` (it scrolls when the content is long) and a `.vk-modal-foot`
 * (the buttons).
 *
 * Mount it with `<Show when={open}>`: it lives as long as it is rendered.
 *  - closes on «×» and on Escape (`onClose`); a click on the dimmed layer
 *    closes it only with `closeOnBackdrop` — a form should not lose what was
 *    typed to a stray click, so it is off by default;
 *  - `closeDisabled` holds all of those while something is being saved;
 *  - focus goes into the dialog, Tab stays inside it, and on close the focus
 *    returns to what opened it;
 *  - the layer scrolls on a tiny screen, and the page behind it can't be
 *    reached by the wheel or by touch.
 */
export default function VKModal(props: {
  title: string,
  onClose: () => void,
  closeDisabled?: boolean,
  closeOnBackdrop?: boolean,
  // the width on a wide screen, px (440 by default); a narrow screen takes its whole width anyway
  width?: number,
  children: JSX.Element
}) {
  const titleId = 'vk-modal-title-' + createUniqueId();
  let dialog: HTMLDivElement;

  const opener = document.activeElement instanceof HTMLElement ? document.activeElement : undefined;

  const close = () => {
    if(!props.closeDisabled) props.onClose();
  };

  const onKeyDown = (e: KeyboardEvent) => {
    if(e.isComposing) return;

    if(e.key === 'Escape') {
      // this dialog is the topmost thing: nothing under it should react to Escape
      e.stopImmediatePropagation();
      e.preventDefault();
      close();
      return;
    }

    if(e.key !== 'Tab' || !dialog) return;

    const items = Array.from(dialog.querySelectorAll<HTMLElement>(FOCUSABLE))
    .filter((el) => el.getClientRects().length);
    if(!items.length) {
      e.preventDefault();
      dialog.focus();
      return;
    }

    const first = items[0];
    const last = items[items.length - 1];
    const active = document.activeElement;
    if(!dialog.contains(active) || active === dialog) {
      e.preventDefault();
      (e.shiftKey ? last : first).focus();
    } else if(e.shiftKey && active === first) {
      e.preventDefault();
      last.focus();
    } else if(!e.shiftKey && active === last) {
      e.preventDefault();
      first.focus();
    }
  };

  onMount(() => {
    document.addEventListener('keydown', onKeyDown, true);

    // after the portal is in the document; something inside may have taken the focus by itself
    queueMicrotask(() => {
      if(!dialog || dialog.contains(document.activeElement)) return;
      // on a touch screen a field in focus would raise the keyboard over the dialog at once
      const isTouch = matchMedia('(pointer: coarse)').matches;
      const target = isTouch ? dialog : dialog.querySelector<HTMLElement>(FIELD) ?? dialog;
      target.focus();
    });
  });

  onCleanup(() => {
    document.removeEventListener('keydown', onKeyDown, true);
    if(opener?.isConnected) opener.focus({preventScroll: true});
  });

  // a drag that began inside the dialog and ended on the layer is not a click on the layer
  let isPressOnLayer = false;

  return (
    <Portal mount={document.querySelector('.vkgram') ?? document.body}>
      <div
        class="vk-modal-layer"
        onPointerDown={(e) => isPressOnLayer = e.target === e.currentTarget}
        onClick={(e) => {
          if(props.closeOnBackdrop && isPressOnLayer && e.target === e.currentTarget) close();
          isPressOnLayer = false;
        }}
      >
        <div
          ref={dialog}
          class="vk-modal"
          role="dialog"
          aria-modal="true"
          aria-labelledby={titleId}
          style={props.width ? {'--vk-modal-width': props.width + 'px'} : undefined}
          tabIndex={-1}
        >
          <div class="vk-modal-head">
            <h2 id={titleId} class="vk-modal-title">{props.title}</h2>
            <button
              type="button"
              class="vk-link-button vk-modal-close"
              aria-label="Закрыть"
              title="Закрыть"
              disabled={props.closeDisabled}
              onClick={close}
            >
              <VKIcon name="close" size={14} />
            </button>
          </div>
          {props.children}
        </div>
      </div>
    </Portal>
  );
}
