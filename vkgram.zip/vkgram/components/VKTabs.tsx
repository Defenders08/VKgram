import {children, For, JSX, Show} from 'solid-js';
import formatNumber from '@helpers/number/formatNumber';

export type VKTabItem<T extends string> = {
  id: T,
  title: string,
  // a number after the title
  count?: number
};

/**
 * Tabs of a VKgram block (the `.vk-tabs` / `.vk-tab` look of the channel's
 * «Лента»): a tablist with the arrow keys moving between the tabs. The page
 * owns the panel — it gives it `id="<idPrefix>-panel-<tab id>"` and
 * `aria-labelledby="<idPrefix>-tab-<tab id>"`. Tabs that do not fit wrap to the
 * next line; `actions` stays at the right end of the strip. `onAdd` puts a «+»
 * button after the last tab.
 */
export default function VKTabs<T extends string>(props: {
  tabs: VKTabItem<T>[],
  active: T,
  onChange: (id: T) => void,
  idPrefix: string,
  label?: string,
  // a control at the right end of the strip (it is not a tab)
  actions?: JSX.Element,
  // «+» right after the last tab (it is not a tab either): what it does and how it is called
  onAdd?: () => void,
  addLabel?: string
}) {
  // `props.actions` is a getter that builds the component on every read: reading it twice
  // (`when` + the content) made two instances, and the one that was never in the DOM kept its
  // own outside-click listener (its `contains` is always false) and closed the panel.
  // `children` resolves it once.
  const actions = children(() => props.actions);

  const onKeyDown = (e: KeyboardEvent) => {
    if(e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
    // the arrows walk the tabs; «+» is not one of them
    if(!(e.target as HTMLElement).closest('[role="tab"]')) return;
    e.preventDefault();
    const index = props.tabs.findIndex((tab) => tab.id === props.active);
    const step = e.key === 'ArrowRight' ? 1 : -1;
    const next = props.tabs[(index + step + props.tabs.length) % props.tabs.length];
    props.onChange(next.id);
    document.getElementById(`${props.idPrefix}-tab-${next.id}`)?.focus();
  };

  return (
    <div class="vk-tabs">
      <div class="vk-tabs-list" role="tablist" aria-label={props.label} onKeyDown={onKeyDown}>
        <For each={props.tabs}>
          {(tab) => (
            <button
              type="button"
              id={`${props.idPrefix}-tab-${tab.id}`}
              class="vk-tab"
              classList={{'is-active': props.active === tab.id}}
              role="tab"
              aria-selected={props.active === tab.id}
              aria-controls={`${props.idPrefix}-panel-${tab.id}`}
              tabindex={props.active === tab.id ? 0 : -1}
              onClick={() => props.onChange(tab.id)}
            >
              {tab.title}
              <Show when={tab.count}>
                <span class="vk-tab-count"> {formatNumber(tab.count, 1)}</span>
              </Show>
            </button>
          )}
        </For>
        <Show when={props.onAdd}>
          <button
            type="button"
            class="vk-tab vk-tab-add"
            title={props.addLabel}
            aria-label={props.addLabel}
            onClick={() => props.onAdd?.()}
          >
            +
          </button>
        </Show>
      </div>
      <Show when={actions()}>
        <div class="vk-tabs-actions">{actions()}</div>
      </Show>
    </div>
  );
}
