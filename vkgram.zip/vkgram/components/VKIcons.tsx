import {JSX} from 'solid-js';

/**
 * VKgram's own section icons — thin line glyphs at home in the old VK left
 * menu (deliberately not Web K's `tgico` set: these belong to the VK look,
 * not to Telegram's). 24×24 viewBox, stroked with `currentColor`, so color
 * and size come from the surrounding control.
 */

export type VKIconName =
  | 'profile'
  | 'news'
  | 'messages'
  | 'telegram'
  | 'friends'
  | 'groups'
  | 'channels'
  | 'audio'
  | 'photos'
  | 'videos'
  | 'docs'
  | 'apps'
  | 'settings'
  | 'search'
  | 'close'
  | 'more'
  | 'more-vertical'
  | 'back'
  | 'up'
  | 'logout'
  | 'bell'
  | 'bell-off'
  | 'discussion'
  | 'select'
  | 'gift'
  | 'boost'
  | 'flag'
  | 'share'
  | 'edit'
  | 'smile';

const ICONS: {[name in VKIconName]: () => JSX.Element} = {
  profile: () => (
    <>
      <circle cx="12" cy="8" r="3.6" />
      <path d="M5 19.5c0-3.3 3-5.2 7-5.2s7 1.9 7 5.2" />
    </>
  ),
  news: () => (
    <>
      <rect x="3.5" y="5" width="13" height="14" rx="1.5" />
      <path d="M16.5 8H19a1.5 1.5 0 0 1 1.5 1.5v8a1.5 1.5 0 0 1-1.5 1.5h-2.5" />
      <line x1="7" y1="9" x2="13" y2="9" />
      <line x1="7" y1="12" x2="13" y2="12" />
      <line x1="7" y1="15" x2="10.5" y2="15" />
    </>
  ),
  messages: () => (
    <>
      <rect x="3.5" y="5.5" width="17" height="13" rx="1.5" />
      <path d="m5.5 8 5.3 3.8c.7.5 1.7.5 2.4 0L18.5 8" />
    </>
  ),
  telegram: () => (
    <>
      <path d="M21 4 3.7 10.7c-.9.35-.85 1.65.08 1.9l4.45 1.2 1.65 5.05c.28.86 1.37 1.08 2.12.42l2.45-2.16 4.28 3.05c.77.55 1.84.14 2.02-.79L23 5.35C23.2 4.43 22.05 3.6 21 4Z" />
      <path d="m8.4 13.8 9.9-6.3-6.7 8.1" />
    </>
  ),
  friends: () => (
    <>
      <circle cx="9.5" cy="8.5" r="3.5" />
      <path d="M3.5 19.5c0-3.3 2.7-5.2 6-5.2s6 1.9 6 5.2" />
      <path d="M16 5.3a3 3 0 0 1 0 5.9" />
      <path d="M17.5 14.7c1.9.6 3 2.1 3 4.3" />
    </>
  ),
  groups: () => (
    <>
      <circle cx="12" cy="9" r="3.4" />
      <path d="M6 19.5c0-3.1 2.7-4.9 6-4.9s6 1.8 6 4.9" />
      <path d="M6.4 6.2a2.7 2.7 0 0 0-.2 5.2" />
      <path d="M4.3 13.4c-1 .8-1.6 1.9-1.6 3.4" />
      <path d="M17.6 6.2a2.7 2.7 0 0 1 .2 5.2" />
      <path d="M19.7 13.4c1 .8 1.6 1.9 1.6 3.4" />
    </>
  ),
  channels: () => (
    <>
      <path d="M4 10v4h2.5L11 17.5v-11L6.5 10H4Z" />
      <path d="M14.5 9.5a3.5 3.5 0 0 1 0 5" />
      <path d="M17 7.5a6 6 0 0 1 0 9" />
    </>
  ),
  audio: () => (
    <>
      <path d="M9 18V6.5l10-2V16" />
      <line x1="9" y1="10" x2="19" y2="8" />
      <circle cx="6.5" cy="18" r="2.5" />
      <circle cx="16.5" cy="16" r="2.5" />
    </>
  ),
  photos: () => (
    <>
      <rect x="3.5" y="5" width="17" height="14" rx="1.5" />
      <circle cx="9" cy="10" r="1.6" />
      <path d="m4 17 5-4.5 3.5 3 3-2.5L20 17" />
    </>
  ),
  videos: () => (
    <>
      <rect x="3.5" y="6" width="12.5" height="12" rx="1.5" />
      <path d="m16 10.5 4.5-2.5v8L16 13.5" />
    </>
  ),
  docs: () => (
    <>
      <path d="M14 3.5H7.5A1.5 1.5 0 0 0 6 5v14a1.5 1.5 0 0 0 1.5 1.5h9A1.5 1.5 0 0 0 18 19V7.5L14 3.5Z" />
      <path d="M14 3.5v4h4" />
      <line x1="9" y1="12.5" x2="15" y2="12.5" />
      <line x1="9" y1="16" x2="13" y2="16" />
    </>
  ),
  apps: () => (
    <>
      <rect x="4" y="4" width="6.5" height="6.5" rx="1" />
      <rect x="13.5" y="4" width="6.5" height="6.5" rx="1" />
      <rect x="4" y="13.5" width="6.5" height="6.5" rx="1" />
      <rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1" />
    </>
  ),
  settings: () => (
    <>
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.7 1.7 0 0 0 .34 1.87l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.7 1.7 0 0 0 9 19.4a1.7 1.7 0 0 0-1.87.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.7 1.7 0 0 0 4.6 15a1.7 1.7 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.7 1.7 0 0 0 4.6 9a1.7 1.7 0 0 0-.34-1.87l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.7 1.7 0 0 0 1 1.51 1.7 1.7 0 0 0 1.87-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.7 1.7 0 0 0 19.4 9c.28.63.9 1.04 1.51 1H21a2 2 0 1 1 0 4h-.09a1.7 1.7 0 0 0-1.51 1Z" />
    </>
  ),
  search: () => (
    <>
      <circle cx="11" cy="11" r="7" />
      <line x1="20.5" y1="20.5" x2="16" y2="16" />
    </>
  ),
  close: () => (
    <>
      <line x1="18" y1="6" x2="6" y2="18" />
      <line x1="6" y1="6" x2="18" y2="18" />
    </>
  ),
  more: () => (
    <>
      <line x1="5" y1="12" x2="5.01" y2="12" />
      <line x1="12" y1="12" x2="12.01" y2="12" />
      <line x1="19" y1="12" x2="19.01" y2="12" />
    </>
  ),
  'more-vertical': () => (
    <>
      <line x1="12" y1="5" x2="12" y2="5.01" />
      <line x1="12" y1="12" x2="12" y2="12.01" />
      <line x1="12" y1="19" x2="12" y2="19.01" />
    </>
  ),
  back: () => (
    <>
      <line x1="19" y1="12" x2="5" y2="12" />
      <polyline points="12 19 5 12 12 5" />
    </>
  ),
  up: () => (
    <>
      <line x1="12" y1="19" x2="12" y2="5" />
      <polyline points="5 12 12 5 19 12" />
    </>
  ),
  logout: () => (
    <>
      <path d="M14 4.5h3.5A1.5 1.5 0 0 1 19 6v12a1.5 1.5 0 0 1-1.5 1.5H14" />
      <polyline points="9.5 8 5.5 12 9.5 16" />
      <line x1="5.5" y1="12" x2="14.5" y2="12" />
    </>
  ),
  bell: () => (
    <>
      <path d="M6.5 16.5V11a5.5 5.5 0 0 1 11 0v5.5l1.5 1.5H5l1.5-1.5Z" />
      <path d="M10 20.5a2 2 0 0 0 4 0" />
    </>
  ),
  'bell-off': () => (
    <>
      <path d="M6.5 16.5V11a5.5 5.5 0 0 1 11 0v5.5l1.5 1.5H5l1.5-1.5Z" />
      <path d="M10 20.5a2 2 0 0 0 4 0" />
      <line x1="4" y1="4" x2="20" y2="20" />
    </>
  ),
  discussion: () => (
    <>
      <path d="M4 5.5h16v11H11l-4 3.5v-3.5H4Z" />
      <line x1="8" y1="10" x2="16" y2="10" />
      <line x1="8" y1="13" x2="13" y2="13" />
    </>
  ),
  select: () => (
    <>
      <rect x="4" y="4" width="16" height="16" rx="1.5" />
      <polyline points="8 12.5 11 15.5 16.5 9" />
    </>
  ),
  gift: () => (
    <>
      <rect x="4" y="11" width="16" height="9" />
      <rect x="3" y="7.5" width="18" height="3.5" />
      <line x1="12" y1="7.5" x2="12" y2="20" />
      <path d="M12 7.5 8 4.5 7 7.5h5Zm0 0 4-3 1 3h-5Z" />
    </>
  ),
  boost: () => <path d="M13.5 3 5.5 13.5H11L10 21l8.5-10.5H13l.5-7.5Z" />,
  flag: () => (
    <>
      <line x1="6" y1="4" x2="6" y2="21" />
      <path d="M6 5h12l-2.5 4 2.5 4H6" />
    </>
  ),
  edit: () => (
    <>
      <path d="M4.5 19.5v-4l11-11 4 4-11 11h-4Z" />
      <line x1="13" y1="7" x2="17" y2="11" />
    </>
  ),
  share: () => (
    <>
      <path d="M8.5 10H5.5v10.5h13V10h-3" />
      <line x1="12" y1="15" x2="12" y2="3.5" />
      <polyline points="8 7.5 12 3.5 16 7.5" />
    </>
  ),
  smile: () => (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M8.5 14c.8 1.3 2 2 3.5 2s2.7-.7 3.5-2" />
      <line x1="9.5" y1="9.8" x2="9.5" y2="9.81" />
      <line x1="14.5" y1="9.8" x2="14.5" y2="9.81" />
    </>
  )
};

export default function VKIcon(props: {name: VKIconName, size?: number, class?: string}) {
  return (
    <svg
      class={props.class}
      width={props.size ?? 18}
      height={props.size ?? 18}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="1.8"
      stroke-linecap="round"
      stroke-linejoin="round"
      aria-hidden="true"
    >
      {ICONS[props.name]()}
    </svg>
  );
}
