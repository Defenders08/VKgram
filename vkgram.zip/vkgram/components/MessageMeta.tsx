import {Show} from 'solid-js';
import type {Message} from '@layer';
import {formatDateAccordingToTodayNew} from '@helpers/date';
import formatNumber from '@helpers/number/formatNumber';

/**
 * Универсальный компонент для отображения метаданных сообщения.
 * Адаптируется в зависимости от варианта (чат или пост канала).
 */
export default function MessageMeta(props: {
  message: Message.message,
  variant: 'chat' | 'channel-post',
  showViews?: boolean,
  showCommentsCount?: number,
  onCommentsClick?: () => void
}) {
  const time = () => formatDateAccordingToTodayNew(new Date(props.message.date * 1000));

  // Для чатов — только время
  if(props.variant === 'chat') {
    return <time class="vk-custom-message-time">{time()}</time>;
  }

  // Для постов каналов — полная метаинформация
  return (
    <footer class="vk-channel-post-meta vk-page-text-secondary">
      <Show when={props.showViews && props.message.views}>
        <span title="Просмотры">👁 {formatNumber(props.message.views, 1)}</span>
      </Show>
      <Show when={props.showCommentsCount !== undefined}>
        <button
          type="button"
          class="vk-link-button vk-channel-post-comments"
          title="Комментарии"
          onClick={props.onCommentsClick}
        >
          💬 {props.showCommentsCount ? `Комментарии: ${formatNumber(props.showCommentsCount, 1)}` : 'Комментировать'}
        </button>
      </Show>
    </footer>
  );
}
