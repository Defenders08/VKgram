import {Show} from 'solid-js';
import type {Message} from '@layer';
import {formatDateAccordingToTodayNew} from '@helpers/date';
import formatNumber from '@helpers/number/formatNumber';
import VKIcon from '@/vkgram/components/VKIcons';

/**
 * Универсальный компонент для отображения метаданных сообщения.
 * Адаптируется в зависимости от варианта (чат или пост канала).
 */
export default function MessageMeta(props: {
  message: Message.message,
  variant: 'chat' | 'channel-post',
  showCommentsCount?: number,
  onCommentsClick?: () => void,
  // «Переслать» (Web K's forward popup); without it the button is not shown
  onForwardClick?: () => void
}) {
  const time = () => formatDateAccordingToTodayNew(new Date(props.message.date * 1000));

  // Для чатов — только время
  if(props.variant === 'chat') {
    return <time class="vk-custom-message-time">{time()}</time>;
  }

  // Для постов каналов — полная метаинформация
  return (
    <footer class="vk-channel-post-meta vk-page-text-secondary">
      <Show when={props.showCommentsCount !== undefined}>
        <button
          type="button"
          class="vk-link-button vk-channel-post-comments"
          title="Комментарии"
          onClick={props.onCommentsClick}
        >
          💬 {props.showCommentsCount ? `Комментарии: ${formatNumber(props.showCommentsCount, 1)}` : 'Комментировать'}
        </button>
      </Show>
      <Show when={props.onForwardClick}>
        <button
          type="button"
          class="vk-link-button vk-channel-post-share"
          title="Переслать"
          aria-label="Переслать публикацию"
          onClick={props.onForwardClick}
        >
          <VKIcon name="forward" size={16} />
          <span>Переслать</span>
          <Show when={props.message.forwards}>
            <span class="vk-channel-post-share-count">{formatNumber(props.message.forwards!, 1)}</span>
          </Show>
        </button>
      </Show>
    </footer>
  );
}
