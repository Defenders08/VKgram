import {Accessor, createEffect, createSignal, For, onCleanup, Show} from 'solid-js';
import type {Message} from '@layer';
import type {MyDocument} from '@appManagers/appDocsManager';
import getMediaFromMessage from '@appManagers/utils/messages/getMediaFromMessage';
import getAudioTitles from '@appManagers/utils/docs/getAudioTitles';
import appMediaPlaybackController from '@components/appMediaPlaybackController';
import rootScope from '@lib/rootScope';
import {usePeers} from '@stores/peers';
import {formatDateAccordingToTodayNew} from '@helpers/date';
import {openWebKMessage} from '@/vkgram/webk';
import createNowPlaying from '@/vkgram/hooks/createNowPlaying';
import createPlaybackTime from '@/vkgram/hooks/createPlaybackTime';
import {formatDuration, formatTime} from '@/vkgram/utils/audio';
import VKChannelPostMedia from '@/vkgram/pages/channel/VKChannelPostMedia';
import VKPlayGlyph from '@/vkgram/components/VKPlayGlyph';

// a small chat icon at the right end of a row: «<chat> · <date>» is its hint, a click opens the message
function AudioSource(props: {message: Message.message}) {
  const peers = usePeers();
  const title = () => {
    if(props.message.peerId === rootScope.myId) return 'Избранное';
    const peer = peers[props.message.peerId] as {title?: string, first_name?: string, last_name?: string};
    return peer?.title ?? [peer?.first_name, peer?.last_name].filter(Boolean).join(' ');
  };
  const date = () => formatDateAccordingToTodayNew(new Date(props.message.date * 1000));

  return (
    <button
      type="button"
      class="vk-audio-source"
      title={`${title()} · ${date()}\nОткрыть в «Телеграм»`}
      aria-label={`Открыть в «Телеграм»: ${title()}`}
      onClick={() => openWebKMessage(props.message.peerId, props.message.mid)}
    >
      <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
        <path d="M4.5 5.5h15v10.5H10l-4.5 3.5V16h-1z" />
      </svg>
    </button>
  );
}

export type VKNowPlaying = {doc: MyDocument, paused: boolean} | undefined;

/**
 * A track / a voice message of a list, in the old VK's audio-row shape: [round play]
 * «performer — title» ..... 3:42, «<chat> · <time>» under it. The row is drawn here, from the
 * document; the playback is not: Web K's own audio element (`VKChannelPostMedia`) stays in the
 * row, invisible, and a click on the row presses its toggle — so the download, the playlist
 * (the next / previous track) and the global player are exactly Web K's. The track that is
 * playing right now is paused / resumed through the global player.
 */
function AudioItem(props: {
  message: Message.message,
  playing: Accessor<VKNowPlaying>,
  time: Accessor<number>
}) {
  let native!: HTMLDivElement;

  const doc = () => getMediaFromMessage(props.message, true) as MyDocument | undefined;
  const isVoice = () => doc()?.type === 'voice';
  const titles = () => {
    const document = doc();
    return document && !isVoice() ? getAudioTitles(document) : undefined;
  };
  const performer = () => titles()?.performer;
  const title = () => isVoice() ? 'Голосовое сообщение' : (titles()?.title || doc()?.file_name || 'Аудио');
  const isCurrent = () => !!doc() && props.playing()?.doc?.id === doc().id;
  const isPlaying = () => isCurrent() && !props.playing().paused;

  // From the click on a track to its first sound Web K loads it: this time the row already
  // answers — a spinner in the button and the mini player (with a moving bar) are there.
  const [pending, setPending] = createSignal(false);
  let startedFrom: string | undefined;
  let pendingTimer: number | undefined;
  const stopPending = () => {
    window.clearTimeout(pendingTimer);
    setPending(false);
  };
  onCleanup(() => window.clearTimeout(pendingTimer));
  createEffect(() => {
    if(!pending()) return;
    const id = props.playing()?.doc?.id as string | undefined;
    // it sounds — or Web K went on to another track: the wait is over
    if(isPlaying() || (id !== undefined && id !== startedFrom && !isCurrent())) stopPending();
  });

  const isLoading = () => pending() && !isPlaying();
  const isActive = () => isCurrent() || pending();
  const time = () => isCurrent() ? props.time() : 0;
  const duration = () => {
    const own = doc()?.duration || 0;
    if(!isCurrent()) return own;
    return appMediaPlaybackController.getPlayingDetails()?.media?.duration || own;
  };
  const progress = () => duration() ? Math.min(1, time() / duration()) : 0;

  const onClick = (event: MouseEvent) => {
    const target = event.target as HTMLElement;
    // the source opens the chat, the player has its own buttons; the click Web K's toggle gets from us comes back here
    if(target.closest('.vk-audio-source, .vk-audio-player, .vk-audio-native')) return;

    if(isCurrent()) {
      appMediaPlaybackController.toggle();
      return;
    }
    // it is loading already: a second press would only stop it
    if(pending()) return;

    const toggle = native.querySelector<HTMLElement>('.audio-toggle') ?? native.querySelector<HTMLElement>('.audio');
    if(!toggle) {
      openWebKMessage(props.message.peerId, props.message.mid);
      return;
    }

    startedFrom = props.playing()?.doc?.id as string | undefined;
    setPending(true);
    window.clearTimeout(pendingTimer);
    pendingTimer = window.setTimeout(stopPending, 10000);
    toggle.click();
  };

  // the bar of the mini player: a click or a drag moves the position of the playing track
  const seekFrom = (event: PointerEvent) => {
    if(!isCurrent()) return;
    const media = appMediaPlaybackController.getPlayingDetails()?.media;
    const total = media?.duration || doc()?.duration;
    if(!media || !total) return;
    const rect = (event.currentTarget as HTMLElement).getBoundingClientRect();
    media.currentTime = Math.max(0, Math.min(1, (event.clientX - rect.left) / rect.width)) * total;
  };

  return (
    <li
      class="vk-audio-item"
      classList={{'is-current': isActive(), 'is-loading': isLoading()}}
      onClick={onClick}
    >
      <button
        type="button"
        class="vk-audio-play"
        aria-label={isLoading() ? 'Загрузка' : isPlaying() ? 'Пауза' : 'Воспроизвести'}
        aria-busy={isLoading()}
      >
        <Show when={!isLoading()} fallback={<span class="vk-audio-spinner" aria-hidden="true" />}>
          <VKPlayGlyph playing={isPlaying()} size={14} />
        </Show>
      </button>

      <div class="vk-audio-info">
        <div class="vk-audio-line">
          <Show when={performer()}>
            <span class="vk-audio-performer">{performer()}</span>
            <span class="vk-audio-dash" aria-hidden="true">{' — '}</span>
          </Show>
          <span class="vk-audio-title">{title()}</span>
        </div>
      </div>

      <div class="vk-audio-side">
        <Show when={isActive()}>
          <div class="vk-audio-player">
            <Show when={!isVoice()}>
              <button
                type="button"
                class="vk-audio-player-button"
                aria-label="Предыдущий трек"
                onClick={() => appMediaPlaybackController.previous()}
              >
                <svg viewBox="0 0 16 16" width="12" height="12" aria-hidden="true">
                  <path d="M2 2.5h1.8v11H2zM14 2.5v11L5.6 8z" fill="currentColor" />
                </svg>
              </button>
              <button
                type="button"
                class="vk-audio-player-button"
                aria-label="Следующий трек"
                onClick={() => appMediaPlaybackController.next()}
              >
                <svg viewBox="0 0 16 16" width="12" height="12" aria-hidden="true">
                  <path d="M14 2.5h-1.8v11H14zM2 2.5v11L10.4 8z" fill="currentColor" />
                </svg>
              </button>
            </Show>
            <span class="vk-audio-player-time">{formatTime(time())}</span>
            <div
              class="vk-audio-seek"
              classList={{'is-loading': isLoading()}}
              role="slider"
              aria-label="Позиция"
              aria-valuemin={0}
              aria-valuemax={Math.round(duration())}
              aria-valuenow={Math.round(time())}
              onPointerDown={(event) => {
                event.currentTarget.setPointerCapture(event.pointerId);
                seekFrom(event);
              }}
              onPointerMove={(event) => {
                if(event.buttons & 1) seekFrom(event);
              }}
            >
              <span style={{width: progress() * 100 + '%'}} />
            </div>
            <span class="vk-audio-player-time">{formatDuration(duration(), true)}</span>
          </div>
        </Show>
        <Show when={isPlaying()}>
          <span class="vk-audio-eq" aria-hidden="true"><i /><i /><i /></span>
        </Show>
        <span class="vk-audio-duration">{formatDuration(doc()?.duration, true)}</span>
        <AudioSource message={props.message} />
      </div>

      <div ref={native} class="vk-audio-native" aria-hidden="true">
        <VKChannelPostMedia message={props.message} />
      </div>
    </li>
  );
}

/**
 * A list of tracks / voice messages in the new audio-row design: «Аудиозаписи» (the tabs of
 * search, saved, voice) and the «Музыка» block of a channel. The state of Web K's global
 * player is read once here and shared by the rows.
 */
export function VKAudioRows(props: {messages: Message.message[]}) {
  const playing = createNowPlaying();
  const time = createPlaybackTime(playing);

  return (
    <ul class="vk-audio-list">
      <For each={props.messages}>
        {(message) => <AudioItem message={message} playing={playing} time={time} />}
      </For>
    </ul>
  );
}
