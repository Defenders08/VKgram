import {createMemo, Match, Show, Switch, createSignal, onCleanup, onMount} from 'solid-js';
import type {Message, MessageMedia, WebPage, Photo} from '@layer';
import type {MyDocument} from '@appManagers/appDocsManager';
import getMediaFromMessage from '@appManagers/utils/messages/getMediaFromMessage';
import PhotoTsx from '@components/wrappers/photoTsx';
import VideoTsx from '@components/wrappers/videoTsx';
import DocumentTsx from '@components/wrappers/documentTsx';
import {openWebKMessage} from '@/vkgram/webk';

/**
 * Web K sizes a photo/video box with fixed px width AND height in inline
 * style. In a narrow column that either overflows or distorts, so the pair is
 * turned into `aspect-ratio` + `width: min(<px>, 100%)`: the box keeps its
 * proportions and never exceeds the column.
 */
function keepAspect(root: HTMLElement) {
  const apply = () => {
    root.querySelectorAll<HTMLElement>('div[style*="width"][style*="height"]').forEach((el) => {
      const w = parseFloat(el.style.width);
      const h = parseFloat(el.style.height);
      if(!(w > 0) || !(h > 0) || el.classList.contains('media-container-aspecter')) return;
      el.style.aspectRatio = `${w} / ${h}`;
      el.style.width = `min(${w}px, 100%)`;
      el.style.height = 'auto';
    });
  };
  const observer = new MutationObserver(apply);
  observer.observe(root, {childList: true, subtree: true, attributes: true, attributeFilter: ['style']});
  apply();
  return observer;
}

export type MediaKind =
  | 'photo' | 'video' | 'gif' | 'round'
  | 'sticker' | 'audio' | 'voice' | 'document'
  | 'link' | 'other';

function StickerMedia(props: {message: Message.message, doc: MyDocument}) {
  let holder!: HTMLDivElement;
  const [failed, setFailed] = createSignal(false);

  onMount(() => {
    let destroyed = false;
    import('@components/wrappers/sticker')
      .then(({default: wrapSticker}) => wrapSticker({
        doc: props.doc,
        div: holder,
        width: 160,
        height: 160,
        loop: true,
        play: true,
        withThumb: true,
        needFadeIn: true
      }))
      .catch(() => {
        if(!destroyed) setFailed(true);
      });
    onCleanup(() => { destroyed = true; });
  });

  return (
    <Show when={!failed()} fallback={
      <DocumentTsx
        class="vk-message-document"
        message={props.message}
        searchContext={{
          peerId: props.message.peerId,
          inputFilter: {_: 'inputMessagesFilterDocument'}
        }}
        autoDownloadSize={0}
        getSize={() => 320}
      />
    }>
      <div ref={holder} class="vk-message-sticker" />
    </Show>
  );
}

export default function MessageMedia(props: {
  message: Message.message,
  boxSize?: number,
  onMediaClick?: (message: Message.message, target?: HTMLElement) => void
}) {
  const box = () => props.boxSize ?? 560;

  const kind = createMemo((): MediaKind | undefined => {
    const media = props.message.media as MessageMedia | undefined;
    if(!media) return;

    switch(media._) {
      case 'messageMediaPhoto':
        return getMediaFromMessage(props.message, true) ? 'photo' : undefined;

      case 'messageMediaDocument': {
        const doc = getMediaFromMessage(props.message, true) as MyDocument | undefined;
        if(!doc) return;
        switch(doc.type) {
          case 'video': return 'video';
          case 'gif': return 'gif';
          case 'round': return 'round';
          case 'sticker': return 'sticker';
          case 'audio': return 'audio';
          case 'voice': return 'voice';
          default: return 'document';
        }
      }

      case 'messageMediaWebPage':
        return (media as MessageMedia.messageMediaWebPage).webpage?._ === 'webPage' ? 'link' : undefined;

      case 'messageMediaEmpty':
        return;

      default:
        return 'other';
    }
  });

  const photo = () => getMediaFromMessage(props.message, true) as Photo.photo;
  const doc = () => getMediaFromMessage(props.message, true) as MyDocument;
  const webPage = () => (props.message.media as MessageMedia.messageMediaWebPage).webpage as WebPage.webPage;

  const getClickTarget = (event: MouseEvent) => {
    const container = event.currentTarget as HTMLElement;
    return container.querySelector<HTMLElement>('img, video, canvas') ?? container;
  };

  const handleMediaClick = (event: MouseEvent) => {
    props.onMediaClick?.(props.message, getClickTarget(event));
  };

  return (
    <Show when={kind()}>
      <div class="vk-message-media" ref={(el) => {
        const observer = keepAspect(el);
        onCleanup(() => observer.disconnect());
      }} classList={{
        'vk-message-media-photo': kind() === 'photo',
        'vk-message-media-video': kind() === 'video' || kind() === 'gif' || kind() === 'round'
      }}>
        <Switch>
          <Match when={kind() === 'photo'}>
            <PhotoTsx
              class="vk-message-photo"
              photo={photo()}
              message={props.message}
              boxWidth={box()}
              boxHeight={box()}
              onClick={handleMediaClick}
            />
          </Match>

          <Match when={kind() === 'video' || kind() === 'gif' || kind() === 'round'}>
            <VideoTsx
              class={`vk-message-video ${kind() === 'round' ? 'vk-message-video-round' : ''}`}
              doc={doc()}
              message={props.message}
              boxWidth={kind() === 'round' ? 200 : box()}
              boxHeight={kind() === 'round' ? 200 : box()}
              onClick={handleMediaClick}
            />
          </Match>

          <Match when={kind() === 'sticker'}>
            <StickerMedia message={props.message} doc={doc()} />
          </Match>

          <Match when={kind() === 'audio' || kind() === 'voice' || kind() === 'document'}>
            <DocumentTsx
              class={`vk-message-document ${kind() === 'audio' ? 'vk-message-audio' : ''} ${kind() === 'voice' ? 'vk-message-voice' : ''}`}
              message={props.message}
              searchContext={{
                peerId: props.message.peerId,
                inputFilter: {_: kind() === 'document' ? 'inputMessagesFilterDocument' : 'inputMessagesFilterMusic'}
              }}
              autoDownloadSize={kind() === 'voice' || kind() === 'audio' ? 2e6 : 0}
              getSize={() => 320}
            />
          </Match>

          <Match when={kind() === 'link'}>
            <a class="vk-message-link" href={webPage().url} target="_blank" rel="noopener noreferrer">
              <Show when={webPage().site_name}>
                <span class="vk-message-link-site">{webPage().site_name}</span>
              </Show>
              <Show when={webPage().title}>
                <span class="vk-message-link-title">{webPage().title}</span>
              </Show>
              <Show when={webPage().description}>
                <span class="vk-message-link-description vk-page-text-secondary">{webPage().description}</span>
              </Show>
              <span class="vk-message-link-url vk-page-text-secondary">{webPage().display_url || webPage().url}</span>
            </a>
          </Match>

          <Match when={kind() === 'other'}>
            <button
              type="button"
              class="vk-button vk-button-secondary"
              onClick={() => openWebKMessage(props.message.peerId, props.message.mid)}
            >
              Показать вложение в «Телеграм»
            </button>
          </Match>
        </Switch>
      </div>
    </Show>
  );
}
