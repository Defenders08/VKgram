import {Show} from 'solid-js';
import type {User} from '@layer';
import rootScope from '@lib/rootScope';
import {useUser} from '@stores/peers';
import useScrollToTop from '@/vkgram/hooks/useScrollToTop';
import useConnectionStatus from '@/vkgram/hooks/useConnectionStatus';
import getPeerActiveUsernames from '@appManagers/utils/peers/getPeerActiveUsernames';
import {closeVKChannel, vkChannelPeerId} from '@/vkgram/pages/channel/route';
import {closeVKProfile, vkProfilePeerId} from '@/vkgram/pages/profile/route';
import {vkMessagesBack} from '@/vkgram/pages/messages/route';
import {openWebKChat} from '@/vkgram/webk';
import {openVKSection, VKSectionId} from '@/vkgram/sections';
import {confirmVKLogout} from '@/vkgram/logout';
import VKHeaderSearch from '@/vkgram/components/VKHeaderSearch';
import VKMiniPlayer from '@/vkgram/components/VKMiniPlayer';
import VKIcon from '@/vkgram/components/VKIcons';

export type VKHeaderProps = {
  variant: 'desktop' | 'mobile',
  // the current section: an open channel puts its «back» and actions into the bar
  section?: VKSectionId,
  // mobile only — the "☰" button; omitted → the button isn't rendered
  onMenuClick?: () => void,
  isMenuActive?: boolean,
  // id of the panel the menu button opens
  menuControls?: string
};

/**
 * The top blue bar in the old VK shape: burger (mobile) and the logo on the left (desktop: a field with the user's username, still the «home» button), the search in the
 * middle (desktop), and on the right the actions of the current page. An open
 * channel adds «← Каналы» next to the logo and «Открыть в «Телеграм»» on the
 * right — they used to sit inside the page content. «Страница» is in the
 * left menu (on mobile — behind «Ещё» / ☰).
 * «↑ Наверх» (desktop, in the left corner of the bar) scrolls whatever is scrolled down in the content (a page, a dialog) to its top and is shown only then.
 * The mini player (desktop) sits between the spacer and the search; on mobile it is at the top of the side menu.
 * «Выйти» closes the bar on desktop only (with Telegram's confirmation); on
 * mobile it is the last item of the side menu instead.
 */
export default function VKHeader(props: VKHeaderProps) {
  const user = useUser(() => rootScope.myId.toUserId()) as () => User.user | undefined;
  // «Waiting for network…» and the like, under the name; empty (not shown) when all is well
  const connectionStatus = useConnectionStatus();
  // desktop: the signed-in user (a small profile icon and the username in lower case; without one — the name as it is written) stands in the place of the logo;
  // an account without a username shows its name instead
  const userName = () => {
    const current = user();
    if(props.variant !== 'desktop' || !current || current.pFlags?.deleted) return '';
    const username = getPeerActiveUsernames(current)[0];
    return username ? username.toLowerCase() : [current.first_name, current.last_name].filter(Boolean).join(' ');
  };
  // an open channel / another user's profile belong to their own sections
  const openChannelId = () => props.section === 'channels' ? vkChannelPeerId() : undefined;
  const openProfileId = () => props.section === 'profile' ? vkProfilePeerId() : undefined;
  // desktop only: shown while something in the content is scrolled down
  const toTop = useScrollToTop(() => props.section);

  return (
    <header class="vk-header" classList={{'is-mobile': props.variant === 'mobile'}}>
      <Show when={props.variant === 'desktop'}>
        <button
          type="button"
          class="vk-header-action vk-header-to-top"
          classList={{'is-visible': toTop.visible()}}
          tabIndex={toTop.visible() ? 0 : -1}
          onClick={() => toTop.scrollToTop()}
        >
          <VKIcon name="up" size={16} />
          <span>Наверх</span>
        </button>
      </Show>

      <div class="vk-header-inner">
        <Show when={props.variant === 'mobile' && props.onMenuClick}>
          <button
            type="button"
            class="vk-header-menu-button"
            classList={{'is-active': !!props.isMenuActive}}
            aria-label="Меню"
            aria-expanded={!!props.isMenuActive}
            aria-controls={props.menuControls}
            onClick={() => props.onMenuClick()}
          >
            ☰
          </button>
        </Show>

        <button
          type="button"
          class="vk-header-logo"
          classList={{'has-user': !!userName()}}
          onClick={() => openVKSection('news')}
          title="Новости"
        >
          <Show when={userName()} fallback="ВКГРАМ">
            <VKIcon name="profile" size={15} class="vk-header-user-icon" />
            <span class="vk-header-user-text">
              <span class="vk-header-user-name">{userName()}</span>
              <Show when={connectionStatus()}>
                {(status) => (
                  <span class="vk-header-user-status" role="status">
                    <span class="vk-header-user-spinner" aria-hidden="true" />
                    <span class="vk-header-user-status-text">{status()}</span>
                  </span>
                )}
              </Show>
            </span>
          </Show>
        </button>

        <Show when={openChannelId()}>
          <button type="button" class="vk-header-action vk-header-back" onClick={() => closeVKChannel()}>
            <VKIcon name="back" size={16} />
            <span>Каналы</span>
          </button>
        </Show>

        <Show when={openProfileId()}>
          <button type="button" class="vk-header-action vk-header-back" onClick={() => closeVKProfile()}>
            <VKIcon name="back" size={16} />
            <span>Назад</span>
          </button>
        </Show>

        <Show when={props.section === 'messages' ? vkMessagesBack() : undefined}>
          {(back) => (
            <button type="button" class="vk-header-action vk-header-back" aria-label="Вернуться в чаты" onClick={() => back()()}>
              <VKIcon name="back" size={16} />
              <span>Чаты</span>
            </button>
          )}
        </Show>

        <div class="vk-header-spacer" />

        <Show when={props.variant === 'desktop'}>
          <VKMiniPlayer variant="header" />
          <VKHeaderSearch />
        </Show>

        <Show when={openChannelId()}>
          {(peerId) => (
            <button type="button" class="vk-header-action" onClick={() => openWebKChat(peerId())}>
              {props.variant === 'desktop' ? 'Открыть в «Телеграм»' : 'В Телеграм'}
            </button>
          )}
        </Show>

      </div>
    </header>
  );
}
