import {Show} from 'solid-js';
import {closeVKChannel, vkChannelPeerId} from '@/vkgram/pages/channel/route';
import {closeVKProfile, vkProfilePeerId} from '@/vkgram/pages/profile/route';
import {openWebKChat} from '@/vkgram/webk';
import {openVKSection, VKSectionId} from '@/vkgram/sections';
import {confirmVKLogout} from '@/vkgram/logout';
import VKHeaderSearch from '@/vkgram/components/VKHeaderSearch';
import VKIcon from '@/vkgram/components/VKIcons';

export type VKHeaderProps = {
  variant: 'desktop' | 'mobile',
  // the current section: an open channel puts its «back» and actions into the bar
  section?: VKSectionId,
  // mobile only — the "☰" button; omitted → the button isn't rendered
  onMenuClick?: () => void,
  isMenuActive?: boolean,
  // id of the panel the menu button opens
  menuControls?: string
};

/**
 * The top blue bar in the old VK shape: burger (mobile) and logo on the left, the search in the
 * middle (desktop), and on the right the actions of the current page. An open
 * channel adds «← Каналы» next to the logo and «Открыть в «Телеграм»» on the
 * right — they used to sit inside the page content. «Страница» is in the
 * left menu (on mobile — behind «Ещё» / ☰).
 * «Выйти» closes the bar on desktop only (with Telegram's confirmation); on
 * mobile it is the last item of the side menu instead.
 */
export default function VKHeader(props: VKHeaderProps) {
  const openChannelId = () => props.section === 'channels' ? vkChannelPeerId() : undefined;
  // desktop only: the mobile app still opens a profile in Web K
  const openProfileId = () => props.variant === 'desktop' && props.section === 'profile' ? vkProfilePeerId() : undefined;

  return (
    <header class="vk-header" classList={{'is-mobile': props.variant === 'mobile'}}>
      <div class="vk-header-inner">
        <Show when={props.variant === 'mobile' && props.onMenuClick}>
          <button
            type="button"
            class="vk-header-menu-button"
            classList={{'is-active': !!props.isMenuActive}}
            aria-label="Меню"
            aria-expanded={!!props.isMenuActive}
            aria-controls={props.menuControls}
            onClick={() => props.onMenuClick()}
          >
            ☰
          </button>
        </Show>

        <button type="button" class="vk-header-logo" onClick={() => openVKSection('news')} title="Новости">
          ВКГРАМ
        </button>

        <Show when={openChannelId()}>
          <button type="button" class="vk-header-action vk-header-back" onClick={() => closeVKChannel()}>
            <VKIcon name="back" size={16} />
            <span>Каналы</span>
          </button>
        </Show>

        <Show when={openProfileId()}>
          <button type="button" class="vk-header-action vk-header-back" onClick={() => closeVKProfile()}>
            <VKIcon name="back" size={16} />
            <span>Назад</span>
          </button>
        </Show>

        <div class="vk-header-spacer" />

        <Show when={props.variant === 'desktop'}>
          <VKHeaderSearch />
        </Show>

        <Show when={openChannelId()}>
          {(peerId) => (
            <button type="button" class="vk-header-action" onClick={() => openWebKChat(peerId())}>
              {props.variant === 'desktop' ? 'Открыть в «Телеграм»' : 'В Телеграм'}
            </button>
          )}
        </Show>

      </div>
    </header>
  );
}
