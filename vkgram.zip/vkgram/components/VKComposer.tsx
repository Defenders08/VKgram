import {createEffect, createResource, createSignal, For, on, onCleanup, Show} from 'solid-js';
import type {Message} from '@layer';
import type {MyDocument} from '@appManagers/appDocsManager';
import type {SendFileDetails} from '@appManagers/appMessagesManager';
import rootScope from '@lib/rootScope';
import opusDecodeController from '@lib/opusDecodeController';
import VoiceWaveformAnalyser from '@helpers/voiceWaveformAnalyser';
import NativeVoiceRecorder, {isNativeVoiceRecorderSupported} from '@helpers/voiceRecorder/nativeVoiceRecorder';
import VideoTsx from '@components/wrappers/videoTsx';
import VKIcon from '@/vkgram/components/VKIcons';
import VKFileIcon from '@/vkgram/components/VKFileIcon';
import {getFileKind} from '@/vkgram/utils/fileKind';

/**
 * Composer of «Сообщения». It owns only the input UI: every send goes through
 * Web K's own `appMessagesManager` (sendText / sendFile / sendGrouped /
 * editMessage) — there is no second message system here.
 *
 * Reply is `replyToMsgId` of MessageSendingParams (what Web K's
 * `chat.getMessageSendingParams()` produces for a reply), voice is the same
 * OGG/Opus recorder Web K's input uses (NativeVoiceRecorder → opus-recorder).
 */

export type ComposerReply = {mid: number, author: string, text: string};

type QueueKind = 'photo' | 'video' | 'document';
type QueueItem = {
  id: number,
  file: File,
  kind: QueueKind,
  url?: string,
  width?: number,
  height?: number,
  duration?: number
};

type Panel = 'emoji' | 'stickers' | 'gifs';

const MAX_ALBUM = 10;

const EMOJI_GROUPS: {title: string, items: string}[] = [
  {title: 'Смайлы', items: '😀😃😄😁😆😅😂🤣😊😇🙂😉😍🥰😘😋😛😜🤪🤔🤨😐😑😶🙄😏😴😌😎🤓😕😟🙁😮😯😲😳🥺😢😭😤😠😡🤬😱😨😰😥😓🤗🤭🤫😬🤐🥴🤢🤮🤧😷🤒🤕'},
  {title: 'Жесты', items: '👍👎👌✌️🤞🤟🤘🤙👈👉👆👇☝️✋🤚🖐️🖖👋🤝🙏💪👏🙌👐🤲✍️'},
  {title: 'Сердца и символы', items: '❤️🧡💛💚💙💜🖤🤍💔💕💞💓💗💖💘💝🔥✨⭐🌟💥💫💯✅❌❗❓💤🎉🎊🎁🏆'},
  {title: 'Разное', items: '🐶🐱🐭🐹🐰🦊🐻🐼🐨🐯🦁🐮🐷🐸🐵🍎🍊🍋🍌🍉🍇🍓🍒🍕🍔🍟🌭🍿🍩🍪🎂☕🍺🍷⚽🏀🎮🎧🎵📷💻📱🚗✈️🌍🌞🌙⛅☔❄️'}
];

const splitEmoji = (items: string) => Array.from(new Intl.Segmenter(undefined, {granularity: 'grapheme'}).segment(items), (s) => s.segment);

const kindOf = (file: File): QueueKind => {
  if(/^image\/(jpeg|png|webp|gif)$/.test(file.type) && file.type !== 'image/gif') return 'photo';
  if(/^video\/(mp4|quicktime|webm)$/.test(file.type)) return 'video';
  return 'document';
};

function probeImage(url: string) {
  return new Promise<{width: number, height: number} | undefined>((resolve) => {
    const img = new Image();
    img.onload = () => resolve({width: img.naturalWidth, height: img.naturalHeight});
    img.onerror = () => resolve(undefined);
    img.src = url;
  });
}

function probeVideo(url: string) {
  return new Promise<{width: number, height: number, duration: number} | undefined>((resolve) => {
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.onloadedmetadata = () => resolve({width: video.videoWidth, height: video.videoHeight, duration: Math.round(video.duration) || 0});
    video.onerror = () => resolve(undefined);
    video.src = url;
  });
}

function StickerThumb(props: {doc: MyDocument}) {
  let holder!: HTMLDivElement;
  createEffect(() => {
    const doc = props.doc;
    let destroyed = false;
    import('@components/wrappers/sticker').then(({default: wrapSticker}) => {
      if(destroyed) return;
      holder.replaceChildren();
      return wrapSticker({doc, div: holder, width: 72, height: 72, loop: false, play: false, static: true, withThumb: true});
    }).catch(() => {});
    onCleanup(() => { destroyed = true; });
  });
  return <div ref={holder} class="vk-composer-sticker-thumb" />;
}

export default function VKComposer(props: {
  peerId: PeerId,
  reply?: ComposerReply,
  editing?: Message.message,
  // a comments thread of the discussion group: everything is sent into it (a reply to the thread's root by default)
  threadId?: number,
  onCancelReply?: () => void,
  onCancelEdit?: () => void,
  onSent?: () => void
}) {
  const managers = () => rootScope.managers;

  const [text, setText] = createSignal('');
  const [queue, setQueue] = createSignal<QueueItem[]>([]);
  const [panel, setPanel] = createSignal<Panel>();
  const [sending, setSending] = createSignal(false);
  const [error, setError] = createSignal<string>();
  const [recording, setRecording] = createSignal(false);
  const [recSeconds, setRecSeconds] = createSignal(0);

  let textarea!: HTMLTextAreaElement;
  let fileInput!: HTMLInputElement;
  let queueId = 0;

  const fail = (err: unknown, message: string) => {
    console.error('VKgram composer:', err);
    setError(message);
  };

  const resize = () => {
    if(!textarea) return;
    textarea.style.height = 'auto';
    textarea.style.height = `${Math.min(textarea.scrollHeight, 120)}px`;
  };

  // entering the editing mode puts the message text into the input; leaving it clears
  createEffect(on(() => props.editing, (message) => {
    setError(undefined);
    if(message) {
      setText(message.message || '');
      setQueue([]);
      setPanel(undefined);
      queueMicrotask(() => {
        resize();
        textarea?.focus();
      });
    }
  }, {defer: true}));

  createEffect(on(() => props.reply, (reply) => {
    if(reply) queueMicrotask(() => textarea?.focus());
  }, {defer: true}));

  // a different dialog is a different composer state
  createEffect(on(() => props.peerId, () => {
    clearQueue();
    setText('');
    setPanel(undefined);
    setError(undefined);
    cancelRecording();
    resize();
  }, {defer: true}));

  const sendingParams = () => ({
    peerId: props.peerId,
    ...(props.threadId ? {threadId: props.threadId} : {}),
    ...(props.reply ? {replyToMsgId: props.reply.mid} : props.threadId ? {replyToMsgId: props.threadId} : {})
  });

  const clearQueue = () => {
    queue().forEach((item) => item.url && URL.revokeObjectURL(item.url));
    setQueue([]);
  };

  onCleanup(() => {
    clearQueue();
    cancelRecording();
  });

  // ── attachments ───────────────────────────────────────────────────────────

  const addFiles = async(files: File[]) => {
    if(!files.length || props.editing) return;
    setError(undefined);
    const items: QueueItem[] = [];
    for(const file of files) {
      const kind = kindOf(file);
      const item: QueueItem = {id: ++queueId, file, kind};
      if(kind !== 'document') {
        item.url = URL.createObjectURL(file);
        const info = kind === 'photo' ? await probeImage(item.url) : await probeVideo(item.url);
        if(info) Object.assign(item, info);
      }
      items.push(item);
    }
    setQueue((prev) => [...prev, ...items]);
    textarea?.focus();
  };

  const onFilesPicked = (event: Event) => {
    const input = event.currentTarget as HTMLInputElement;
    const files = Array.from(input.files || []);
    input.value = '';
    void addFiles(files);
  };

  const onPaste = (event: ClipboardEvent) => {
    const files = Array.from(event.clipboardData?.files || []);
    if(files.length) {
      event.preventDefault();
      void addFiles(files);
    }
  };

  const removeItem = (id: number) => {
    setQueue((prev) => {
      const item = prev.find((i) => i.id === id);
      if(item?.url) URL.revokeObjectURL(item.url);
      return prev.filter((i) => i.id !== id);
    });
  };

  const toDetails = (item: QueueItem): SendFileDetails => ({
    file: item.file,
    width: item.width,
    height: item.height,
    duration: item.duration
  });

  // ── send ──────────────────────────────────────────────────────────────────

  const canSend = () => !sending() && !recording() && (!!text().trim() || queue().length > 0);

  const afterSend = () => {
    setText('');
    clearQueue();
    setPanel(undefined);
    props.onCancelReply?.();
    resize();
    props.onSent?.();
  };

  const send = async() => {
    if(!canSend()) return;
    const value = text().trim();
    setSending(true);
    setError(undefined);

    try {
      const m = managers().appMessagesManager;

      if(props.editing) {
        if(!value) return;
        await m.editMessage(props.editing, value);
        setText('');
        resize();
        props.onCancelEdit?.();
        props.onSent?.();
        return;
      }

      const items = queue();
      if(!items.length) {
        await m.sendText({...sendingParams(), text: value, clearDraft: true});
        afterSend();
        return;
      }

      const media = items.filter((i) => i.kind !== 'document');
      const docs = items.filter((i) => i.kind === 'document');
      let caption = value;
      const takeCaption = () => {
        const c = caption;
        caption = '';
        return c;
      };

      // photos and videos go as an album (grouped), the rest as separate files
      for(let i = 0; i < media.length; i += MAX_ALBUM) {
        const chunk = media.slice(i, i + MAX_ALBUM);
        if(chunk.length > 1) {
          await m.sendGrouped({
            ...sendingParams(),
            isMedia: true,
            caption: takeCaption(),
            sendFileDetails: chunk.map(toDetails),
            clearDraft: true
          });
        } else {
          await m.sendFile({
            ...sendingParams(),
            ...toDetails(chunk[0]),
            isMedia: true,
            caption: takeCaption(),
            clearDraft: true
          });
        }
      }

      for(const doc of docs) {
        await m.sendFile({
          ...sendingParams(),
          ...toDetails(doc),
          isMedia: false,
          caption: takeCaption(),
          clearDraft: true
        });
      }

      afterSend();
    } catch(err) {
      fail(err, 'Не удалось отправить сообщение.');
    } finally {
      setSending(false);
    }
  };

  const onKeyDown = (event: KeyboardEvent) => {
    if(event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
      event.preventDefault();
      void send();
    } else if(event.key === 'Escape') {
      if(props.editing) props.onCancelEdit?.();
      else if(panel()) setPanel(undefined);
      else if(props.reply) props.onCancelReply?.();
    }
  };

  // ── emoji ─────────────────────────────────────────────────────────────────

  const insertEmoji = (emoji: string) => {
    const start = textarea.selectionStart ?? text().length;
    const end = textarea.selectionEnd ?? start;
    const value = text();
    setText(value.slice(0, start) + emoji + value.slice(end));
    queueMicrotask(() => {
      textarea.focus();
      const pos = start + emoji.length;
      textarea.setSelectionRange(pos, pos);
      resize();
    });
  };

  // ── stickers & GIFs: Web K's own documents, sent the way Web K's input sends them ──

  const sendDocument = async(doc: MyDocument) => {
    if(sending()) return;
    setSending(true);
    setError(undefined);
    try {
      await managers().appMessagesManager.sendFile({
        ...sendingParams(),
        file: doc,
        isMedia: true
      });
      if(doc.type === 'sticker') {
        void managers().appStickersManager.saveRecentSticker(doc.id);
      } else if(doc.type === 'gif') {
        void managers().appGifsManager.addRecentGif(doc.id);
      }
      setPanel(undefined);
      props.onCancelReply?.();
      props.onSent?.();
    } catch(err) {
      fail(err, 'Не удалось отправить.');
    } finally {
      setSending(false);
    }
  };

  const [stickerSets] = createResource(() => panel() === 'stickers' ? true : undefined, async() => {
    const all = await managers().appStickersManager.getAllStickers();
    return ((all as any).sets || []) as any[];
  });
  const [recentStickers] = createResource(() => panel() === 'stickers' ? true : undefined, async() => {
    const res = await managers().appStickersManager.getRecentStickers();
    return res.stickers as MyDocument[];
  });
  const [activeSet, setActiveSet] = createSignal<any>();
  const [setStickers] = createResource(activeSet, async(set) => {
    const {getStickerSetInputByStickerSet} = await import('@appManagers/utils/stickers/getStickerSetInput');
    const full = await managers().appStickersManager.getStickerSet(getStickerSetInputByStickerSet(set));
    return full.documents as MyDocument[];
  });
  const shownStickers = () => activeSet() ? setStickers() : recentStickers();

  const [gifQuery, setGifQuery] = createSignal('');
  const [gifs] = createResource(() => panel() === 'gifs' ? gifQuery().trim() : undefined, async(query) => {
    if(!query) return await managers().appGifsManager.getGifs() as MyDocument[];
    return (await managers().appGifsManager.searchGifs(query)).documents as MyDocument[];
  });
  let gifTimer: number;
  const onGifQuery = (value: string) => {
    clearTimeout(gifTimer);
    gifTimer = window.setTimeout(() => setGifQuery(value), 400);
  };
  onCleanup(() => clearTimeout(gifTimer));

  // ── voice ─────────────────────────────────────────────────────────────────

  let recorder: any;
  let analyser: VoiceWaveformAnalyser | undefined;
  let recStart = 0;
  let recTimer: number;
  let recCanceled = false;

  const stopTimer = () => clearInterval(recTimer);

  function cancelRecording() {
    if(!recorder) return;
    recCanceled = true;
    stopTimer();
    try {
      void recorder.stop();
    } catch(err) {}
    recorder = undefined;
    analyser = undefined;
    setRecording(false);
  }

  const startRecording = async() => {
    if(recording() || props.editing) return;
    setError(undefined);

    const Recorder = isNativeVoiceRecorderSupported() ? NativeVoiceRecorder : (window as any).Recorder;
    if(!Recorder) {
      setError('Запись голоса не поддерживается в этом браузере.');
      return;
    }

    const rec = new Recorder({
      encoderSampleRate: 48000,
      monitorGain: 0,
      numberOfChannels: 1,
      recordingGain: 1,
      reuseWorker: true
    });
    recorder = rec;
    recCanceled = false;

    rec.onstop = () => {
      stopTimer();
      setRecording(false);
    };

    rec.ondataavailable = async(typedArray: Uint8Array) => {
      const waveform = analyser?.finish();
      analyser = undefined;
      recorder = undefined;
      if(recCanceled) return;

      const duration = Math.max(1, Math.round((Date.now() - recStart) / 1000));
      if(Date.now() - recStart < 500) return;

      const file = new Blob([typedArray as BlobPart], {type: 'audio/ogg'});
      try {
        const result = await opusDecodeController.decode(typedArray, false);
        opusDecodeController.setKeepAlive(false);
        await managers().appMessagesManager.sendFile({
          ...sendingParams(),
          file,
          isVoiceMessage: true,
          isMedia: true,
          duration,
          waveform,
          objectURLBlob: result.blob,
          clearDraft: true
        });
        props.onCancelReply?.();
        props.onSent?.();
      } catch(err) {
        fail(err, 'Не удалось отправить голосовое сообщение.');
      }
    };

    try {
      await rec.start();
      recStart = Date.now();
      analyser = new VoiceWaveformAnalyser(rec.sourceNode);
      setRecSeconds(0);
      setRecording(true);
      recTimer = window.setInterval(() => setRecSeconds(Math.floor((Date.now() - recStart) / 1000)), 250);
    } catch(err) {
      recorder = undefined;
      fail(err, 'Нет доступа к микрофону.');
    }
  };

  const finishRecording = () => {
    if(!recorder) return;
    try {
      void recorder.stop();
    } catch(err) {
      fail(err, 'Не удалось завершить запись.');
    }
  };

  const mmss = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  const togglePanel = (next: Panel) => setPanel((p) => p === next ? undefined : next);

  // ── view ──────────────────────────────────────────────────────────────────

  return (
    <div class="vk-composer">
      <Show when={props.editing}>
        <div class="vk-composer-reply">
          <div class="vk-composer-reply-info">
            <span class="vk-composer-reply-name">Редактирование</span>
            <span class="vk-composer-reply-text">{props.editing!.message}</span>
          </div>
          <button type="button" class="vk-composer-btn" aria-label="Отменить редактирование" onClick={() => {
            setText('');
            resize();
            props.onCancelEdit?.();
          }}>
            <VKIcon name="close" size={14} />
          </button>
        </div>
      </Show>

      <Show when={props.reply && !props.editing}>
        <div class="vk-composer-reply">
          <div class="vk-composer-reply-info">
            <span class="vk-composer-reply-name">{props.reply!.author}</span>
            <span class="vk-composer-reply-text">{props.reply!.text}</span>
          </div>
          <button type="button" class="vk-composer-btn" aria-label="Отменить ответ" onClick={() => props.onCancelReply?.()}>
            <VKIcon name="close" size={14} />
          </button>
        </div>
      </Show>

      <Show when={queue().length}>
        <div class="vk-composer-attach-queue">
          <For each={queue()}>
            {(item) => (
              <div class="vk-composer-attach-chip">
                <Show when={item.kind === 'photo'}>
                  <img class="vk-composer-attach-thumb" src={item.url} alt="" />
                </Show>
                <Show when={item.kind === 'video'}>
                  <video class="vk-composer-attach-thumb" src={item.url} muted preload="metadata" />
                </Show>
                <Show when={item.kind === 'document'}>
                  <div class="vk-composer-attach-file" title={item.file.name}>
                    <VKFileIcon kind={getFileKind(item.file.name, item.file.type)} size={22} />
                  </div>
                </Show>
                <button type="button" class="vk-composer-attach-remove" aria-label="Убрать вложение" onClick={() => removeItem(item.id)}>
                  ×
                </button>
              </div>
            )}
          </For>
        </div>
      </Show>

      <Show when={recording()}>
        <div class="vk-composer-recording">
          <span class="vk-composer-rec-dot" />
          <span>Запись {mmss(recSeconds())}</span>
        </div>
      </Show>

      <div class="vk-composer-row">
        <Show when={!props.editing && !recording()}>
          <button type="button" class="vk-composer-btn" title="Прикрепить файл" aria-label="Прикрепить файл" onClick={() => fileInput.click()}>
            <VKIcon name="docs" size={18} />
          </button>
          <input
            ref={fileInput}
            type="file"
            multiple
            hidden
            onChange={onFilesPicked}
          />
        </Show>

        <Show when={!recording()} fallback={<div class="vk-composer-input vk-composer-input-recording" />}>
          <textarea
            ref={textarea}
            class="vk-composer-input"
            value={text()}
            placeholder={props.editing ? 'Изменить сообщение…' : 'Написать сообщение…'}
            rows={1}
            disabled={sending()}
            onInput={(event) => {
              setText(event.currentTarget.value);
              resize();
            }}
            onKeyDown={onKeyDown}
            onPaste={onPaste}
          />
        </Show>

        <Show when={!recording()}>
          <div class="vk-composer-emoji-holder">
            <button
              type="button"
              class="vk-composer-btn"
              classList={{'is-active': !!panel()}}
              title="Эмодзи, стикеры, GIF"
              aria-label="Эмодзи, стикеры, GIF"
              aria-expanded={!!panel()}
              onClick={() => setPanel((p) => p ? undefined : 'emoji')}
            >
              <VKIcon name="smile" size={18} />
            </button>

            <Show when={panel()}>
              <div class="vk-composer-pop vk-composer-panel">
                <div class="vk-composer-panel-tabs" role="tablist">
                  <button type="button" role="tab" class="vk-composer-panel-tab" classList={{'is-active': panel() === 'emoji'}} onClick={() => togglePanel('emoji')}>Эмодзи</button>
                  <Show when={!props.editing}>
                    <button type="button" role="tab" class="vk-composer-panel-tab" classList={{'is-active': panel() === 'stickers'}} onClick={() => setPanel('stickers')}>Стикеры</button>
                    <button type="button" role="tab" class="vk-composer-panel-tab" classList={{'is-active': panel() === 'gifs'}} onClick={() => setPanel('gifs')}>GIF</button>
                  </Show>
                </div>

                <Show when={panel() === 'emoji'}>
                  <div class="vk-emoji-panel">
                    <For each={EMOJI_GROUPS}>
                      {(group) => (
                        <>
                          <div class="vk-emoji-group-title">{group.title}</div>
                          <div class="vk-emoji-grid">
                            <For each={splitEmoji(group.items)}>
                              {(emoji) => (
                                <button type="button" class="vk-emoji-item" onClick={() => insertEmoji(emoji)}>{emoji}</button>
                              )}
                            </For>
                          </div>
                        </>
                      )}
                    </For>
                  </div>
                </Show>

                <Show when={panel() === 'stickers'}>
                  <div class="vk-composer-sticker-sets">
                    <button type="button" class="vk-composer-sticker-set" classList={{'is-active': !activeSet()}} onClick={() => setActiveSet(undefined)}>Недавние</button>
                    <For each={stickerSets() || []}>
                      {(set) => (
                        <button type="button" class="vk-composer-sticker-set" classList={{'is-active': activeSet() === set}} title={set.title} onClick={() => setActiveSet(set)}>
                          {set.title}
                        </button>
                      )}
                    </For>
                  </div>
                  <div class="vk-sticker-grid">
                    <For each={shownStickers() || []} fallback={<div class="vk-composer-panel-empty">{(activeSet() ? setStickers : recentStickers).loading ? 'Загрузка…' : 'Нет стикеров'}</div>}>
                      {(doc) => (
                        <button type="button" class="vk-sticker-item" onClick={() => void sendDocument(doc)}>
                          <StickerThumb doc={doc} />
                        </button>
                      )}
                    </For>
                  </div>
                </Show>

                <Show when={panel() === 'gifs'}>
                  <input
                    type="search"
                    class="vk-composer-gif-search"
                    placeholder="Поиск GIF"
                    onInput={(event) => onGifQuery(event.currentTarget.value)}
                  />
                  <div class="vk-gif-grid">
                    <For each={gifs() || []} fallback={<div class="vk-composer-panel-empty">{gifs.loading ? 'Загрузка…' : 'Ничего не найдено'}</div>}>
                      {(doc) => (
                        <button type="button" class="vk-gif-item" onClick={() => void sendDocument(doc)}>
                          <VideoTsx doc={doc} boxWidth={120} boxHeight={120} noInfo noPlayButton withoutPreloader />
                        </button>
                      )}
                    </For>
                  </div>
                </Show>
              </div>
            </Show>
          </div>
        </Show>

        <Show when={recording()}>
          <button type="button" class="vk-composer-btn" title="Отменить запись" aria-label="Отменить запись" onClick={cancelRecording}>
            <VKIcon name="close" size={16} />
          </button>
        </Show>

        <Show
          when={canSend() || recording() || props.editing}
          fallback={
            <button type="button" class="vk-composer-btn" title="Записать голосовое сообщение" aria-label="Записать голосовое сообщение" onClick={() => void startRecording()}>
              <VKIcon name="audio" size={18} />
            </button>
          }
        >
          <button
            type="button"
            class="vk-composer-btn vk-composer-send"
            title={recording() ? 'Отправить голосовое сообщение' : props.editing ? 'Сохранить' : 'Отправить'}
            aria-label={recording() ? 'Отправить голосовое сообщение' : props.editing ? 'Сохранить' : 'Отправить'}
            disabled={recording() ? false : !canSend()}
            onClick={() => recording() ? finishRecording() : void send()}
          >
            {sending() ? '…' : '➤'}
          </button>
        </Show>
      </div>

      <Show when={error()}>
        <div class="vk-composer-error">{error()}</div>
      </Show>
    </div>
  );
}
