import {createEffect, onCleanup} from 'solid-js';
import type {Message} from '@layer';
import wrapRichText from '@richTextProcessor/wrapRichText';
import {getMiddleware} from '@helpers/middleware';

/**
 * Универсальный компонент для рендеринга текста сообщения с entities.
 * Используется как в чатах, так и в постах каналов.
 */
export default function MessageText(props: {
  message: Message.message,
  class?: string
}) {
  let textEl!: HTMLDivElement;

  createEffect(() => {
    const message = props.message;
    const middlewareHelper = getMiddleware();
    onCleanup(() => middlewareHelper.destroy());

    textEl.replaceChildren(
      message.message
        ? wrapRichText(message.message, {
          entities: message.totalEntities ?? message.entities,
          middleware: middlewareHelper.get()
        })
        : document.createTextNode('')
    );
  });

  return <div ref={textEl} class={props.class} />;
}
