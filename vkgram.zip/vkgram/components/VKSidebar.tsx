import {For, Show} from 'solid-js';
import type {User} from '@layer';
import rootScope from '@lib/rootScope';
import {useUser} from '@stores/peers';
import {getVKSections, VKSection, VKSectionId} from '@/vkgram/sections';
import VKIcon from '@/vkgram/components/VKIcons';

const MAIN_SECTIONS = getVKSections([
  'profile', 'news', 'messages', 'friends', 'groups', 'channels', 'audio', 'photos', 'videos', 'apps'
]);
const BOTTOM_SECTIONS = getVKSections(['settings']);

export type VKSidebarProps = {
  active: VKSectionId,
  onSectionChange: (id: VKSectionId) => void
};

/**
 * Desktop left menu in the old VK shape: the sections in one list, settings
 * below a divider. Reports the chosen section
 * up — the layout decides what to show.
 */
export default function VKSidebar(props: VKSidebarProps) {
  const user = useUser(() => rootScope.myId.toUserId()) as () => User.user;

  const renderItems = (items: VKSection[]) => (
    <ul class="vk-sidebar-list">
      <For each={items}>
        {(item) => (
          <li>
            <button
              type="button"
              class="vk-sidebar-item"
              classList={{'is-active': props.active === item.id}}
              aria-current={props.active === item.id ? 'page' : undefined}
              onClick={() => props.onSectionChange(item.id)}
            >
              <VKIcon name={item.icon} size={16} class="vk-sidebar-item-icon" />
              <span class="vk-sidebar-item-text">{item.title}</span>
            </button>
          </li>
        )}
      </For>
    </ul>
  );

  return (
    <nav class="vk-sidebar" aria-label="Главное меню">
      {renderItems(MAIN_SECTIONS)}
      <div class="vk-sidebar-divider" />
      {renderItems(BOTTOM_SECTIONS)}

      <Show when={user()?.username}>
        <div class="vk-sidebar-footer">@{user().username}</div>
      </Show>
    </nav>
  );
}
